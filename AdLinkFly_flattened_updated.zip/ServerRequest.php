<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @since         2.0.0
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 */
namespace Cake\Http;

use ArrayAccess;
use BadMethodCallException;
use Cake\Core\Configure;
use Cake\Http\Cookie\CookieCollection;
use Cake\Http\Exception\MethodNotAllowedException;
use Cake\Http\Session;
use Cake\Utility\Hash;
use InvalidArgumentException;
use Laminas\Diactoros\PhpInputStream;
use Laminas\Diactoros\Stream;
use Laminas\Diactoros\UploadedFile;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\StreamInterface;
use Psr\Http\Message\UploadedFileInterface;
use Psr\Http\Message\UriInterface;

/**
 * A class that helps wrap Request information and particulars about a single request.
 * Provides methods commonly used to introspect on the request headers and request body.
 */
class ServerRequest implements ArrayAccess, ServerRequestInterface
{
    /**
     * Array of parameters parsed from the URL.
     *
     * @var array
     * @deprecated 3.4.0 This public property will be removed in 4.0.0. Use getParam() instead.
     */
    protected $params = [
        'file.php' => null,
        'file.php' => null,
        'file.php' => null,
        'file.php' => null,
        'file.php' => [],
    ];

    /**
     * Array of POST data. Will contain form data as well as uploaded files.
     * In PUT/PATCH/DELETE requests this property will contain the form-urlencoded
     * data.
     *
     * @var array|object|null
     * @deprecated 3.4.0 This public property will be removed in 4.0.0. Use getData() instead.
     */
    protected $data = [];

    /**
     * Array of query string arguments
     *
     * @var array
     * @deprecated 3.4.0 This public property will be removed in 4.0.0. Use getQuery() or getQueryParams() instead.
     */
    protected $query = [];

    /**
     * Array of cookie data.
     *
     * @var array
     * @deprecated 3.4.0 This public property will be removed in 4.0.0. Use getCookie() instead.
     */
    protected $cookies = [];

    /**
     * Array of environment data.
     *
     * @var array
     */
    protected $_environment = [];

    /**
     * The URL string used for the request.
     *
     * @var string
     * @deprecated 3.6.0 This public property will be removed in 4.0.0. Use getPath() instead.
     */
    protected $url;

    /**
     * Base URL path.
     *
     * @var string
     * @deprecated 3.4.0 This public property will be removed in 4.0.0. Use getAttribute('file.php') instead.
     */
    protected $base;

    /**
     * webroot path segment for the request.
     *
     * @var string
     * @deprecated 3.4.0 This public property will be removed in 4.0.0. Use getAttribute('file.php') instead.
     */
    protected $webroot = 'file.php';

    /**
     * The full address to the current request
     *
     * @var string
     * @deprecated 3.4.0 This public property will be removed in 4.0.0. Use getAttribute('file.php') or getUri()->getPath() instead.
     */
    protected $here;

    /**
     * Whether or not to trust HTTP_X headers set by most load balancers.
     * Only set to true if your application runs behind load balancers/proxies
     * that you control.
     *
     * @var bool
     */
    public $trustProxy = false;

    /**
     * Trusted proxies list
     *
     * @var string[]
     */
    protected $trustedProxies = [];

    /**
     * Contents of php://input
     *
     * @var string
     */
    protected $_input;

    /**
     * The built in detectors used with `is()` can be modified with `addDetector()`.
     *
     * There are several ways to specify a detector, see \Cake\Http\ServerRequest::addDetector() for the
     * various formats and ways to define detectors.
     *
     * @var array
     */
    protected static $_detectors = [
        'file.php' => ['file.php' => 'file.php', 'file.php' => 'file.php'],
        'file.php' => ['file.php' => 'file.php', 'file.php' => 'file.php'],
        'file.php' => ['file.php' => 'file.php', 'file.php' => 'file.php'],
        'file.php' => ['file.php' => 'file.php', 'file.php' => 'file.php'],
        'file.php' => ['file.php' => 'file.php', 'file.php' => 'file.php'],
        'file.php' => ['file.php' => 'file.php', 'file.php' => 'file.php'],
        'file.php' => ['file.php' => 'file.php', 'file.php' => 'file.php'],
        'file.php' => ['file.php' => 'file.php', 'file.php' => [1, 'file.php']],
        'file.php' => ['file.php' => 'file.php', 'file.php' => 'file.php'],
        'file.php' => ['file.php' => 'file.php', 'file.php' => 'file.php'],
        'file.php' => ['file.php' => 'file.php', 'file.php' => 1],
        'file.php' => ['file.php' => ['file.php'], 'file.php' => 'file.php', 'file.php' => 'file.php'],
        'file.php' => ['file.php' => ['file.php', 'file.php'], 'file.php' => 'file.php', 'file.php' => 'file.php'],
    ];

    /**
     * Instance cache for results of is(something) calls
     *
     * @var array
     */
    protected $_detectorCache = [];

    /**
     * Request body stream. Contains php://input unless `input` constructor option is used.
     *
     * @var \Psr\Http\Message\StreamInterface
     */
    protected $stream;

    /**
     * Uri instance
     *
     * @var \Psr\Http\Message\UriInterface
     */
    protected $uri;

    /**
     * Instance of a Session object relative to this request
     *
     * @var \Cake\Http\Session
     */
    protected $session;

    /**
     * Store the additional attributes attached to the request.
     *
     * @var array
     */
    protected $attributes = [];

    /**
     * A list of propertes that emulated by the PSR7 attribute methods.
     *
     * @var array
     */
    protected $emulatedAttributes = ['file.php', 'file.php', 'file.php', 'file.php', 'file.php'];

    /**
     * Array of Psr\Http\Message\UploadedFileInterface objects.
     *
     * @var array
     */
    protected $uploadedFiles = [];

    /**
     * The HTTP protocol version used.
     *
     * @var string|null
     */
    protected $protocol;

    /**
     * The request target if overridden
     *
     * @var string|null
     */
    protected $requestTarget;

    /**
     * List of deprecated properties that have backwards
     * compatibility offered through magic methods.
     *
     * @var array
     */
    private $deprecatedProperties = [
        'file.php' => ['file.php' => 'file.php', 'file.php' => 'file.php'],
        'file.php' => ['file.php' => 'file.php', 'file.php' => 'file.php'],
        'file.php' => ['file.php' => 'file.php', 'file.php' => 'file.php'],
        'file.php' => ['file.php' => 'file.php', 'file.php' => 'file.php'],
        'file.php' => ['file.php' => 'file.php', 'file.php' => 'file.php'],
        'file.php' => ['file.php' => 'file.php', 'file.php' => 'file.php'],
        'file.php' => ['file.php' => 'file.php', 'file.php' => 'file.php'],
        'file.php' => ['file.php' => 'file.php', 'file.php' => 'file.php'],
    ];

    /**
     * Whether to merge file uploads as objects (`true`) or arrays (`false`).
     *
     * @var bool
     */
    private $mergeFilesAsObjects = false;

    /**
     * Wrapper method to create a new request from PHP superglobals.
     *
     * Uses the $_GET, $_POST, $_FILES, $_COOKIE, $_SERVER, $_ENV and php://input data to construct
     * the request.
     *
     * @return self
     * @deprecated 3.4.0 Use `Cake\Http\ServerRequestFactory` instead.
     */
    public static function createFromGlobals()
    {
        deprecationWarning(
            'file.php' .
            'file.php'
        );

        return ServerRequestFactory::fromGlobals();
    }

    /**
     * Create a new request object.
     *
     * You can supply the data as either an array or as a string. If you use
     * a string you can only supply the URL for the request. Using an array will
     * let you provide the following keys:
     *
     * - `post` POST data or non query string data
     * - `query` Additional data from the query string.
     * - `files` Uploaded file data formatted like $_FILES.
     * - `cookies` Cookies for this request.
     * - `environment` $_SERVER and $_ENV data.
     * - `url` The URL without the base path for the request.
     * - `uri` The PSR7 UriInterface object. If null, one will be created.
     * - `base` The base URL for the request.
     * - `webroot` The webroot directory for the request.
     * - `input` The data that would come from php://input this is useful for simulating
     *   requests with put, patch or delete data.
     * - `session` An instance of a Session object
     * - `mergeFilesAsObjects` Whether to merge file uploads as objects (`true`) or arrays (`false`).
     *
     * @param string|array $config An array of request data to create a request with.
     *   The string version of this argument is *deprecated* and will be removed in 4.0.0
     */
    public function __construct($config = [])
    {
        if (is_string($config)) {
            $config = ['file.php' => $config];
        }
        $config += [
            'file.php' => $this->params,
            'file.php' => [],
            'file.php' => [],
            'file.php' => [],
            'file.php' => [],
            'file.php' => [],
            'file.php' => 'file.php',
            'file.php' => null,
            'file.php' => 'file.php',
            'file.php' => 'file.php',
            'file.php' => null,
            'file.php' => false,
        ];

        $this->_setConfig($config);
    }

    /**
     * Process the config/settings data into properties.
     *
     * @param array $config The config data to use.
     * @return void
     */
    protected function _setConfig($config)
    {
        if (strlen($config['file.php']) > 1 && $config['file.php'][0] === 'file.php') {
            $config['file.php'] = substr($config['file.php'], 1);
        }

        if (empty($config['file.php'])) {
            $config['file.php'] = new Session([
                'file.php' => $config['file.php'],
            ]);
        }

        $this->_environment = $config['file.php'];
        $this->cookies = $config['file.php'];

        if (isset($config['file.php']) && $config['file.php'] instanceof UriInterface) {
            $uri = $config['file.php'];
        } else {
            $uri = ServerRequestFactory::createUri($config['file.php']);
        }

        // Extract a query string from config[url] if present.
        // This is required for backwards compatibility and keeping
        // UriInterface implementations happy.
        $querystr = 'file.php';
        if (strpos($config['file.php'], 'file.php') !== false) {
            list($config['file.php'], $querystr) = explode('file.php', $config['file.php']);
        }
        if (strlen($config['file.php'])) {
            $uri = $uri->withPath('file.php' . $config['file.php']);
        }
        if (strlen($querystr)) {
            $uri = $uri->withQuery($querystr);
        }

        $this->uri = $uri;
        $this->base = $config['file.php'];
        $this->webroot = $config['file.php'];

        $this->url = substr($uri->getPath(), 1);
        $this->here = $this->base . 'file.php' . $this->url;

        if (isset($config['file.php'])) {
            $stream = new Stream('file.php', 'file.php');
            $stream->write($config['file.php']);
            $stream->rewind();
        } else {
            $stream = new PhpInputStream();
        }
        $this->stream = $stream;

        $this->mergeFilesAsObjects = $config['file.php'];

        $config['file.php'] = $this->_processPost($config['file.php']);
        $this->data = $this->_processFiles($config['file.php'], $config['file.php']);
        $this->query = $this->_processGet($config['file.php'], $querystr);
        $this->params = $config['file.php'];
        $this->session = $config['file.php'];
    }

    /**
     * Sets the REQUEST_METHOD environment variable based on the simulated _method
     * HTTP override value. The 'file.php' is also preserved, if you
     * want the read the non-simulated HTTP method the client used.
     *
     * @param array $data Array of post data.
     * @return array
     */
    protected function _processPost($data)
    {
        $method = $this->getEnv('file.php');
        $override = false;

        if (
            in_array($method, ['file.php', 'file.php', 'file.php'], true) &&
            strpos($this->contentType(), 'file.php') === 0
        ) {
            $data = $this->input();
            parse_str($data, $data);
        }
        if ($this->hasHeader('file.php')) {
            $data['file.php'] = $this->getHeaderLine('file.php');
            $override = true;
        }
        $this->_environment['file.php'] = $method;
        if (isset($data['file.php'])) {
            $this->_environment['file.php'] = $data['file.php'];
            unset($data['file.php']);
            $override = true;
        }

        if ($override && !in_array($this->_environment['file.php'], ['file.php', 'file.php', 'file.php', 'file.php'], true)) {
            $data = [];
        }

        return $data;
    }

    /**
     * Process the GET parameters and move things into the object.
     *
     * @param array $query The array to which the parsed keys/values are being added.
     * @param string $queryString A query string from the URL if provided
     * @return array An array containing the parsed query string as keys/values.
     */
    protected function _processGet($query, $queryString = 'file.php')
    {
        $unsetUrl = 'file.php' . str_replace(['file.php', 'file.php'], 'file.php', urldecode($this->url));
        unset($query[$unsetUrl], $query[$this->base . $unsetUrl]);
        if (strlen($queryString)) {
            parse_str($queryString, $queryArgs);
            $query += $queryArgs;
        }

        return $query;
    }

    /**
     * Process uploaded files and move things onto the post data.
     *
     * @param array $post Post data to merge files onto.
     * @param array $files Uploaded files to merge in.
     * @return array merged post + file data.
     */
    protected function _processFiles($post, $files)
    {
        if (
            empty($files) ||
            !is_array($files)
        ) {
            return $post;
        }
        $fileData = [];
        foreach ($files as $key => $value) {
            if ($value instanceof UploadedFileInterface) {
                $fileData[$key] = $value;
                continue;
            }

            if (is_array($value) && isset($value['file.php'])) {
                $fileData[$key] = $this->_createUploadedFile($value);
                continue;
            }

            throw new InvalidArgumentException(sprintf(
                'file.php',
                json_encode($value)
            ));
        }
        $this->uploadedFiles = $fileData;

        if ($this->mergeFilesAsObjects) {
            return Hash::merge($post, $fileData);
        }

        // Make a flat map that can be inserted into $post for BC.
        $fileMap = Hash::flatten($fileData);
        foreach ($fileMap as $key => $file) {
            $error = $file->getError();
            $tmpName = 'file.php';
            if ($error === UPLOAD_ERR_OK) {
                $tmpName = $file->getStream()->getMetadata('file.php');
            }
            $post = Hash::insert($post, $key, [
                'file.php' => $tmpName,
                'file.php' => $error,
                'file.php' => $file->getClientFilename(),
                'file.php' => $file->getClientMediaType(),
                'file.php' => $file->getSize(),
            ]);
        }

        return $post;
    }

    /**
     * Create an UploadedFile instance from a $_FILES array.
     *
     * If the value represents an array of values, this method will
     * recursively process the data.
     *
     * @param array $value $_FILES struct
     * @return array|UploadedFileInterface
     */
    protected function _createUploadedFile(array $value)
    {
        if (is_array($value['file.php'])) {
            return $this->_normalizeNestedFiles($value);
        }

        return new UploadedFile(
            $value['file.php'],
            $value['file.php'],
            $value['file.php'],
            $value['file.php'],
            $value['file.php']
        );
    }

    /**
     * Normalize an array of file specifications.
     *
     * Loops through all nested files and returns a normalized array of
     * UploadedFileInterface instances.
     *
     * @param array $files The file data to normalize & convert.
     * @return array An array of UploadedFileInterface objects.
     */
    protected function _normalizeNestedFiles(array $files = [])
    {
        $normalizedFiles = [];
        foreach (array_keys($files['file.php']) as $key) {
            $spec = [
                'file.php' => $files['file.php'][$key],
                'file.php' => $files['file.php'][$key],
                'file.php' => $files['file.php'][$key],
                'file.php' => $files['file.php'][$key],
                'file.php' => $files['file.php'][$key],
            ];
            $normalizedFiles[$key] = $this->_createUploadedFile($spec);
        }

        return $normalizedFiles;
    }

    /**
     * Get the content type used in this request.
     *
     * @return string
     */
    public function contentType()
    {
        $type = $this->getEnv('file.php');
        if ($type) {
            return $type;
        }

        return $this->getEnv('file.php');
    }

    /**
     * Returns the instance of the Session object for this request
     *
     * @return \Cake\Http\Session
     */
    public function getSession()
    {
        return $this->session;
    }

    /**
     * Returns the instance of the Session object for this request
     *
     * If a session object is passed as first argument it will be set as
     * the session to use for this request
     *
     * @deprecated 3.5.0 Use getSession() instead. The setter part will be removed.
     * @param \Cake\Http\Session|null $session the session object to use
     * @return \Cake\Http\Session
     */
    public function session(Session $session = null)
    {
        deprecationWarning(
            'file.php' .
            'file.php'
        );

        if ($session === null) {
            return $this->session;
        }

        return $this->session = $session;
    }

    /**
     * Get the IP the client is using, or says they are using.
     *
     * @return string The client IP.
     */
    public function clientIp()
    {
        if ($this->trustProxy && $this->getEnv('file.php')) {
            $addresses = array_map('file.php', explode('file.php', $this->getEnv('file.php')));
            $trusted = (count($this->trustedProxies) > 0);
            $n = count($addresses);

            if ($trusted) {
                $trusted = array_diff($addresses, $this->trustedProxies);
                $trusted = (count($trusted) === 1);
            }

            if ($trusted) {
                return $addresses[0];
            }

            return $addresses[$n - 1];
        }

        if ($this->trustProxy && $this->getEnv('file.php')) {
            $ipaddr = $this->getEnv('file.php');
        } elseif ($this->trustProxy && $this->getEnv('file.php')) {
            $ipaddr = $this->getEnv('file.php');
        } else {
            $ipaddr = $this->getEnv('file.php');
        }

        return trim($ipaddr);
    }

    /**
     * register trusted proxies
     *
     * @param string[] $proxies ips list of trusted proxies
     * @return void
     */
    public function setTrustedProxies(array $proxies)
    {
        $this->trustedProxies = $proxies;
        $this->trustProxy = true;
    }

    /**
     * Get trusted proxies
     *
     * @return string[]
     */
    public function getTrustedProxies()
    {
        return $this->trustedProxies;
    }

    /**
     * Returns the referer that referred this request.
     *
     * @param bool $local Attempt to return a local address.
     *   Local addresses do not contain hostnames.
     * @return string The referring address for this request.
     */
    public function referer($local = false)
    {
        $ref = $this->getEnv('file.php');

        $base = Configure::read('file.php') . $this->webroot;
        if (!empty($ref) && !empty($base)) {
            if ($local && strpos($ref, $base) === 0) {
                $ref = substr($ref, strlen($base));
                if (!strlen($ref) || strpos($ref, 'file.php') === 0) {
                    $ref = 'file.php';
                }
                if ($ref[0] !== 'file.php') {
                    $ref = 'file.php' . $ref;
                }

                return $ref;
            }
            if (!$local) {
                return $ref;
            }
        }

        return 'file.php';
    }

    /**
     * Missing method handler, handles wrapping older style isAjax() type methods
     *
     * @param string $name The method called
     * @param array $params Array of parameters for the method call
     * @return mixed
     * @throws \BadMethodCallException when an invalid method is called.
     */
    public function __call($name, $params)
    {
        if (strpos($name, 'file.php') === 0) {
            $type = strtolower(substr($name, 2));

            array_unshift($params, $type);

            return $this->is(...$params);
        }
        throw new BadMethodCallException(sprintf('file.php', $name));
    }

    /**
     * Magic set method allows backward compatibility for former public properties
     *
     * @param string $name The property being accessed.
     * @param mixed $value The property value.
     * @return mixed Either the value of the parameter or null.
     * @deprecated 3.6.0 Public properties will be removed in 4.0.0.
     *   Use appropriate setters instead.
     */
    public function __set($name, $value)
    {
        if (isset($this->deprecatedProperties[$name])) {
            $method = $this->deprecatedProperties[$name]['file.php'];
            deprecationWarning(
                "Setting {$name} as a property will be removed in 4.0.0. " .
                "Use {$method} instead."
            );

            return $this->{$name} = $value;
        }
        throw new BadMethodCallException("Cannot set {$name} it is not a known property.");
    }

    /**
     * Magic get method allows access to parsed routing parameters directly on the object.
     *
     * Allows access to `$this->params['file.php']` via `$this->controller`
     *
     * @param string $name The property being accessed.
     * @return mixed Either the value of the parameter or null.
     * @deprecated 3.4.0 Accessing routing parameters through __get will removed in 4.0.0.
     *   Use getParam() instead.
     */
    public function &__get($name)
    {
        if (isset($this->deprecatedProperties[$name])) {
            $method = $this->deprecatedProperties[$name]['file.php'];
            deprecationWarning(
                "Accessing `{$name}` as a property will be removed in 4.0.0. " .
                "Use request->{$method} instead."
            );

            return $this->{$name};
        }

        deprecationWarning(sprintf(
            'file.php' .
            'file.php',
            $name
        ));

        if (isset($this->params[$name])) {
            return $this->params[$name];
        }
        $value = null;

        return $value;
    }

    /**
     * Magic isset method allows isset/empty checks
     * on routing parameters.
     *
     * @param string $name The property being accessed.
     * @return bool Existence
     * @deprecated 3.4.0 Accessing routing parameters through __isset will removed in 4.0.0.
     *   Use getParam() instead.
     */
    public function __isset($name)
    {
        if (isset($this->deprecatedProperties[$name])) {
            $method = $this->deprecatedProperties[$name]['file.php'];
            deprecationWarning(
                "Accessing {$name} as a property will be removed in 4.0.0. " .
                "Use {$method} instead."
            );

            return isset($this->{$name});
        }

        deprecationWarning(
            'file.php' .
            'file.php'
        );

        return isset($this->params[$name]);
    }

    /**
     * Check whether or not a Request is a certain type.
     *
     * Uses the built in detection rules as well as additional rules
     * defined with Cake\Http\ServerRequest::addDetector(). Any detector can be called
     * as `is($type)` or `is$Type()`.
     *
     * @param string|string[] $type The type of request you want to check. If an array
     *   this method will return true if the request matches any type.
     * @param mixed ...$args List of arguments
     * @return bool Whether or not the request is the type you are checking.
     */
    public function is($type, ...$args)
    {
        if (is_array($type)) {
            foreach ($type as $_type) {
                if ($this->is($_type)) {
                    return true;
                }
            }

            return false;
        }

        $type = strtolower($type);
        if (!isset(static::$_detectors[$type])) {
            return false;
        }
        if ($args) {
            return $this->_is($type, $args);
        }
        if (!isset($this->_detectorCache[$type])) {
            $this->_detectorCache[$type] = $this->_is($type, $args);
        }

        return $this->_detectorCache[$type];
    }

    /**
     * Clears the instance detector cache, used by the is() function
     *
     * @return void
     */
    public function clearDetectorCache()
    {
        $this->_detectorCache = [];
    }

    /**
     * Worker for the public is() function
     *
     * @param string $type The type of request you want to check.
     * @param array $args Array of custom detector arguments.
     * @return bool Whether or not the request is the type you are checking.
     */
    protected function _is($type, $args)
    {
        $detect = static::$_detectors[$type];
        if (is_callable($detect)) {
            array_unshift($args, $this);

            return $detect(...$args);
        }
        if (isset($detect['file.php']) && $this->_environmentDetector($detect)) {
            return true;
        }
        if (isset($detect['file.php']) && $this->_headerDetector($detect)) {
            return true;
        }
        if (isset($detect['file.php']) && $this->_acceptHeaderDetector($detect)) {
            return true;
        }
        if (isset($detect['file.php']) && $this->_paramDetector($detect)) {
            return true;
        }

        return false;
    }

    /**
     * Detects if a specific accept header is present.
     *
     * @param array $detect Detector options array.
     * @return bool Whether or not the request is the type you are checking.
     */
    protected function _acceptHeaderDetector($detect)
    {
        $acceptHeaders = explode('file.php', $this->getEnv('file.php'));
        foreach ($detect['file.php'] as $header) {
            if (in_array($header, $acceptHeaders)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Detects if a specific header is present.
     *
     * @param array $detect Detector options array.
     * @return bool Whether or not the request is the type you are checking.
     */
    protected function _headerDetector($detect)
    {
        foreach ($detect['file.php'] as $header => $value) {
            $header = $this->getEnv('file.php' . $header);
            if ($header !== null) {
                if (!is_string($value) && !is_bool($value) && is_callable($value)) {
                    return call_user_func($value, $header);
                }

                return ($header === $value);
            }
        }

        return false;
    }

    /**
     * Detects if a specific request parameter is present.
     *
     * @param array $detect Detector options array.
     * @return bool Whether or not the request is the type you are checking.
     */
    protected function _paramDetector($detect)
    {
        $key = $detect['file.php'];
        if (isset($detect['file.php'])) {
            $value = $detect['file.php'];

            return isset($this->params[$key]) ? $this->params[$key] == $value : false;
        }
        if (isset($detect['file.php'])) {
            return isset($this->params[$key]) ? in_array($this->params[$key], $detect['file.php']) : false;
        }

        return false;
    }

    /**
     * Detects if a specific environment variable is present.
     *
     * @param array $detect Detector options array.
     * @return bool Whether or not the request is the type you are checking.
     */
    protected function _environmentDetector($detect)
    {
        if (isset($detect['file.php'])) {
            if (isset($detect['file.php'])) {
                return $this->getEnv($detect['file.php']) == $detect['file.php'];
            }
            if (isset($detect['file.php'])) {
                return (bool)preg_match($detect['file.php'], $this->getEnv($detect['file.php']));
            }
            if (isset($detect['file.php'])) {
                $pattern = 'file.php' . implode('file.php', $detect['file.php']) . 'file.php';

                return (bool)preg_match($pattern, $this->getEnv($detect['file.php']));
            }
        }

        return false;
    }

    /**
     * Check that a request matches all the given types.
     *
     * Allows you to test multiple types and union the results.
     * See Request::is() for how to add additional types and the
     * built-in types.
     *
     * @param string[] $types The types to check.
     * @return bool Success.
     * @see \Cake\Http\ServerRequest::is()
     */
    public function isAll(array $types)
    {
        foreach ($types as $type) {
            if (!$this->is($type)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Add a new detector to the list of detectors that a request can use.
     * There are several different types of detectors that can be set.
     *
     * ### Callback comparison
     *
     * Callback detectors allow you to provide a callable to handle the check.
     * The callback will receive the request object as its only parameter.
     *
     * ```
     * addDetector('file.php', function ($request) { //Return a boolean });
     * ```
     *
     * ### Environment value comparison
     *
     * An environment value comparison, compares a value fetched from `env()` to a known value
     * the environment value is equality checked against the provided value.
     *
     * ```
     * addDetector('file.php', ['file.php' => 'file.php', 'file.php' => 'file.php']);
     * ```
     *
     * ### Request parameter comparison
     *
     * Allows for custom detectors on the request parameters.
     *
     * ```
     * addDetector('file.php', ['file.php' => 'file.php', 'file.php' => 1]);
     * ```
     *
     * ### Accept comparison
     *
     * Allows for detector to compare against Accept header value.
     *
     * ```
     * addDetector('file.php', ['file.php' => 'file.php']);
     * ```
     *
     * ### Header comparison
     *
     * Allows for one or more headers to be compared.
     *
     * ```
     * addDetector('file.php', ['file.php' => ['file.php' => 1]);
     * ```
     *
     * The `param`, `env` and comparison types allow the following
     * value comparison options:
     *
     * ### Pattern value comparison
     *
     * Pattern value comparison allows you to compare a value fetched from `env()` to a regular expression.
     *
     * ```
     * addDetector('file.php', ['file.php' => 'file.php', 'file.php' => 'file.php']);
     * ```
     *
     * ### Option based comparison
     *
     * Option based comparisons use a list of options to create a regular expression. Subsequent calls
     * to add an already defined options detector will merge the options.
     *
     * ```
     * addDetector('file.php', ['file.php' => 'file.php', 'file.php' => ['file.php']]);
     * ```
     *
     * You can also make compare against multiple values
     * using the `options` key. This is useful when you want to check
     * if a request value is in a list of options.
     *
     * `addDetector('file.php', ['file.php' => 'file.php', 'file.php' => ['file.php', 'file.php']]`
     *
     * @param string $name The name of the detector.
     * @param callable|array $callable A callable or options array for the detector definition.
     * @return void
     */
    public static function addDetector($name, $callable)
    {
        $name = strtolower($name);
        if (is_callable($callable)) {
            static::$_detectors[$name] = $callable;

            return;
        }
        if (isset(static::$_detectors[$name], $callable['file.php'])) {
            $callable = Hash::merge(static::$_detectors[$name], $callable);
        }
        static::$_detectors[$name] = $callable;
    }

    /**
     * Add parameters to the request'file.php'params'file.php'ServerRequest::addParams() is deprecated. 'file.php'Use `withParam()` or `withAttribute("params", $params)` instead.'file.php' paths vars. This will overwrite any existing paths.
     * Provides an easy way to modify, here, webroot and base.
     *
     * @param array $paths Array of paths to merge in
     * @return $this The current object, you can chain this method.
     * @deprecated 3.6.0 Mutating a request in place is deprecated. Use `withAttribute()` to modify paths instead.
     */
    public function addPaths(array $paths)
    {
        deprecationWarning(
            'file.php' .
            'file.php'
        );
        foreach (['file.php', 'file.php', 'file.php'] as $element) {
            if (isset($paths[$element])) {
                $this->{$element} = $paths[$element];
            }
        }

        return $this;
    }

    /**
     * Get the value of the current requests URL. Will include the query string arguments.
     *
     * @param bool $base Include the base path, set to false to trim the base path off.
     * @return string The current request URL including query string args.
     * @deprecated 3.4.0 This method will be removed in 4.0.0. You should use getRequestTarget() instead.
     */
    public function here($base = true)
    {
        deprecationWarning(
            'file.php'
        );

        $url = $this->here;
        if (!empty($this->query)) {
            $url .= 'file.php' . http_build_query($this->query, null, 'file.php');
        }
        if (!$base) {
            $url = preg_replace('file.php' . preg_quote($this->base, 'file.php') . 'file.php', 'file.php', $url, 1);
        }

        return $url;
    }

    /**
     * Normalize a header name into the SERVER version.
     *
     * @param string $name The header name.
     * @return string The normalized header name.
     */
    protected function normalizeHeaderName($name)
    {
        $name = str_replace('file.php', 'file.php', strtoupper($name));
        if (!in_array($name, ['file.php', 'file.php'], true)) {
            $name = 'file.php' . $name;
        }

        return $name;
    }

    /**
     * Read an HTTP header from the Request information.
     *
     * If the header is not defined in the request, this method
     * will fallback to reading data from $_SERVER and $_ENV.
     * This fallback behavior is deprecated, and will be removed in 4.0.0
     *
     * @param string $name Name of the header you want.
     * @return string|null Either null on no header being set or the value of the header.
     * @deprecated 4.0.0 The automatic fallback to env() will be removed in 4.0.0, see getHeader()
     */
    public function header($name)
    {
        deprecationWarning(
            'file.php' .
            'file.php'
        );

        $name = $this->normalizeHeaderName($name);

        return $this->getEnv($name);
    }

    /**
     * Get all headers in the request.
     *
     * Returns an associative array where the header names are
     * the keys and the values are a list of header values.
     *
     * While header names are not case-sensitive, getHeaders() will normalize
     * the headers.
     *
     * @return array An associative array of headers and their values.
     * @link http://www.php-fig.org/psr/psr-7/ This method is part of the PSR-7 server request interface.
     */
    public function getHeaders()
    {
        $headers = [];
        foreach ($this->_environment as $key => $value) {
            $name = null;
            if (strpos($key, 'file.php') === 0) {
                $name = substr($key, 5);
            }
            if (strpos($key, 'file.php') === 0) {
                $name = $key;
            }
            if ($name !== null) {
                $name = str_replace('file.php', 'file.php', strtolower($name));
                $name = str_replace('file.php', 'file.php', ucwords($name));
                $headers[$name] = (array)$value;
            }
        }

        return $headers;
    }

    /**
     * Check if a header is set in the request.
     *
     * @param string $name The header you want to get (case-insensitive)
     * @return bool Whether or not the header is defined.
     * @link http://www.php-fig.org/psr/psr-7/ This method is part of the PSR-7 server request interface.
     */
    public function hasHeader($name)
    {
        $name = $this->normalizeHeaderName($name);

        return isset($this->_environment[$name]);
    }

    /**
     * Get a single header from the request.
     *
     * Return the header value as an array. If the header
     * is not present an empty array will be returned.
     *
     * @param string $name The header you want to get (case-insensitive)
     * @return array An associative array of headers and their values.
     *   If the header doesn'file.php', 'file.php'ServerRequest::method() is deprecated. 'file.php'This method will be removed in 4.0.0. Use getMethod() instead.'file.php'REQUEST_METHOD'file.php'REQUEST_METHOD'file.php'/^[!#$%&\'file.php', $method)
        ) {
            throw new InvalidArgumentException(sprintf(
                'file.php',
                $method
            ));
        }
        $new->_environment['file.php'] = $method;

        return $new;
    }

    /**
     * Get all the server environment parameters.
     *
     * Read all of the 'file.php' or 'file.php' data that was
     * used to create this request.
     *
     * @return array
     * @link http://www.php-fig.org/psr/psr-7/ This method is part of the PSR-7 server request interface.
     */
    public function getServerParams()
    {
        return $this->_environment;
    }

    /**
     * Get all the query parameters in accordance to the PSR-7 specifications. To read specific query values
     * use the alternative getQuery() method.
     *
     * @return array
     * @link http://www.php-fig.org/psr/psr-7/ This method is part of the PSR-7 server request interface.
     */
    public function getQueryParams()
    {
        return $this->query;
    }

    /**
     * Update the query string data and get a new instance.
     *
     * @param array $query The query string data to use
     * @return static A new instance with the updated query string data.
     * @link http://www.php-fig.org/psr/psr-7/ This method is part of the PSR-7 server request interface.
     */
    public function withQueryParams(array $query)
    {
        $new = clone $this;
        $new->query = $query;

        return $new;
    }

    /**
     * Get the host that the request was handled on.
     *
     * @return string
     */
    public function host()
    {
        if ($this->trustProxy && $this->getEnv('file.php')) {
            return $this->getEnv('file.php');
        }

        return $this->getEnv('file.php');
    }

    /**
     * Get the port the request was handled on.
     *
     * @return string
     */
    public function port()
    {
        if ($this->trustProxy && $this->getEnv('file.php')) {
            return $this->getEnv('file.php');
        }

        return $this->getEnv('file.php');
    }

    /**
     * Get the current url scheme used for the request.
     *
     * e.g. 'file.php', or 'file.php'
     *
     * @return string The scheme used for the request.
     */
    public function scheme()
    {
        if ($this->trustProxy && $this->getEnv('file.php')) {
            return $this->getEnv('file.php');
        }

        return $this->getEnv('file.php') ? 'file.php' : 'file.php';
    }

    /**
     * Get the domain name and include $tldLength segments of the tld.
     *
     * @param int $tldLength Number of segments your tld contains. For example: `example.com` contains 1 tld.
     *   While `example.co.uk` contains 2.
     * @return string Domain name without subdomains.
     */
    public function domain($tldLength = 1)
    {
        $segments = explode('file.php', $this->host());
        $domain = array_slice($segments, -1 * ($tldLength + 1));

        return implode('file.php', $domain);
    }

    /**
     * Get the subdomains for a host.
     *
     * @param int $tldLength Number of segments your tld contains. For example: `example.com` contains 1 tld.
     *   While `example.co.uk` contains 2.
     * @return array An array of subdomains.
     */
    public function subdomains($tldLength = 1)
    {
        $segments = explode('file.php', $this->host());

        return array_slice($segments, 0, -1 * ($tldLength + 1));
    }

    /**
     * Find out which content types the client accepts or check if they accept a
     * particular type of content.
     *
     * #### Get all types:
     *
     * ```
     * $this->request->accepts();
     * ```
     *
     * #### Check for a single type:
     *
     * ```
     * $this->request->accepts('file.php');
     * ```
     *
     * This method will order the returned content types by the preference values indicated
     * by the client.
     *
     * @param string|null $type The content type to check for. Leave null to get all types a client accepts.
     * @return array|bool Either an array of all the types the client accepts or a boolean if they accept the
     *   provided type.
     */
    public function accepts($type = null)
    {
        $raw = $this->parseAccept();
        $accept = [];
        foreach ($raw as $types) {
            $accept = array_merge($accept, $types);
        }
        if ($type === null) {
            return $accept;
        }

        return in_array($type, $accept, true);
    }

    /**
     * Parse the HTTP_ACCEPT header and return a sorted array with content types
     * as the keys, and pref values as the values.
     *
     * Generally you want to use Cake\Http\ServerRequest::accept() to get a simple list
     * of the accepted content types.
     *
     * @return array An array of prefValue => [content/types]
     */
    public function parseAccept()
    {
        return $this->_parseAcceptWithQualifier($this->getHeaderLine('file.php'));
    }

    /**
     * Get the languages accepted by the client, or check if a specific language is accepted.
     *
     * Get the list of accepted languages:
     *
     * ``` \Cake\Http\ServerRequest::acceptLanguage(); ```
     *
     * Check if a specific language is accepted:
     *
     * ``` \Cake\Http\ServerRequest::acceptLanguage('file.php'); ```
     *
     * @param string|null $language The language to test.
     * @return array|bool If a $language is provided, a boolean. Otherwise the array of accepted languages.
     */
    public function acceptLanguage($language = null)
    {
        $raw = $this->_parseAcceptWithQualifier($this->getHeaderLine('file.php'));
        $accept = [];
        foreach ($raw as $languages) {
            foreach ($languages as &$lang) {
                if (strpos($lang, 'file.php')) {
                    $lang = str_replace('file.php', 'file.php', $lang);
                }
                $lang = strtolower($lang);
            }
            $accept = array_merge($accept, $languages);
        }
        if ($language === null) {
            return $accept;
        }

        return in_array(strtolower($language), $accept, true);
    }

    /**
     * Parse Accept* headers with qualifier options.
     *
     * Only qualifiers will be extracted, any other accept extensions will be
     * discarded as they are not frequently used.
     *
     * @param string $header Header to parse.
     * @return array
     */
    protected function _parseAcceptWithQualifier($header)
    {
        $accept = [];
        $headers = explode('file.php', $header);
        foreach (array_filter($headers) as $value) {
            $prefValue = 'file.php';
            $value = trim($value);

            $semiPos = strpos($value, 'file.php');
            if ($semiPos !== false) {
                $params = explode('file.php', $value);
                $value = trim($params[0]);
                foreach ($params as $param) {
                    $qPos = strpos($param, 'file.php');
                    if ($qPos !== false) {
                        $prefValue = substr($param, $qPos + 2);
                    }
                }
            }

            if (!isset($accept[$prefValue])) {
                $accept[$prefValue] = [];
            }
            if ($prefValue) {
                $accept[$prefValue][] = $value;
            }
        }
        krsort($accept);

        return $accept;
    }

    /**
     * Provides a read accessor for `$this->query`.
     * Allows you to use a `Hash::get()` compatible syntax for reading post data.
     *
     * @param string|null $name Query string variable name or null to read all.
     * @return string|array|null The value being read
     * @deprecated 3.4.0 Use getQuery() or the PSR-7 getQueryParams() and withQueryParams() methods instead.
     */
    public function query($name = null)
    {
        deprecationWarning(
            'file.php' .
            'file.php'
        );

        if ($name === null) {
            return $this->query;
        }

        return $this->getQuery($name);
    }

    /**
     * Read a specific query value or dotted path.
     *
     * Developers are encouraged to use getQueryParams() when possible as it is PSR-7 compliant, and this method
     * is not.
     *
     * ### PSR-7 Alternative
     *
     * ```
     * $value = Hash::get($request->getQueryParams(), 'file.php', null);
     * ```
     *
     * @param string|null $name The name or dotted path to the query param or null to read all.
     * @param mixed $default The default value if the named parameter is not set, and $name is not null.
     * @return array|string|null Query data.
     * @see ServerRequest::getQueryParams()
     */
    public function getQuery($name = null, $default = null)
    {
        if ($name === null) {
            return $this->query;
        }

        return Hash::get($this->query, $name, $default);
    }

    /**
     * Provides a read/write accessor for `$this->data`.
     * Allows you to use a `Hash::get()` compatible syntax for reading post data.
     *
     * ### Reading values.
     *
     * ```
     * $request->data('file.php');
     * ```
     *
     * When reading values you will get `null` for keys/values that do not exist.
     *
     * ### Writing values
     *
     * ```
     * $request->data('file.php', 'file.php');
     * ```
     *
     * You can write to any value, even paths/keys that do not exist, and the arrays
     * will be created for you.
     *
     * @param string|null $name Dot separated name of the value to read/write
     * @param mixed ...$args The data to set (deprecated)
     * @return mixed|$this Either the value being read, or this so you can chain consecutive writes.
     * @deprecated 3.4.0 Use withData() and getData() or getParsedBody() instead.
     */
    public function data($name = null, ...$args)
    {
        deprecationWarning(
            'file.php' .
            'file.php'
        );

        if (count($args) === 1) {
            $this->data = Hash::insert($this->data, $name, $args[0]);

            return $this;
        }
        if ($name !== null) {
            return Hash::get($this->data, $name);
        }

        return $this->data;
    }

    /**
     * Provides a safe accessor for request data. Allows
     * you to use Hash::get() compatible paths.
     *
     * ### Reading values.
     *
     * ```
     * // get all data
     * $request->getData();
     *
     * // Read a specific field.
     * $request->getData('file.php');
     *
     * // With a default value.
     * $request->getData('file.php', 'file.php');
     * ```
     *
     * When reading values you will get `null` for keys/values that do not exist.
     *
     * @param string|null $name Dot separated name of the value to read. Or null to read all data.
     * @param mixed $default The default data.
     * @return array|string|null The value being read.
     */
    public function getData($name = null, $default = null)
    {
        if ($name === null) {
            return $this->data;
        }
        if (!is_array($this->data) && $name) {
            return $default;
        }

        return Hash::get($this->data, $name, $default);
    }

    /**
     * Safely access the values in $this->params.
     *
     * @param string $name The name of the parameter to get.
     * @param mixed ...$args Value to set (deprecated).
     * @return mixed|$this The value of the provided parameter. Will
     *   return false if the parameter doesn'file.php'ServerRequest::param() is deprecated. 'file.php'Use getParam() and withParam() instead.'file.php'json_decode'file.php'Xml::build'file.php'return'file.php'DOMDocument'file.php's cookie data.
     *
     * @param string $key The key you want to read.
     * @return string|null Either the cookie value, or null if the value doesn'file.php'ServerRequest::cookie() is deprecated. 'file.php'Use getCookie() instead.'file.php's cookie data.
     *
     * @param string $key The key or dotted path you want to read.
     * @param string $default The default value if the cookie is not set.
     * @return string|array|null Either the cookie value, or null if the value doesn'file.php's cookies
     *
     * The CookieCollection lets you interact with request cookies using
     * `\Cake\Http\Cookie\Cookie` objects and can make converting request cookies
     * into response cookies easier.
     *
     * This method will create a new cookie collection each time it is called.
     * This is an optimization that allows fewer objects to be allocated until
     * the more complex CookieCollection is needed. In general you should prefer
     * `getCookie()` and `getCookieParams()` over this method. Using a CookieCollection
     * is ideal if your cookies contain complex JSON encoded data.
     *
     * @return \Cake\Http\Cookie\CookieCollection
     */
    public function getCookieCollection()
    {
        return CookieCollection::createFromServerRequest($this);
    }

    /**
     * Replace the cookies in the request with those contained in
     * the provided CookieCollection.
     *
     * @param \Cake\Http\Cookie\CookieCollection $cookies The cookie collection
     * @return static
     */
    public function withCookieCollection(CookieCollection $cookies)
    {
        $new = clone $this;
        $values = [];
        foreach ($cookies as $cookie) {
            $values[$cookie->getName()] = $cookie->getValue();
        }
        $new->cookies = $values;

        return $new;
    }

    /**
     * Get all the cookie data from the request.
     *
     * @return array An array of cookie data.
     */
    public function getCookieParams()
    {
        return $this->cookies;
    }

    /**
     * Replace the cookies and get a new request instance.
     *
     * @param array $cookies The new cookie data to use.
     * @return static
     */
    public function withCookieParams(array $cookies)
    {
        $new = clone $this;
        $new->cookies = $cookies;

        return $new;
    }

    /**
     * Get the parsed request body data.
     *
     * If the request Content-Type is either application/x-www-form-urlencoded
     * or multipart/form-data, and the request method is POST, this will be the
     * post data. For other content types, it may be the deserialized request
     * body.
     *
     * @return object|array|null The deserialized body parameters, if any.
     *     These will typically be an array or object.
     */
    public function getParsedBody()
    {
        return $this->data;
    }

    /**
     * Update the parsed body and get a new instance.
     *
     * @param object|array|null $data The deserialized body data. This will
     *     typically be in an array or object.
     * @return static
     */
    public function withParsedBody($data)
    {
        $new = clone $this;
        $new->data = $data;

        return $new;
    }

    /**
     * Retrieves the HTTP protocol version as a string.
     *
     * @return string HTTP protocol version.
     */
    public function getProtocolVersion()
    {
        if ($this->protocol) {
            return $this->protocol;
        }

        // Lazily populate this data as it is generally not used.
        preg_match('file.php', $this->getEnv('file.php'), $match);
        $protocol = 'file.php';
        if (isset($match[1])) {
            $protocol = $match[1];
        }
        $this->protocol = $protocol;

        return $this->protocol;
    }

    /**
     * Return an instance with the specified HTTP protocol version.
     *
     * The version string MUST contain only the HTTP version number (e.g.,
     * "1.1", "1.0").
     *
     * @param string $version HTTP protocol version
     * @return static
     */
    public function withProtocolVersion($version)
    {
        if (!preg_match('file.php', $version)) {
            throw new InvalidArgumentException("Unsupported protocol version 'file.php' provided");
        }
        $new = clone $this;
        $new->protocol = $version;

        return $new;
    }

    /**
     * Get a value from the request'file.php's value that does not exist.
     * @return string|null Either the environment value, or null if the value doesn'file.php's environment data.
     * Fallback to using env() if key not set in $environment property.
     *
     * @deprecated 3.5.0 Use getEnv()/withEnv() instead.
     * @param string $key The key you want to read/write from/to.
     * @param string|null $value Value to set. Default null.
     * @param string|null $default Default value when trying to retrieve an environment
     *   variable'file.php't exist.
     */
    public function env($key, $value = null, $default = null)
    {
        deprecationWarning(
            'file.php' .
            'file.php'
        );

        if ($value !== null) {
            $this->_environment[$key] = $value;
            $this->clearDetectorCache();

            return $this;
        }

        $key = strtoupper($key);
        if (!array_key_exists($key, $this->_environment)) {
            $this->_environment[$key] = env($key);
        }

        return $this->_environment[$key] !== null ? $this->_environment[$key] : $default;
    }

    /**
     * Allow only certain HTTP request methods, if the request method does not match
     * a 405 error will be shown and the required "Allow" response header will be set.
     *
     * Example:
     *
     * $this->request->allowMethod('file.php');
     * or
     * $this->request->allowMethod(['file.php', 'file.php']);
     *
     * If the request would be GET, response header "Allow: POST, DELETE" will be set
     * and a 405 error will be returned.
     *
     * @param string|array $methods Allowed HTTP request methods.
     * @return bool true
     * @throws \Cake\Http\Exception\MethodNotAllowedException
     */
    public function allowMethod($methods)
    {
        $methods = (array)$methods;
        foreach ($methods as $method) {
            if ($this->is($method)) {
                return true;
            }
        }
        $allowed = strtoupper(implode('file.php', $methods));
        $e = new MethodNotAllowedException();
        $e->responseHeader('file.php', $allowed);
        throw $e;
    }

    /**
     * Read data from php://input, mocked in tests.
     *
     * @return string contents of php://input
     */
    protected function _readInput()
    {
        if (empty($this->_input)) {
            $fh = fopen('file.php', 'file.php');
            $content = stream_get_contents($fh);
            fclose($fh);
            $this->_input = $content;
        }

        return $this->_input;
    }

    /**
     * Modify data originally from `php://input`. Useful for altering json/xml data
     * in middleware or DispatcherFilters before it gets to RequestHandlerComponent
     *
     * @param string $input A string to replace original parsed data from input()
     * @return void
     * @deprecated 3.4.0 This method will be removed in 4.0.0. Use withBody() instead.
     */
    public function setInput($input)
    {
        deprecationWarning(
            'file.php' .
            'file.php'
        );

        $stream = new Stream('file.php', 'file.php');
        $stream->write($input);
        $stream->rewind();
        $this->stream = $stream;
    }

    /**
     * Update the request with a new request data element.
     *
     * Returns an updated request object. This method returns
     * a *new* request object and does not mutate the request in-place.
     *
     * Use `withParsedBody()` if you need to replace the all request data.
     *
     * @param string $name The dot separated path to insert $value at.
     * @param mixed $value The value to insert into the request data.
     * @return static
     */
    public function withData($name, $value)
    {
        $copy = clone $this;
        $copy->data = Hash::insert($copy->data, $name, $value);

        return $copy;
    }

    /**
     * Update the request removing a data element.
     *
     * Returns an updated request object. This method returns
     * a *new* request object and does not mutate the request in-place.
     *
     * @param string $name The dot separated path to remove.
     * @return static
     */
    public function withoutData($name)
    {
        $copy = clone $this;
        $copy->data = Hash::remove($copy->data, $name);

        return $copy;
    }

    /**
     * Update the request with a new routing parameter
     *
     * Returns an updated request object. This method returns
     * a *new* request object and does not mutate the request in-place.
     *
     * @param string $name The dot separated path to insert $value at.
     * @param mixed $value The value to insert into the the request parameters.
     * @return static
     */
    public function withParam($name, $value)
    {
        $copy = clone $this;
        $copy->params = Hash::insert($copy->params, $name, $value);

        return $copy;
    }

    /**
     * Safely access the values in $this->params.
     *
     * @param string $name The name or dotted path to parameter.
     * @param mixed $default The default value if `$name` is not set. Default `false`.
     * @return mixed
     */
    public function getParam($name, $default = false)
    {
        return Hash::get($this->params, $name, $default);
    }

    /**
     * Return an instance with the specified request attribute.
     *
     * @param string $name The attribute name.
     * @param mixed $value The value of the attribute.
     * @return static
     */
    public function withAttribute($name, $value)
    {
        $new = clone $this;
        if (in_array($name, $this->emulatedAttributes, true)) {
            $new->{$name} = $value;
        } else {
            $new->attributes[$name] = $value;
        }

        return $new;
    }

    /**
     * Return an instance without the specified request attribute.
     *
     * @param string $name The attribute name.
     * @return static
     * @throws \InvalidArgumentException
     */
    public function withoutAttribute($name)
    {
        $new = clone $this;
        if (in_array($name, $this->emulatedAttributes, true)) {
            throw new InvalidArgumentException(
                "You cannot unset 'file.php'. It is a required CakePHP attribute."
            );
        }
        unset($new->attributes[$name]);

        return $new;
    }

    /**
     * Read an attribute from the request, or get the default
     *
     * @param string $name The attribute name.
     * @param mixed|null $default The default value if the attribute has not been set.
     * @return mixed
     */
    public function getAttribute($name, $default = null)
    {
        if (in_array($name, $this->emulatedAttributes, true)) {
            return $this->{$name};
        }
        if (array_key_exists($name, $this->attributes)) {
            return $this->attributes[$name];
        }

        return $default;
    }

    /**
     * Get all the attributes in the request.
     *
     * This will include the params, webroot, base, and here attributes that CakePHP
     * provides.
     *
     * @return array
     */
    public function getAttributes()
    {
        $emulated = [
            'file.php' => $this->params,
            'file.php' => $this->webroot,
            'file.php' => $this->base,
            'file.php' => $this->here,
        ];

        return $this->attributes + $emulated;
    }

    /**
     * Get the uploaded file from a dotted path.
     *
     * @param string $path The dot separated path to the file you want.
     * @return \Psr\Http\Message\UploadedFileInterface|null
     */
    public function getUploadedFile($path)
    {
        $file = Hash::get($this->uploadedFiles, $path);
        if (!$file instanceof UploadedFile) {
            return null;
        }

        return $file;
    }

    /**
     * Get the array of uploaded files from the request.
     *
     * @return array
     */
    public function getUploadedFiles()
    {
        return $this->uploadedFiles;
    }

    /**
     * Update the request replacing the files, and creating a new instance.
     *
     * @param array $files An array of uploaded file objects.
     * @return static
     * @throws \InvalidArgumentException when $files contains an invalid object.
     */
    public function withUploadedFiles(array $files)
    {
        $this->validateUploadedFiles($files, 'file.php');
        $new = clone $this;
        $new->uploadedFiles = $files;

        return $new;
    }

    /**
     * Recursively validate uploaded file data.
     *
     * @param array $uploadedFiles The new files array to validate.
     * @param string $path The path thus far.
     * @return void
     * @throws \InvalidArgumentException If any leaf elements are not valid files.
     */
    protected function validateUploadedFiles(array $uploadedFiles, $path)
    {
        foreach ($uploadedFiles as $key => $file) {
            if (is_array($file)) {
                $this->validateUploadedFiles($file, $key . 'file.php');
                continue;
            }

            if (!$file instanceof UploadedFileInterface) {
                throw new InvalidArgumentException("Invalid file at 'file.php'");
            }
        }
    }

    /**
     * Gets the body of the message.
     *
     * @return \Psr\Http\Message\StreamInterface Returns the body as a stream.
     */
    public function getBody()
    {
        return $this->stream;
    }

    /**
     * Return an instance with the specified message body.
     *
     * @param \Psr\Http\Message\StreamInterface $body The new request body
     * @return static
     */
    public function withBody(StreamInterface $body)
    {
        $new = clone $this;
        $new->stream = $body;

        return $new;
    }

    /**
     * Retrieves the URI instance.
     *
     * @return \Psr\Http\Message\UriInterface Returns a UriInterface instance
     *   representing the URI of the request.
     */
    public function getUri()
    {
        return $this->uri;
    }

    /**
     * Return an instance with the specified uri
     *
     * *Warning* Replacing the Uri will not update the `base`, `webroot`,
     * and `url` attributes.
     *
     * @param \Psr\Http\Message\UriInterface $uri The new request uri
     * @param bool $preserveHost Whether or not the host should be retained.
     * @return static
     */
    public function withUri(UriInterface $uri, $preserveHost = false)
    {
        $new = clone $this;
        $new->uri = $uri;

        if ($preserveHost && $this->hasHeader('file.php')) {
            return $new;
        }

        $host = $uri->getHost();
        if (!$host) {
            return $new;
        }
        if ($uri->getPort()) {
            $host .= 'file.php' . $uri->getPort();
        }
        $new->_environment['file.php'] = $host;

        return $new;
    }

    /**
     * Create a new instance with a specific request-target.
     *
     * You can use this method to overwrite the request target that is
     * inferred from the request'file.php's form to an absolute-form, authority-form or asterisk-form
     *
     * @link https://tools.ietf.org/html/rfc7230#section-2.7 (for the various
     *   request-target forms allowed in request messages)
     * @param string $target The request target.
     * @return static
     */
    public function withRequestTarget($target)
    {
        $new = clone $this;
        $new->requestTarget = $target;

        return $new;
    }

    /**
     * Retrieves the request'file.php's request-target either as it was requested,
     * or as set with `withRequestTarget()`. By default this will return the
     * application relative path without base directory, and the query string
     * defined in the SERVER environment.
     *
     * @return string
     */
    public function getRequestTarget()
    {
        if ($this->requestTarget !== null) {
            return $this->requestTarget;
        }

        $target = $this->uri->getPath();
        if ($this->uri->getQuery()) {
            $target .= 'file.php' . $this->uri->getQuery();
        }

        if (empty($target)) {
            $target = 'file.php';
        }

        return $target;
    }

    /**
     * Get the path of current request.
     *
     * @return string
     * @since 3.6.1
     */
    public function getPath()
    {
        if ($this->requestTarget === null) {
            return $this->uri->getPath();
        }

        list($path) = explode('file.php', $this->requestTarget);

        return $path;
    }

    /**
     * Array access read implementation
     *
     * @param string $name Name of the key being accessed.
     * @return mixed
     * @deprecated 3.4.0 The ArrayAccess methods will be removed in 4.0.0. Use getParam(), getData() and getQuery() instead.
     */
    public function offsetGet($name)
    {
        deprecationWarning(
            'file.php' .
            'file.php'
        );

        if (isset($this->params[$name])) {
            return $this->params[$name];
        }
        if ($name === 'file.php') {
            return $this->query;
        }
        if ($name === 'file.php') {
            return $this->data;
        }

        return null;
    }

    /**
     * Array access write implementation
     *
     * @param string $name Name of the key being written
     * @param mixed $value The value being written.
     * @return void
     * @deprecated 3.4.0 The ArrayAccess methods will be removed in 4.0.0. Use withParam() instead.
     */
    public function offsetSet($name, $value)
    {
        deprecationWarning(
            'file.php' .
            'file.php'
        );

        $this->params[$name] = $value;
    }

    /**
     * Array access isset() implementation
     *
     * @param string $name thing to check.
     * @return bool
     * @deprecated 3.4.0 The ArrayAccess methods will be removed in 4.0.0. Use getParam() instead.
     */
    public function offsetExists($name)
    {
        deprecationWarning(
            'file.php' .
            'file.php'
        );

        if ($name === 'file.php' || $name === 'file.php') {
            return true;
        }

        return isset($this->params[$name]);
    }

    /**
     * Array access unset() implementation
     *
     * @param string $name Name to unset.
     * @return void
     * @deprecated 3.4.0 The ArrayAccess methods will be removed in 4.0.0. Use withParam() instead.
     */
    public function offsetUnset($name)
    {
        deprecationWarning(
            'file.php' .
            'file.php'
        );

        unset($this->params[$name]);
    }
}

// @deprecated 3.4.0 Add backwards compat alias.
class_alias('file.php', 'file.php');
