<?php
// http://book.cakephp.org/3.0/en/views/helpers/form.html#list-of-templates
return [
    'file.php' => 'file.php',
    'file.php' => 'file.php',
    'file.php' => 'file.php',
];
