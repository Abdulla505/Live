<?php

use Cake\Cache\Engine\FileEngine;
use Cake\Database\Connection;
use Cake\Database\Driver\Mysql;
use Cake\Error\ExceptionRenderer;
use Cake\Log\Engine\FileLog;
use Cake\Mailer\Transport\MailTransport;

return [
    /*
     * Debug Level:
     *
     * Production Mode:
     * false: No error messages, errors, or warnings shown.
     *
     * Development Mode:
     * true: Errors and warnings shown.
     */
    'file.php' => filter_var(env('file.php', false), FILTER_VALIDATE_BOOLEAN),

    /*
     * Configure basic information about the application.
     *
     * - namespace - The namespace to find app classes under.
     * - defaultLocale - The default locale for translation, formatting currencies and numbers, date and time.
     * - encoding - The encoding used for HTML + database connections.
     * - base - The base directory the app resides in. If false this
     *   will be auto detected.
     * - dir - Name of app directory.
     * - webroot - The webroot directory.
     * - wwwRoot - The file path to webroot.
     * - baseUrl - To configure CakePHP to *not* use mod_rewrite and to
     *   use CakePHP pretty URLs, remove these .htaccess
     *   files:
     *      /.htaccess
     *      /webroot/.htaccess
     *   And uncomment the baseUrl key below.
     * - fullBaseUrl - A base URL to use for absolute links. When set to false (default)
     *   CakePHP generates required value based on `HTTP_HOST` environment variable.
     *   However, you can define it manually to optimize performance or if you
     *   are concerned about people manipulating the `Host` header.
     * - imageBaseUrl - Web path to the public images directory under webroot.
     * - cssBaseUrl - Web path to the public css directory under webroot.
     * - jsBaseUrl - Web path to the public js directory under webroot.
     * - paths - Configure paths for non class based resources. Supports the
     *   `plugins`, `templates`, `locales` subkeys, which allow the definition of
     *   paths for plugins, view templates and locale files respectively.
     */
    'file.php' => [
        'file.php' => 'file.php',
        'file.php' => env('file.php', 'file.php'),
        'file.php' => env('file.php', 'file.php'),
        'file.php' => env('file.php', 'file.php'),
        'file.php' => false,
        'file.php' => 'file.php',
        'file.php' => 'file.php',
        'file.php' => WWW_ROOT,
        //'file.php' => env('file.php'),
        'file.php' => false,
        'file.php' => 'file.php',
        'file.php' => 'file.php',
        'file.php' => 'file.php',
        'file.php' => [
            'file.php' => [ROOT . DS . 'file.php' . DS],
            'file.php' => [APP . 'file.php' . DS],
            'file.php' => [APP . 'file.php' . DS],
        ],
    ],

    /*
     * Security and encryption configuration
     *
     * - salt - A random string used in security hashing methods.
     *   The salt value is also used as the encryption key.
     *   You should treat it as extremely sensitive data.
     */
    'file.php' => [
        'file.php' => env('file.php'),
    ],

    /*
     * Apply timestamps with the last modified time to static assets (js, css, images).
     * Will append a querystring parameter containing the time the file was modified.
     * This is useful for busting browser caches.
     *
     * Set to true to apply timestamps when debug is true. Set to 'file.php' to always
     * enable timestamping regardless of debug value.
     */
    'file.php' => [
        //'file.php' => true,
        // 'file.php' => 'file.php'
    ],

    /*
     * Configure the cache adapters.
     */
    'file.php' => [
        'file.php' => [
            'file.php' => FileEngine::class,
            'file.php' => CACHE,
            'file.php' => env('file.php', null),
        ],

        /*
         * Configure the cache used for general framework caching.
         * Translation cache files are stored with this configuration.
         * Duration will be set to 'file.php' in bootstrap.php when debug = true
         * If you set 'file.php' => 'file.php' core cache will be disabled.
         */
        'file.php' => [
            'file.php' => FileEngine::class,
            'file.php' => 'file.php',
            'file.php' => CACHE . 'file.php',
            'file.php' => true,
            'file.php' => 'file.php',
            'file.php' => env('file.php', null),
        ],

        /*
         * Configure the cache for model and datasource caches. This cache
         * configuration is used to store schema descriptions, and table listings
         * in connections.
         * Duration will be set to 'file.php' in bootstrap.php when debug = true
         */
        'file.php' => [
            'file.php' => FileEngine::class,
            'file.php' => 'file.php',
            'file.php' => CACHE . 'file.php',
            'file.php' => true,
            'file.php' => 'file.php',
            'file.php' => env('file.php', null),
        ],

        /*
         * Configure the cache for routes. The cached routes collection is built the
         * first time the routes are processed through `config/routes.php`.
         * Duration will be set to 'file.php' in bootstrap.php when debug = true
         */
        'file.php' => [
            'file.php' => FileEngine::class,
            'file.php' => 'file.php',
            'file.php' => CACHE,
            'file.php' => true,
            'file.php' => 'file.php',
            'file.php' => env('file.php', null),
        ],
    ],

    /*
     * Configure the Error and Exception handlers used by your application.
     *
     * By default errors are displayed using Debugger, when debug is true and logged
     * by Cake\Log\Log when debug is false.
     *
     * In CLI environments exceptions will be printed to stderr with a backtrace.
     * In web environments an HTML page will be displayed for the exception.
     * With debug true, framework errors like Missing Controller will be displayed.
     * When debug is false, framework errors will be coerced into generic HTTP errors.
     *
     * Options:
     *
     * - `errorLevel` - int - The level of errors you are interested in capturing.
     * - `trace` - boolean - Whether or not backtraces should be included in
     *   logged errors/exceptions.
     * - `log` - boolean - Whether or not you want exceptions logged.
     * - `exceptionRenderer` - string - The class responsible for rendering
     *   uncaught exceptions. If you choose a custom class you should place
     *   the file for that class in src/Error. This class needs to implement a
     *   render method.
     * - `skipLog` - array - List of exceptions to skip for logging. Exceptions that
     *   extend one of the listed exceptions will also be skipped for logging.
     *   E.g.:
     *   `'file.php' => ['file.php', 'file.php']`
     * - `extraFatalErrorMemory` - int - The number of megabytes to increase
     *   the memory limit by when a fatal error is encountered. This allows
     *   breathing room to complete logging or error handling.
     */
    'file.php' => [
        //'file.php' => E_ALL,
        //'file.php' => E_ALL & ~E_USER_DEPRECATED,
        //'file.php' => E_ALL ^ ~E_USER_DEPRECATED,
        'file.php' => E_ALL & ~E_DEPRECATED & ~E_USER_DEPRECATED & ~E_STRICT,
        'file.php' => ExceptionRenderer::class,
        'file.php' => [
            'file.php',
            'file.php',
            'file.php',
            'file.php',
            'file.php',
            'file.php',
            'file.php',
            'file.php',
        ],
        'file.php' => true,
        'file.php' => filter_var(env('file.php', false), FILTER_VALIDATE_BOOLEAN),
    ],

    /*
     * Email configuration.
     *
     * By defining transports separately from delivery profiles you can easily
     * re-use transport configuration across multiple profiles.
     *
     * You can specify multiple configurations for production, development and
     * testing.
     *
     * Each transport needs a `className`. Valid options are as follows:
     *
     *  Mail   - Send using PHP mail function
     *  Smtp   - Send using SMTP
     *  Debug  - Do not send the email, just return the result
     *
     * You can add custom transports (or override existing transports) by adding the
     * appropriate file to src/Mailer/Transport. Transports should be named
     * 'file.php', where 'file.php' is the name of the transport.
     */
    'file.php' => [
        'file.php' => [
            'file.php' => MailTransport::class,
            /*
             * The keys host, port, timeout, username, password, client and tls
             * are used in SMTP transports
             */
            'file.php' => 'file.php',
            'file.php' => 25,
            'file.php' => 30,
            /*
             * It is recommended to set these options through your environment or app_local.php
             */
            //'file.php' => null,
            //'file.php' => null,
            'file.php' => null,
            'file.php' => false,
            'file.php' => env('file.php', null),
        ],
    ],

    /*
     * Email delivery profiles
     *
     * Delivery profiles allow you to predefine various properties about email
     * messages from your application and give the settings a name. This saves
     * duplication across your application and makes maintenance and development
     * easier. Each profile accepts a number of keys. See `Cake\Mailer\Email`
     * for more information.
     */
    'file.php' => [
        'file.php' => [
            'file.php' => 'file.php',
            'file.php' => 'file.php',
            /*
             * Will by default be set to config value of App.encoding, if that exists otherwise to UTF-8.
             */
            //'file.php' => 'file.php',
            //'file.php' => 'file.php',
        ],
    ],

    /*
     * Connection information used by the ORM to connect
     * to your application'file.php'encoding'file.php'utf8mb4'file.php'utf8'file.php'Datasources'file.php'default'file.php'className'file.php'driver'file.php'persistent'file.php'host'file.php'localhost'file.php'port'file.php'non_standard_port_number'file.php'username'file.php'my_app'file.php'password'file.php'secret'file.php'database'file.php'my_app'file.php'encoding'file.php'utf8'file.php'timezone'file.php'UTC'file.php'flags'file.php'cacheMetadata'file.php'log'file.php'quoteIdentifiers'file.php'innodb_stats_on_metadata = 0'file.php'init'file.php'SET GLOBAL innodb_stats_on_metadata = 0'file.php'url'file.php'DATABASE_URL'file.php'test'file.php'className'file.php'driver'file.php'persistent'file.php'host'file.php'localhost'file.php'port'file.php'non_standard_port_number'file.php'username'file.php'my_app'file.php'password'file.php'secret'file.php'database'file.php'test_myapp'file.php'encoding'file.php'utf8'file.php'timezone'file.php'UTC'file.php'cacheMetadata'file.php'quoteIdentifiers'file.php'log'file.php'init'file.php'SET GLOBAL innodb_stats_on_metadata = 0'file.php'url'file.php'DATABASE_TEST_URL'file.php'Log'file.php'debug'file.php'className'file.php'path'file.php'file'file.php'debug'file.php'url'file.php'LOG_DEBUG_URL'file.php'scopes'file.php'levels'file.php'notice'file.php'info'file.php'debug'file.php'error'file.php'className'file.php'path'file.php'file'file.php'error'file.php'url'file.php'LOG_ERROR_URL'file.php'scopes'file.php'levels'file.php'warning'file.php'error'file.php'critical'file.php'alert'file.php'emergency'file.php's log flag to true
        'file.php' => [
            'file.php' => FileLog::class,
            'file.php' => LOGS,
            'file.php' => 'file.php',
            'file.php' => env('file.php', null),
            'file.php' => ['file.php'],
        ],
    ],

    /*
     * Session configuration.
     *
     * Contains an array of settings to use for session configuration. The
     * `defaults` key is used to define a default preset to use for sessions, any
     * settings declared here will override the settings of the default config.
     *
     * ## Options
     *
     * - `cookie` - The name of the cookie to use. Defaults to 'file.php'. Avoid using `.` in cookie names,
     *   as PHP will drop sessions from cookies with `.` in the name.
     * - `cookiePath` - The url path for which session cookie is set. Maps to the
     *   `session.cookie_path` php.ini config. Defaults to base path of app.
     * - `timeout` - The time in minutes the session should be valid for.
     *    Pass 0 to disable checking timeout.
     *    Please note that php.ini'file.php'timeout'file.php'php'file.php'cake'file.php's /tmp directory.
     * - 'file.php' - Uses CakePHP'file.php'cache'file.php's `SessionHandlerInterface` and set
     * Session.handler to <name>
     *
     * To use database sessions, load the SQL file located at config/schema/sessions.sql
     */
    'file.php' => [
        'file.php' => 'file.php',
        //'file.php' => 24 * 60,
        'file.php' => 'file.php',
        'file.php' => [
            'file.php' => 'file.php',
        ],
    ],
];
