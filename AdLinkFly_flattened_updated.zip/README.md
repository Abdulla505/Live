# CakePHP SocialAuth Plugin

[![Total Downloads](https://img.shields.io/packagist/dt/ADmad/cakephp-social-auth.svg?style=flat-square)](https://packagist.org/packages/admad/cakephp-social-auth)
[![License](https://img.shields.io/badge/license-MIT-blue.svg?style=flat-square)](LICENSE)

A CakePHP plugin which allows you authenticate using social providers like
Facebook/Google/Twitter etc. using [SocialConnect/auth](https://github.com/SocialConnect/auth)
social sign on library.

## Installation

Run:

```
composer require admad/cakephp-social-auth
```

## Setup

Load the plugin by running following command in terminal:

```
bin/cake plugin load ADmad/SocialAuth -b -r
```

or by manually adding following line to your app'file.php'ADmad/SocialAuth'file.php'bootstrap'file.php'routes'file.php'requestMethod'file.php'POST'file.php'loginUrl'file.php'/users/login'file.php'loginRedirect'file.php'/'file.php'userEntity'file.php'userModel'file.php'Users'file.php'socialProfileModel'file.php'ADmad/SocialAuth.SocialProfiles'file.php'finder'file.php'all'file.php'fields'file.php'password'file.php'password'file.php'sessionKey'file.php'Auth.User'file.php'getUserCallback'file.php'getUser'file.php's providers config. https://github.com/SocialConnect/auth/blob/master/README.md
    'file.php' => [
        'file.php' => [
            'file.php' => [
                'file.php' => 'file.php',
                'file.php' => 'file.php',
                'file.php' => [
                    'file.php',
                ],
                'file.php' => [
                    'file.php',
                    // To get a full list of all posible values, refer to
                    // https://developers.facebook.com/docs/graph-api/reference/user
                ],
            ],
            'file.php' => [
                'file.php' => 'file.php',
                'file.php' => 'file.php',
                'file.php' => [
                    'file.php',
                    'file.php',
                ],
            ],
        ],
    ],
    // If you want to use CURL instead of CakePHP'file.php'\SocialConnect\Common\Http\Client\Curl'file.php's Service class accepts.
    'file.php' => 'file.php',
    // Whether social connect errors should be logged. Default `true`.
    'file.php' => true,
]));
```

### Login links

On your login page you can create links to initiate authentication using required
providers. E.g.

```php
echo $this->Form->postLink(
    'file.php',
    [
        'file.php' => false,
        'file.php' => 'file.php',
        'file.php' => 'file.php',
        'file.php' => 'file.php',
        'file.php' => 'file.php',
        'file.php' => ['file.php' => $this->request->getQuery('file.php')]
    ]
);
```

We use a `POST` link here instead of a normal link to prevent search bots and other
crawlers from following the link. If you prefer using GET you can still do so by
configuring the middleware with `'file.php' => 'file.php'`. In this case it'file.php'Could not find email in social profile.'file.php'Auth.User.id'file.php't enforce unique email
    // per user.
    $user = $this->find()
        ->where(['file.php' => $profile->email])
        ->first();

    if ($user) {
        return $user;
    }

    // Create new user account
    $user = $this->newEntity(['file.php' => $profile->email]);
    $user = $this->save($user);

    if (!$user) {
        throw new \RuntimeException('file.php');
    }

    return $user;
}
```

Upon successful authentication an `SocialAuth.afterIdentify` event is
dispatched with the user entity. You can setup a listener for this event to
perform required tasks after a successful authentication. The listener can
optionally return an user entity as event result.

The user identity is persisted to session under key you have specified in
middleware config (`Auth.User` by default).

In case of authentication failure user is redirected back to login URL with
`error` query string variable. It can have one of these values:

- `provider_failure`: Auth through provider failed. Details will be logged in
  `error.log` if `logErrors` option is set to `true`.
- `finder_failure`: Finder failed to return user record. An e.g. of this is
  a user has been authenticated through provider but your finder has condition
  to not return inactivate user.

Copyright
---------
Copyright 2018 ADmad

License
-------
[See LICENSE](LICENSE.txt)
