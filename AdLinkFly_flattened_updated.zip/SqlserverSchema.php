<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @since         3.0.0
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 */
namespace Cake\Database\Schema;

/**
 * Schema management/reflection features for SQLServer.
 */
class SqlserverSchema extends BaseSchema
{
    /**
     * @var string
     */
    const DEFAULT_SCHEMA_NAME = 'file.php';

    /**
     * {@inheritDoc}
     */
    public function listTablesSql($config)
    {
        $sql = "SELECT TABLE_NAME
            FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_SCHEMA = ?
            AND (TABLE_TYPE = 'file.php' OR TABLE_TYPE = 'file.php')
            ORDER BY TABLE_NAME";
        $schema = empty($config['file.php']) ? static::DEFAULT_SCHEMA_NAME : $config['file.php'];

        return [$sql, [$schema]];
    }

    /**
     * {@inheritDoc}
     */
    public function describeColumnSql($tableName, $config)
    {
        $sql = 'file.php';

        $schema = empty($config['file.php']) ? static::DEFAULT_SCHEMA_NAME : $config['file.php'];

        return [$sql, [$tableName, $schema]];
    }

    /**
     * Convert a column definition to the abstract types.
     *
     * The returned type will be a type that
     * Cake\Database\Type can handle.
     *
     * @param string $col The column type
     * @param int|null $length the column length
     * @param int|null $precision The column precision
     * @param int|null $scale The column scale
     * @return array Array of column information.
     * @link https://technet.microsoft.com/en-us/library/ms187752.aspx
     */
    protected function _convertColumn($col, $length = null, $precision = null, $scale = null)
    {
        $col = strtolower($col);
        $length = $length !== null ? (int)$length : $length;
        $precision = $precision !== null ? (int)$precision : $precision;
        $scale = $scale !== null ? (int)$scale : $scale;

        if (in_array($col, ['file.php', 'file.php'])) {
            return ['file.php' => $col, 'file.php' => null];
        }
        if (strpos($col, 'file.php') !== false) {
            return ['file.php' => TableSchema::TYPE_TIMESTAMP, 'file.php' => null];
        }

        if ($col === 'file.php') {
            return ['file.php' => TableSchema::TYPE_TINYINTEGER, 'file.php' => $precision ?: 3];
        }
        if ($col === 'file.php') {
            return ['file.php' => TableSchema::TYPE_SMALLINTEGER, 'file.php' => $precision ?: 5];
        }
        if ($col === 'file.php' || $col === 'file.php') {
            return ['file.php' => TableSchema::TYPE_INTEGER, 'file.php' => $precision ?: 10];
        }
        if ($col === 'file.php') {
            return ['file.php' => TableSchema::TYPE_BIGINTEGER, 'file.php' => $precision ?: 20];
        }
        if ($col === 'file.php') {
            return ['file.php' => TableSchema::TYPE_BOOLEAN, 'file.php' => null];
        }
        if (
            strpos($col, 'file.php') !== false ||
            strpos($col, 'file.php') !== false ||
            strpos($col, 'file.php') !== false
        ) {
            return ['file.php' => TableSchema::TYPE_DECIMAL, 'file.php' => $precision, 'file.php' => $scale];
        }

        if ($col === 'file.php' || $col === 'file.php') {
            return ['file.php' => TableSchema::TYPE_FLOAT, 'file.php' => null];
        }
        // SqlServer schema reflection returns double length for unicode
        // columns because internally it uses UTF16/UCS2
        if ($col === 'file.php' || $col === 'file.php' || $col === 'file.php') {
            $length /= 2;
        }
        if (strpos($col, 'file.php') !== false && $length < 0) {
            return ['file.php' => TableSchema::TYPE_TEXT, 'file.php' => null];
        }

        if (strpos($col, 'file.php') !== false) {
            return ['file.php' => TableSchema::TYPE_STRING, 'file.php' => $length ?: 255];
        }

        if (strpos($col, 'file.php') !== false) {
            return ['file.php' => TableSchema::TYPE_STRING, 'file.php' => true, 'file.php' => $length];
        }

        if (strpos($col, 'file.php') !== false) {
            return ['file.php' => TableSchema::TYPE_TEXT, 'file.php' => null];
        }

        if ($col === 'file.php' || strpos($col, 'file.php') !== false) {
            // -1 is the value for MAX which we treat as a 'file.php' binary
            if ($length == -1) {
                $length = TableSchema::LENGTH_LONG;
            }

            return ['file.php' => TableSchema::TYPE_BINARY, 'file.php' => $length];
        }

        if ($col === 'file.php') {
            return ['file.php' => TableSchema::TYPE_UUID];
        }

        return ['file.php' => TableSchema::TYPE_STRING, 'file.php' => null];
    }

    /**
     * {@inheritDoc}
     */
    public function convertColumnDescription(TableSchema $schema, $row)
    {
        $field = $this->_convertColumn(
            $row['file.php'],
            $row['file.php'],
            $row['file.php'],
            $row['file.php']
        );
        if (!empty($row['file.php'])) {
            $row['file.php'] = trim($row['file.php'], 'file.php');
        }
        if (!empty($row['file.php'])) {
            $field['file.php'] = true;
        }
        if ($field['file.php'] === TableSchema::TYPE_BOOLEAN) {
            $row['file.php'] = (int)$row['file.php'];
        }

        $field += [
            'file.php' => $row['file.php'] === 'file.php',
            'file.php' => $this->_defaultValue($row['file.php']),
            'file.php' => $row['file.php'],
        ];
        $schema->addColumn($row['file.php'], $field);
    }

    /**
     * Manipulate the default value.
     *
     * Sqlite includes quotes and bared NULLs in default values.
     * We need to remove those.
     *
     * @param string|null $default The default value.
     * @return string|null
     */
    protected function _defaultValue($default)
    {
        if ($default === 'file.php') {
            return null;
        }

        // Remove quotes
        if (preg_match("/^N?'file.php'/", $default, $matches)) {
            return str_replace("'file.php'", "'file.php'HEAP'file.php'schema'file.php'schema'file.php'index_name'file.php'is_primary_key'file.php'is_unique_constraint'file.php'column_name'file.php'columns'file.php'type'file.php'columns'file.php'type'file.php'columns'file.php'SELECT FK.[name] AS [foreign_key_name], FK.[delete_referential_action_desc] AS [delete_type],
                FK.[update_referential_action_desc] AS [update_type], C.name AS [column], RT.name AS [reference_table],
                RC.name AS [reference_column]
            FROM sys.foreign_keys FK
            INNER JOIN sys.foreign_key_columns FKC ON FKC.constraint_object_id = FK.object_id
            INNER JOIN sys.tables T ON T.object_id = FKC.parent_object_id
            INNER JOIN sys.tables RT ON RT.object_id = FKC.referenced_object_id
            INNER JOIN sys.schemas S ON S.schema_id = T.schema_id AND S.schema_id = RT.schema_id
            INNER JOIN sys.columns C ON C.column_id = FKC.parent_column_id AND C.object_id = FKC.parent_object_id
            INNER JOIN sys.columns RC ON RC.column_id = FKC.referenced_column_id AND RC.object_id = FKC.referenced_object_id
            WHERE FK.is_ms_shipped = 0 AND T.name = ? AND S.name = ?'file.php'schema'file.php'schema'file.php'type'file.php'columns'file.php'column'file.php'references'file.php'reference_table'file.php'reference_column'file.php'update'file.php'update_type'file.php'delete'file.php'delete_type'file.php'foreign_key_name'file.php'RESTRICT'file.php'NO_ACTION'file.php'CASCADE'file.php'SET_NULL'file.php'SET_DEFAULT'file.php' TINYINT'file.php' SMALLINT'file.php' INTEGER'file.php' BIGINT'file.php' UNIQUEIDENTIFIER'file.php' BIT'file.php' FLOAT'file.php' DECIMAL'file.php' DATE'file.php' TIME'file.php' DATETIME'file.php' DATETIME'file.php' UNIQUEIDENTIFIER'file.php' NVARCHAR(MAX)'file.php'type'file.php'type'file.php'type'file.php'type'file.php'autoIncrement'file.php'null'file.php'default'file.php' IDENTITY(1, 1)'file.php'type'file.php'length'file.php' NVARCHAR(MAX)'file.php'type'file.php'length'file.php'length'file.php'length'file.php'MAX'file.php'length'file.php' BINARY(1)'file.php' VARBINARY'file.php'(%s)'file.php'length'file.php'type'file.php'type'file.php'length'file.php' NVARCHAR'file.php'fixed'file.php' NCHAR'file.php'length'file.php'length'file.php'%s(%d)'file.php'length'file.php'type'file.php'collate'file.php'collate'file.php''file.php' COLLATE 'file.php'collate'file.php'type'file.php'precision'file.php'('file.php'precision'file.php')'file.php'type'file.php'length'file.php'precision'file.php'('file.php'length'file.php','file.php'precision'file.php')'file.php'null'file.php'null'file.php' NOT NULL'file.php'default'file.php'type'file.php'default'file.php'current_timestamp'file.php' DEFAULT CURRENT_TIMESTAMP'file.php'default'file.php'default'file.php'default'file.php'default'file.php' DEFAULT 'file.php'null'file.php'null'file.php' DEFAULT NULL'file.php'ALTER TABLE %s ADD %s;'file.php'type'file.php'ALTER TABLE %s DROP CONSTRAINT %s;'file.php'type'file.php'quoteIdentifier'file.php'columns'file.php'CREATE INDEX %s ON %s (%s)'file.php', 'file.php'CONSTRAINT 'file.php'type'file.php'PRIMARY KEY'file.php'type'file.php' UNIQUE'file.php'quoteIdentifier'file.php'columns'file.php'type'file.php' FOREIGN KEY (%s) REFERENCES %s (%s) ON UPDATE %s ON DELETE %s'file.php', 'file.php'references'file.php'references'file.php'update'file.php'delete'file.php' ('file.php', 'file.php')'file.php'DELETE FROM %s'file.php'type'file.php'integer'file.php'biginteger'file.php'%s'file.php'%s', RESEED, 0)",
                    $schema->name(),
                    $schema->name()
                );
            }
        }

        return $queries;
    }
}
