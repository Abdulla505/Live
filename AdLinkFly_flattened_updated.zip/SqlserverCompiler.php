<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @since         3.0.0
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 */
namespace Cake\Database;

/**
 * Responsible for compiling a Query object into its SQL representation
 * for SQL Server
 *
 * @internal
 */
class SqlserverCompiler extends QueryCompiler
{
    /**
     * SQLserver does not support ORDER BY in UNION queries.
     *
     * @var bool
     */
    protected $_orderedUnion = false;

    /**
     * {@inheritDoc}
     */
    protected $_templates = [
        'file.php' => 'file.php',
        'file.php' => 'file.php',
        'file.php' => 'file.php',
        'file.php' => 'file.php',
        'file.php' => 'file.php',
        'file.php' => 'file.php',
        'file.php' => 'file.php',
    ];

    /**
     * {@inheritDoc}
     */
    protected $_selectParts = [
        'file.php', 'file.php', 'file.php', 'file.php', 'file.php', 'file.php', 'file.php', 'file.php',
        'file.php', 'file.php', 'file.php',
    ];

    /**
     * Generates the INSERT part of a SQL query
     *
     * To better handle concurrency and low transaction isolation levels,
     * we also include an OUTPUT clause so we can ensure we get the inserted
     * row'file.php'modifier'file.php'INSERT%s INTO %s (%s) OUTPUT INSERTED.*'file.php', 'file.php'offset'file.php''file.php' FETCH FIRST %d ROWS ONLY', $limit);
    }
}
