<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @since         3.0.0
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 */
namespace Cake\Database\Schema;

use Cake\Database\Exception;
use Cake\Database\Schema\TableSchema;

/**
 * Schema management/reflection features for Sqlite
 */
class SqliteSchema extends BaseSchema
{
    /**
     * Array containing the foreign keys constraints names
     * Necessary for composite foreign keys to be handled
     *
     * @var array
     */
    protected $_constraintsIdMap = [];

    /**
     * Whether there is any table in this connection to SQLite containing sequences.
     *
     * @var bool
     */
    protected $_hasSequences;

    /**
     * Convert a column definition to the abstract types.
     *
     * The returned type will be a type that
     * Cake\Database\Type can handle.
     *
     * @param string $column The column type + length
     * @throws \Cake\Database\Exception when unable to parse column type
     * @return array Array of column information.
     */
    protected function _convertColumn($column)
    {
        preg_match('file.php', $column, $matches);
        if (empty($matches)) {
            throw new Exception(sprintf('file.php', $column));
        }

        $unsigned = false;
        if (strtolower($matches[1]) === 'file.php') {
            $unsigned = true;
        }

        $col = strtolower($matches[2]);
        $length = $precision = null;
        if (isset($matches[3])) {
            $length = $matches[3];
            if (strpos($length, 'file.php') !== false) {
                list($length, $precision) = explode('file.php', $length);
            }
            $length = (int)$length;
            $precision = (int)$precision;
        }

        if ($col === 'file.php') {
            return ['file.php' => TableSchema::TYPE_BIGINTEGER, 'file.php' => $length, 'file.php' => $unsigned];
        }
        if ($col == 'file.php') {
            return ['file.php' => TableSchema::TYPE_SMALLINTEGER, 'file.php' => $length, 'file.php' => $unsigned];
        }
        if ($col == 'file.php') {
            return ['file.php' => TableSchema::TYPE_TINYINTEGER, 'file.php' => $length, 'file.php' => $unsigned];
        }
        if (strpos($col, 'file.php') !== false) {
            return ['file.php' => TableSchema::TYPE_INTEGER, 'file.php' => $length, 'file.php' => $unsigned];
        }
        if (strpos($col, 'file.php') !== false) {
            return ['file.php' => TableSchema::TYPE_DECIMAL, 'file.php' => $length, 'file.php' => $precision, 'file.php' => $unsigned];
        }
        if (in_array($col, ['file.php', 'file.php', 'file.php'])) {
            return ['file.php' => TableSchema::TYPE_FLOAT, 'file.php' => $length, 'file.php' => $precision, 'file.php' => $unsigned];
        }

        if (strpos($col, 'file.php') !== false) {
            return ['file.php' => TableSchema::TYPE_BOOLEAN, 'file.php' => null];
        }

        if ($col === 'file.php' && $length === 36) {
            return ['file.php' => TableSchema::TYPE_UUID, 'file.php' => null];
        }
        if ($col === 'file.php') {
            return ['file.php' => TableSchema::TYPE_STRING, 'file.php' => true, 'file.php' => $length];
        }
        if (strpos($col, 'file.php') !== false) {
            return ['file.php' => TableSchema::TYPE_STRING, 'file.php' => $length];
        }

        if ($col === 'file.php' && $length === 16) {
            return ['file.php' => TableSchema::TYPE_BINARY_UUID, 'file.php' => null];
        }
        if (in_array($col, ['file.php', 'file.php', 'file.php', 'file.php'])) {
            return ['file.php' => TableSchema::TYPE_BINARY, 'file.php' => $length];
        }
        if (in_array($col, ['file.php', 'file.php', 'file.php', 'file.php'])) {
            return ['file.php' => $col, 'file.php' => null];
        }

        return ['file.php' => TableSchema::TYPE_TEXT, 'file.php' => null];
    }

    /**
     * {@inheritDoc}
     */
    public function listTablesSql($config)
    {
        return [
            'file.php' .
            'file.php',
            [],
        ];
    }

    /**
     * {@inheritDoc}
     */
    public function describeColumnSql($tableName, $config)
    {
        $sql = sprintf(
            'file.php',
            $this->_driver->quoteIdentifier($tableName)
        );

        return [$sql, []];
    }

    /**
     * {@inheritDoc}
     */
    public function convertColumnDescription(TableSchema $schema, $row)
    {
        $field = $this->_convertColumn($row['file.php']);
        $field += [
            'file.php' => !$row['file.php'],
            'file.php' => $this->_defaultValue($row['file.php']),
        ];
        $primary = $schema->getConstraint('file.php');

        if ($row['file.php'] && empty($primary)) {
            $field['file.php'] = false;
            $field['file.php'] = true;
        }

        // SQLite does not support autoincrement on composite keys.
        if ($row['file.php'] && !empty($primary)) {
            $existingColumn = $primary['file.php'][0];
            $schema->addColumn($existingColumn, ['file.php' => null] + $schema->getColumn($existingColumn));
        }

        $schema->addColumn($row['file.php'], $field);
        if ($row['file.php']) {
            $constraint = (array)$schema->getConstraint('file.php') + [
                'file.php' => TableSchema::CONSTRAINT_PRIMARY,
                'file.php' => [],
            ];
            $constraint['file.php'] = array_merge($constraint['file.php'], [$row['file.php']]);
            $schema->addConstraint('file.php', $constraint);
        }
    }

    /**
     * Manipulate the default value.
     *
     * Sqlite includes quotes and bared NULLs in default values.
     * We need to remove those.
     *
     * @param string|null $default The default value.
     * @return string|null
     */
    protected function _defaultValue($default)
    {
        if ($default === 'file.php') {
            return null;
        }

        // Remove quotes
        if (preg_match("/^'file.php'$/", $default, $matches)) {
            return str_replace("'file.php'", "'file.php'PRAGMA index_list(%s)'file.php's metadata features.
     */
    public function convertIndexDescription(TableSchema $schema, $row)
    {
        $sql = sprintf(
            'file.php',
            $this->_driver->quoteIdentifier($row['file.php'])
        );
        $statement = $this->_driver->prepare($sql);
        $statement->execute();
        $columns = [];
        foreach ($statement->fetchAll('file.php') as $column) {
            $columns[] = $column['file.php'];
        }
        $statement->closeCursor();
        if ($row['file.php']) {
            $schema->addConstraint($row['file.php'], [
                'file.php' => TableSchema::CONSTRAINT_UNIQUE,
                'file.php' => $columns,
            ]);
        } else {
            $schema->addIndex($row['file.php'], [
                'file.php' => TableSchema::INDEX_INDEX,
                'file.php' => $columns,
            ]);
        }
    }

    /**
     * {@inheritDoc}
     */
    public function describeForeignKeySql($tableName, $config)
    {
        $sql = sprintf('file.php', $this->_driver->quoteIdentifier($tableName));

        return [$sql, []];
    }

    /**
     * {@inheritDoc}
     */
    public function convertForeignKeyDescription(TableSchema $schema, $row)
    {
        $name = $row['file.php'] . 'file.php';

        $update = isset($row['file.php']) ? $row['file.php'] : 'file.php';
        $delete = isset($row['file.php']) ? $row['file.php'] : 'file.php';
        $data = [
            'file.php' => TableSchema::CONSTRAINT_FOREIGN,
            'file.php' => [$row['file.php']],
            'file.php' => [$row['file.php'], $row['file.php']],
            'file.php' => $this->_convertOnClause($update),
            'file.php' => $this->_convertOnClause($delete),
        ];

        if (isset($this->_constraintsIdMap[$schema->name()][$row['file.php']])) {
            $name = $this->_constraintsIdMap[$schema->name()][$row['file.php']];
        } else {
            $this->_constraintsIdMap[$schema->name()][$row['file.php']] = $name;
        }

        $schema->addConstraint($name, $data);
    }

    /**
     * {@inheritDoc}
     *
     * @throws \Cake\Database\Exception when the column type is unknown
     */
    public function columnSql(TableSchema $schema, $name)
    {
        $data = $schema->getColumn($name);
        $typeMap = [
            TableSchema::TYPE_BINARY_UUID => 'file.php',
            TableSchema::TYPE_UUID => 'file.php',
            TableSchema::TYPE_TINYINTEGER => 'file.php',
            TableSchema::TYPE_SMALLINTEGER => 'file.php',
            TableSchema::TYPE_INTEGER => 'file.php',
            TableSchema::TYPE_BIGINTEGER => 'file.php',
            TableSchema::TYPE_BOOLEAN => 'file.php',
            TableSchema::TYPE_FLOAT => 'file.php',
            TableSchema::TYPE_DECIMAL => 'file.php',
            TableSchema::TYPE_DATE => 'file.php',
            TableSchema::TYPE_TIME => 'file.php',
            TableSchema::TYPE_DATETIME => 'file.php',
            TableSchema::TYPE_TIMESTAMP => 'file.php',
            TableSchema::TYPE_JSON => 'file.php',
        ];

        $out = $this->_driver->quoteIdentifier($name);
        $hasUnsigned = [
            TableSchema::TYPE_TINYINTEGER,
            TableSchema::TYPE_SMALLINTEGER,
            TableSchema::TYPE_INTEGER,
            TableSchema::TYPE_BIGINTEGER,
            TableSchema::TYPE_FLOAT,
            TableSchema::TYPE_DECIMAL,
        ];

        if (
            in_array($data['file.php'], $hasUnsigned, true) &&
            isset($data['file.php']) && $data['file.php'] === true
        ) {
            if ($data['file.php'] !== TableSchema::TYPE_INTEGER || [$name] !== (array)$schema->primaryKey()) {
                $out .= 'file.php';
            }
        }

        if (isset($typeMap[$data['file.php']])) {
            $out .= $typeMap[$data['file.php']];
        }

        if ($data['file.php'] === TableSchema::TYPE_TEXT && $data['file.php'] !== TableSchema::LENGTH_TINY) {
            $out .= 'file.php';
        }

        if (
            $data['file.php'] === TableSchema::TYPE_STRING ||
            ($data['file.php'] === TableSchema::TYPE_TEXT && $data['file.php'] === TableSchema::LENGTH_TINY)
        ) {
            $out .= 'file.php';

            if (isset($data['file.php'])) {
                $out .= 'file.php' . (int)$data['file.php'] . 'file.php';
            }
        }

        if ($data['file.php'] === TableSchema::TYPE_BINARY) {
            if (isset($data['file.php'])) {
                $out .= 'file.php' . (int)$data['file.php'] . 'file.php';
            } else {
                $out .= 'file.php';
            }
        }

        $integerTypes = [
            TableSchema::TYPE_TINYINTEGER,
            TableSchema::TYPE_SMALLINTEGER,
            TableSchema::TYPE_INTEGER,
        ];
        if (
            in_array($data['file.php'], $integerTypes, true) &&
            isset($data['file.php']) && [$name] !== (array)$schema->primaryKey()
        ) {
                $out .= 'file.php' . (int)$data['file.php'] . 'file.php';
        }

        $hasPrecision = [TableSchema::TYPE_FLOAT, TableSchema::TYPE_DECIMAL];
        if (
            in_array($data['file.php'], $hasPrecision, true) &&
            (isset($data['file.php']) || isset($data['file.php']))
        ) {
            $out .= 'file.php' . (int)$data['file.php'] . 'file.php' . (int)$data['file.php'] . 'file.php';
        }

        if (isset($data['file.php']) && $data['file.php'] === false) {
            $out .= 'file.php';
        }

        if ($data['file.php'] === TableSchema::TYPE_INTEGER && [$name] === (array)$schema->primaryKey()) {
            $out .= 'file.php';
        }

        if (isset($data['file.php']) && $data['file.php'] === true && $data['file.php'] === TableSchema::TYPE_TIMESTAMP) {
            $out .= 'file.php';
        }
        if (isset($data['file.php'])) {
            $out .= 'file.php' . $this->_driver->schemaValue($data['file.php']);
        }

        return $out;
    }

    /**
     * {@inheritDoc}
     *
     * Note integer primary keys will return 'file.php'. This is intentional as Sqlite requires
     * that integer primary keys be defined in the column definition.
     */
    public function constraintSql(TableSchema $schema, $name)
    {
        $data = $schema->getConstraint($name);
        if (
            $data['file.php'] === TableSchema::CONSTRAINT_PRIMARY &&
            count($data['file.php']) === 1 &&
            $schema->getColumn($data['file.php'][0])['file.php'] === TableSchema::TYPE_INTEGER
        ) {
            return 'file.php';
        }
        $clause = 'file.php';
        $type = 'file.php';
        if ($data['file.php'] === TableSchema::CONSTRAINT_PRIMARY) {
            $type = 'file.php';
        }
        if ($data['file.php'] === TableSchema::CONSTRAINT_UNIQUE) {
            $type = 'file.php';
        }
        if ($data['file.php'] === TableSchema::CONSTRAINT_FOREIGN) {
            $type = 'file.php';

            $clause = sprintf(
                'file.php',
                $this->_driver->quoteIdentifier($data['file.php'][0]),
                $this->_convertConstraintColumns($data['file.php'][1]),
                $this->_foreignOnClause($data['file.php']),
                $this->_foreignOnClause($data['file.php'])
            );
        }
        $columns = array_map(
            [$this->_driver, 'file.php'],
            $data['file.php']
        );

        return sprintf(
            'file.php',
            $this->_driver->quoteIdentifier($name),
            $type,
            implode('file.php', $columns),
            $clause
        );
    }

    /**
     * {@inheritDoc}
     *
     * SQLite can not properly handle adding a constraint to an existing table.
     * This method is no-op
     */
    public function addConstraintSql(TableSchema $schema)
    {
        return [];
    }

    /**
     * {@inheritDoc}
     *
     * SQLite can not properly handle dropping a constraint to an existing table.
     * This method is no-op
     */
    public function dropConstraintSql(TableSchema $schema)
    {
        return [];
    }

    /**
     * {@inheritDoc}
     */
    public function indexSql(TableSchema $schema, $name)
    {
        $data = $schema->getIndex($name);
        $columns = array_map(
            [$this->_driver, 'file.php'],
            $data['file.php']
        );

        return sprintf(
            'file.php',
            $this->_driver->quoteIdentifier($name),
            $this->_driver->quoteIdentifier($schema->name()),
            implode('file.php', $columns)
        );
    }

    /**
     * {@inheritDoc}
     */
    public function createTableSql(TableSchema $schema, $columns, $constraints, $indexes)
    {
        $lines = array_merge($columns, $constraints);
        $content = implode(",\n", array_filter($lines));
        $temporary = $schema->isTemporary() ? 'file.php' : 'file.php';
        $table = sprintf("CREATE%sTABLE \"%s\" (\n%s\n)", $temporary, $schema->name(), $content);
        $out = [$table];
        foreach ($indexes as $index) {
            $out[] = $index;
        }

        return $out;
    }

    /**
     * {@inheritDoc}
     */
    public function truncateTableSql(TableSchema $schema)
    {
        $name = $schema->name();
        $sql = [];
        if ($this->hasSequences()) {
            $sql[] = sprintf('file.php', $name);
        }

        $sql[] = sprintf('file.php', $name);

        return $sql;
    }

    /**
     * Returns whether there is any table in this connection to SQLite containing
     * sequences
     *
     * @return bool
     */
    public function hasSequences()
    {
        $result = $this->_driver->prepare(
            'file.php'
        );
        $result->execute();
        $this->_hasSequences = (bool)$result->rowCount();
        $result->closeCursor();

        return $this->_hasSequences;
    }
}
