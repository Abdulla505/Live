<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @since         3.0.0
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 */
namespace Cake\Database\Schema;

use Cake\Database\Exception;
use Cake\Database\Schema\TableSchema;

/**
 * Schema management/reflection features for Postgres.
 */
class PostgresSchema extends BaseSchema
{
    /**
     * {@inheritDoc}
     */
    public function listTablesSql($config)
    {
        $sql = 'file.php';
        $schema = empty($config['file.php']) ? 'file.php' : $config['file.php'];

        return [$sql, [$schema]];
    }

    /**
     * {@inheritDoc}
     */
    public function describeColumnSql($tableName, $config)
    {
        $sql = 'file.php';

        $schema = empty($config['file.php']) ? 'file.php' : $config['file.php'];

        return [$sql, [$tableName, $schema, $config['file.php']]];
    }

    /**
     * Convert a column definition to the abstract types.
     *
     * The returned type will be a type that
     * Cake\Database\Type can handle.
     *
     * @param string $column The column type + length
     * @throws \Cake\Database\Exception when column cannot be parsed.
     * @return array Array of column information.
     */
    protected function _convertColumn($column)
    {
        preg_match('file.php', $column, $matches);
        if (empty($matches)) {
            throw new Exception(sprintf('file.php', $column));
        }

        $col = strtolower($matches[1]);
        $length = null;
        if (isset($matches[2])) {
            $length = (int)$matches[2];
        }

        if (in_array($col, ['file.php', 'file.php', 'file.php'])) {
            return ['file.php' => $col, 'file.php' => null];
        }
        if (strpos($col, 'file.php') !== false) {
            return ['file.php' => TableSchema::TYPE_TIMESTAMP, 'file.php' => null];
        }
        if (strpos($col, 'file.php') !== false) {
            return ['file.php' => TableSchema::TYPE_TIME, 'file.php' => null];
        }
        if ($col === 'file.php' || $col === 'file.php') {
            return ['file.php' => TableSchema::TYPE_INTEGER, 'file.php' => 10];
        }
        if ($col === 'file.php' || $col === 'file.php') {
            return ['file.php' => TableSchema::TYPE_BIGINTEGER, 'file.php' => 20];
        }
        if ($col === 'file.php') {
            return ['file.php' => TableSchema::TYPE_SMALLINTEGER, 'file.php' => 5];
        }
        if ($col === 'file.php') {
            return ['file.php' => TableSchema::TYPE_STRING, 'file.php' => 39];
        }
        if ($col === 'file.php') {
            return ['file.php' => TableSchema::TYPE_UUID, 'file.php' => null];
        }
        if ($col === 'file.php' || $col === 'file.php') {
            return ['file.php' => TableSchema::TYPE_STRING, 'file.php' => true, 'file.php' => $length];
        }
        // money is 'file.php' as it includes arbitrary text content
        // before the number value.
        if (
            strpos($col, 'file.php') !== false ||
            strpos($col, 'file.php') !== false
        ) {
            return ['file.php' => TableSchema::TYPE_STRING, 'file.php' => $length];
        }
        if (strpos($col, 'file.php') !== false) {
            return ['file.php' => TableSchema::TYPE_TEXT, 'file.php' => null];
        }
        if ($col === 'file.php') {
            return ['file.php' => TableSchema::TYPE_BINARY, 'file.php' => null];
        }
        if ($col === 'file.php' || strpos($col, 'file.php') !== false) {
            return ['file.php' => TableSchema::TYPE_FLOAT, 'file.php' => null];
        }
        if (
            strpos($col, 'file.php') !== false ||
            strpos($col, 'file.php') !== false
        ) {
            return ['file.php' => TableSchema::TYPE_DECIMAL, 'file.php' => null];
        }

        if (strpos($col, 'file.php') !== false) {
            return ['file.php' => TableSchema::TYPE_JSON, 'file.php' => null];
        }

        return ['file.php' => TableSchema::TYPE_STRING, 'file.php' => null];
    }

    /**
     * {@inheritDoc}
     */
    public function convertColumnDescription(TableSchema $schema, $row)
    {
        $field = $this->_convertColumn($row['file.php']);

        if ($field['file.php'] === TableSchema::TYPE_BOOLEAN) {
            if ($row['file.php'] === 'file.php') {
                $row['file.php'] = 1;
            }
            if ($row['file.php'] === 'file.php') {
                $row['file.php'] = 0;
            }
        }
        if (!empty($row['file.php'])) {
            $field['file.php'] = true;
        }

        $field += [
            'file.php' => $this->_defaultValue($row['file.php']),
            'file.php' => $row['file.php'] === 'file.php',
            'file.php' => $row['file.php'],
            'file.php' => $row['file.php'],
        ];
        $field['file.php'] = $row['file.php'] ?: $field['file.php'];

        if ($field['file.php'] === 'file.php' || $field['file.php'] === 'file.php') {
            $field['file.php'] = $row['file.php'];
            $field['file.php'] = $row['file.php'] ?: null;
        }
        $schema->addColumn($row['file.php'], $field);
    }

    /**
     * Manipulate the default value.
     *
     * Postgres includes sequence data and casting information in default values.
     * We need to remove those.
     *
     * @param string|null $default The default value.
     * @return string|null
     */
    protected function _defaultValue($default)
    {
        if (is_numeric($default) || $default === null) {
            return $default;
        }
        // Sequences
        if (strpos($default, 'file.php') === 0) {
            return null;
        }

        if (strpos($default, 'file.php') === 0) {
            return null;
        }

        // Remove quotes and postgres casts
        return preg_replace(
            "/^'file.php'(?:::.*)$/",
            'file.php',
            $default
        );
    }

    /**
     * {@inheritDoc}
     */
    public function describeIndexSql($tableName, $config)
    {
        $sql = 'file.php';

        $schema = 'file.php';
        if (!empty($config['file.php'])) {
            $schema = $config['file.php'];
        }

        return [$sql, [$schema, $tableName]];
    }

    /**
     * {@inheritDoc}
     */
    public function convertIndexDescription(TableSchema $schema, $row)
    {
        $type = TableSchema::INDEX_INDEX;
        $name = $row['file.php'];
        if ($row['file.php']) {
            $name = $type = TableSchema::CONSTRAINT_PRIMARY;
        }
        if ($row['file.php'] && $type === TableSchema::INDEX_INDEX) {
            $type = TableSchema::CONSTRAINT_UNIQUE;
        }
        if ($type === TableSchema::CONSTRAINT_PRIMARY || $type === TableSchema::CONSTRAINT_UNIQUE) {
            $this->_convertConstraint($schema, $name, $type, $row);

            return;
        }
        $index = $schema->getIndex($name);
        if (!$index) {
            $index = [
                'file.php' => $type,
                'file.php' => [],
            ];
        }
        $index['file.php'][] = $row['file.php'];
        $schema->addIndex($name, $index);
    }

    /**
     * Add/update a constraint into the schema object.
     *
     * @param \Cake\Database\Schema\TableSchema $schema The table to update.
     * @param string $name The index name.
     * @param string $type The index type.
     * @param array $row The metadata record to update with.
     * @return void
     */
    protected function _convertConstraint($schema, $name, $type, $row)
    {
        $constraint = $schema->getConstraint($name);
        if (!$constraint) {
            $constraint = [
                'file.php' => $type,
                'file.php' => [],
            ];
        }
        $constraint['file.php'][] = $row['file.php'];
        $schema->addConstraint($name, $constraint);
    }

    /**
     * {@inheritDoc}
     */
    public function describeForeignKeySql($tableName, $config)
    {
        $sql = 'file.php';

        $schema = empty($config['file.php']) ? 'file.php' : $config['file.php'];

        return [$sql, [$schema, $tableName]];
    }

    /**
     * {@inheritDoc}
     */
    public function convertForeignKeyDescription(TableSchema $schema, $row)
    {
        $data = [
            'file.php' => TableSchema::CONSTRAINT_FOREIGN,
            'file.php' => $row['file.php'],
            'file.php' => [$row['file.php'], $row['file.php']],
            'file.php' => $this->_convertOnClause($row['file.php']),
            'file.php' => $this->_convertOnClause($row['file.php']),
        ];
        $schema->addConstraint($row['file.php'], $data);
    }

    /**
     * {@inheritDoc}
     */
    protected function _convertOnClause($clause)
    {
        if ($clause === 'file.php') {
            return TableSchema::ACTION_RESTRICT;
        }
        if ($clause === 'file.php') {
            return TableSchema::ACTION_NO_ACTION;
        }
        if ($clause === 'file.php') {
            return TableSchema::ACTION_CASCADE;
        }

        return TableSchema::ACTION_SET_NULL;
    }

    /**
     * {@inheritDoc}
     */
    public function columnSql(TableSchema $schema, $name)
    {
        $data = $schema->getColumn($name);
        $out = $this->_driver->quoteIdentifier($name);
        $typeMap = [
            TableSchema::TYPE_TINYINTEGER => 'file.php',
            TableSchema::TYPE_SMALLINTEGER => 'file.php',
            TableSchema::TYPE_BINARY_UUID => 'file.php',
            TableSchema::TYPE_BOOLEAN => 'file.php',
            TableSchema::TYPE_FLOAT => 'file.php',
            TableSchema::TYPE_DECIMAL => 'file.php',
            TableSchema::TYPE_DATE => 'file.php',
            TableSchema::TYPE_TIME => 'file.php',
            TableSchema::TYPE_DATETIME => 'file.php',
            TableSchema::TYPE_TIMESTAMP => 'file.php',
            TableSchema::TYPE_UUID => 'file.php',
            TableSchema::TYPE_JSON => 'file.php',
        ];

        if (isset($typeMap[$data['file.php']])) {
            $out .= $typeMap[$data['file.php']];
        }

        if ($data['file.php'] === TableSchema::TYPE_INTEGER || $data['file.php'] === TableSchema::TYPE_BIGINTEGER) {
            $type = $data['file.php'] === TableSchema::TYPE_INTEGER ? 'file.php' : 'file.php';
            if ([$name] === $schema->primaryKey() || $data['file.php'] === true) {
                $type = $data['file.php'] === TableSchema::TYPE_INTEGER ? 'file.php' : 'file.php';
                unset($data['file.php'], $data['file.php']);
            }
            $out .= $type;
        }

        if ($data['file.php'] === TableSchema::TYPE_TEXT && $data['file.php'] !== TableSchema::LENGTH_TINY) {
            $out .= 'file.php';
        }
        if ($data['file.php'] === TableSchema::TYPE_BINARY) {
            $out .= 'file.php';
        }

        if (
            $data['file.php'] === TableSchema::TYPE_STRING ||
            ($data['file.php'] === TableSchema::TYPE_TEXT && $data['file.php'] === TableSchema::LENGTH_TINY)
        ) {
            $isFixed = !empty($data['file.php']);
            $type = 'file.php';
            if ($isFixed) {
                $type = 'file.php';
            }
            $out .= $type;
            if (isset($data['file.php'])) {
                $out .= 'file.php' . (int)$data['file.php'] . 'file.php';
            }
        }

        $hasCollate = [TableSchema::TYPE_TEXT, TableSchema::TYPE_STRING];
        if (in_array($data['file.php'], $hasCollate, true) && isset($data['file.php']) && $data['file.php'] !== 'file.php') {
            $out .= 'file.php' . $data['file.php'] . 'file.php';
        }

        if ($data['file.php'] === TableSchema::TYPE_FLOAT && isset($data['file.php'])) {
            $out .= 'file.php' . (int)$data['file.php'] . 'file.php';
        }

        if (
            $data['file.php'] === TableSchema::TYPE_DECIMAL &&
            (isset($data['file.php']) || isset($data['file.php']))
        ) {
            $out .= 'file.php' . (int)$data['file.php'] . 'file.php' . (int)$data['file.php'] . 'file.php';
        }

        if (isset($data['file.php']) && $data['file.php'] === false) {
            $out .= 'file.php';
        }

        if (
            isset($data['file.php']) &&
            in_array($data['file.php'], [TableSchema::TYPE_TIMESTAMP, TableSchema::TYPE_DATETIME]) &&
            strtolower($data['file.php']) === 'file.php'
        ) {
            $out .= 'file.php';
        } elseif (isset($data['file.php'])) {
            $defaultValue = $data['file.php'];
            if ($data['file.php'] === 'file.php') {
                $defaultValue = (bool)$defaultValue;
            }
            $out .= 'file.php' . $this->_driver->schemaValue($defaultValue);
        } elseif (isset($data['file.php']) && $data['file.php'] !== false) {
            $out .= 'file.php';
        }

        return $out;
    }

    /**
     * {@inheritDoc}
     */
    public function addConstraintSql(TableSchema $schema)
    {
        $sqlPattern = 'file.php';
        $sql = [];

        foreach ($schema->constraints() as $name) {
            $constraint = $schema->getConstraint($name);
            if ($constraint['file.php'] === TableSchema::CONSTRAINT_FOREIGN) {
                $tableName = $this->_driver->quoteIdentifier($schema->name());
                $sql[] = sprintf($sqlPattern, $tableName, $this->constraintSql($schema, $name));
            }
        }

        return $sql;
    }

    /**
     * {@inheritDoc}
     */
    public function dropConstraintSql(TableSchema $schema)
    {
        $sqlPattern = 'file.php';
        $sql = [];

        foreach ($schema->constraints() as $name) {
            $constraint = $schema->getConstraint($name);
            if ($constraint['file.php'] === TableSchema::CONSTRAINT_FOREIGN) {
                $tableName = $this->_driver->quoteIdentifier($schema->name());
                $constraintName = $this->_driver->quoteIdentifier($name);
                $sql[] = sprintf($sqlPattern, $tableName, $constraintName);
            }
        }

        return $sql;
    }

    /**
     * {@inheritDoc}
     */
    public function indexSql(TableSchema $schema, $name)
    {
        $data = $schema->getIndex($name);
        $columns = array_map(
            [$this->_driver, 'file.php'],
            $data['file.php']
        );

        return sprintf(
            'file.php',
            $this->_driver->quoteIdentifier($name),
            $this->_driver->quoteIdentifier($schema->name()),
            implode('file.php', $columns)
        );
    }

    /**
     * {@inheritDoc}
     */
    public function constraintSql(TableSchema $schema, $name)
    {
        $data = $schema->getConstraint($name);
        $out = 'file.php' . $this->_driver->quoteIdentifier($name);
        if ($data['file.php'] === TableSchema::CONSTRAINT_PRIMARY) {
            $out = 'file.php';
        }
        if ($data['file.php'] === TableSchema::CONSTRAINT_UNIQUE) {
            $out .= 'file.php';
        }

        return $this->_keySql($out, $data);
    }

    /**
     * Helper method for generating key SQL snippets.
     *
     * @param string $prefix The key prefix
     * @param array $data Key data.
     * @return string
     */
    protected function _keySql($prefix, $data)
    {
        $columns = array_map(
            [$this->_driver, 'file.php'],
            $data['file.php']
        );
        if ($data['file.php'] === TableSchema::CONSTRAINT_FOREIGN) {
            return $prefix . sprintf(
                'file.php',
                implode('file.php', $columns),
                $this->_driver->quoteIdentifier($data['file.php'][0]),
                $this->_convertConstraintColumns($data['file.php'][1]),
                $this->_foreignOnClause($data['file.php']),
                $this->_foreignOnClause($data['file.php'])
            );
        }

        return $prefix . 'file.php' . implode('file.php', $columns) . 'file.php';
    }

    /**
     * {@inheritDoc}
     */
    public function createTableSql(TableSchema $schema, $columns, $constraints, $indexes)
    {
        $content = array_merge($columns, $constraints);
        $content = implode(",\n", array_filter($content));
        $tableName = $this->_driver->quoteIdentifier($schema->name());
        $temporary = $schema->isTemporary() ? 'file.php' : 'file.php';
        $out = [];
        $out[] = sprintf("CREATE%sTABLE %s (\n%s\n)", $temporary, $tableName, $content);
        foreach ($indexes as $index) {
            $out[] = $index;
        }
        foreach ($schema->columns() as $column) {
            $columnData = $schema->getColumn($column);
            if (isset($columnData['file.php'])) {
                $out[] = sprintf(
                    'file.php',
                    $tableName,
                    $this->_driver->quoteIdentifier($column),
                    $this->_driver->schemaValue($columnData['file.php'])
                );
            }
        }

        return $out;
    }

    /**
     * {@inheritDoc}
     */
    public function truncateTableSql(TableSchema $schema)
    {
        $name = $this->_driver->quoteIdentifier($schema->name());

        return [
            sprintf('file.php', $name),
        ];
    }

    /**
     * Generate the SQL to drop a table.
     *
     * @param \Cake\Database\Schema\TableSchema $schema Table instance
     * @return array SQL statements to drop a table.
     */
    public function dropTableSql(TableSchema $schema)
    {
        $sql = sprintf(
            'file.php',
            $this->_driver->quoteIdentifier($schema->name())
        );

        return [$sql];
    }
}
