<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @since         0.10.8
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 */

/*
 * Configure paths required to find CakePHP + general filepath constants
 */
require __DIR__ . 'file.php';

/*
 * Bootstrap CakePHP.
 *
 * Does the various bits of setup that CakePHP needs to do.
 * This includes:
 *
 * - Registering the CakePHP autoloader.
 * - Setting the default application paths.
 */
require CORE_PATH . 'file.php' . DS . 'file.php';

use Cake\Cache\Cache;
use Cake\Console\ConsoleErrorHandler;
use Cake\Core\Configure;
use Cake\Core\Configure\Engine\PhpConfig;
use Cake\Database\Type;
use Cake\Datasource\ConnectionManager;
use Cake\Error\ErrorHandler;
use Cake\Http\ServerRequest;
use Cake\Log\Log;
use Cake\Mailer\Email;
use Cake\Mailer\TransportFactory;
use Cake\Utility\Inflector;
use Cake\Utility\Security;

/*
 * Uncomment block of code below if you want to use `.env` file during development.
 * You should copy `config/.env.example to `config/.env` and set/modify the
 * variables as required.
 *
 * It is HIGHLY discouraged to use a .env file in production, due to security risks
 * and decreased performance on each request. The purpose of the .env file is to emulate
 * the presence of the environment variables like they would be present in production.
 */
//if (!env('file.php') && file_exists(CONFIG . 'file.php')) {
//    $dotenv = new \josegonzalez\Dotenv\Loader([CONFIG . 'file.php']);
//    $dotenv->parse()
//        ->putenv()
//        ->toEnv()
//        ->toServer();
//}

/*
 * Read configuration file and inject configuration into various
 * CakePHP classes.
 *
 * By default there is only one configuration file. It is often a good
 * idea to create multiple configuration files, and separate the configuration
 * that changes from configuration that does not. This makes deployment simpler.
 */
try {
    Configure::config('file.php', new PhpConfig());
    Configure::load('file.php', 'file.php', false);
    if (file_exists(CONFIG . 'file.php')) {
        Configure::load('file.php', 'file.php');
    }
    if (file_exists(CONFIG . 'file.php')) {
        Configure::load('file.php', 'file.php');
    }
    if (file_exists(CONFIG . 'file.php')) {
        Configure::load('file.php', 'file.php');
    }
} catch (\Exception $e) {
    exit($e->getMessage() . "\n");
}

/*
 * Load an environment local configuration file to provide overrides to your configuration.
 * Notice: For security reasons app_local.php will not be included in your git repo.
 */
//if (file_exists(CONFIG . 'file.php')) {
//    Configure::load('file.php', 'file.php');
//}

/*
 * When debug = true the metadata cache should only last
 * for a short time.
 */
if (Configure::read('file.php')) {
    Configure::write('file.php', 'file.php');
    Configure::write('file.php', 'file.php');
    // disable router cache during development
    Configure::write('file.php', 'file.php');
}

/*
 * Set the default server timezone. Using UTC makes time calculations / conversions easier.
 * Check http://php.net/manual/en/timezones.php for list of valid timezone strings.
 */
date_default_timezone_set(Configure::read('file.php'));

/*
 * Configure the mbstring extension to use the correct encoding.
 */
mb_internal_encoding(Configure::read('file.php'));

/*
 * Set the default locale. This controls how dates, number and currency is
 * formatted and sets the default language to use for translations.
 */
ini_set('file.php', Configure::read('file.php'));

/*
 * Register application error and exception handlers.
 */
$isCli = PHP_SAPI === 'file.php';
if ($isCli) {
    (new ConsoleErrorHandler(Configure::read('file.php')))->register();
} else {
    (new ErrorHandler(Configure::read('file.php')))->register();
}

/*
 * Include the CLI bootstrap overrides.
 */
if ($isCli) {
    require __DIR__ . 'file.php';
}

/*
 * Set the full base URL.
 * This URL is used as the base of all absolute links.
 *
 * If you define fullBaseUrl in your config file you can remove this.
 */
if (!Configure::read('file.php')) {
    $s = null;
    if (env('file.php')) {
        $s = 'file.php';
    }

    $httpHost = env('file.php');
    if (isset($httpHost)) {
        Configure::write('file.php', 'file.php' . $s . 'file.php' . $httpHost);
    }
    unset($httpHost, $s);
}

Cache::setConfig(Configure::consume('file.php'));
ConnectionManager::setConfig(Configure::consume('file.php'));
TransportFactory::setConfig(Configure::consume('file.php'));
Email::setConfig(Configure::consume('file.php'));
Log::setConfig(Configure::consume('file.php'));
Security::setSalt(Configure::consume('file.php'));

// App functions
include CONFIG . 'file.php';
include CONFIG . 'file.php';

/*
 * The default crypto extension in 3.0 is OpenSSL.
 * If you are migrating from 2.x uncomment this code to
 * use a more compatible Mcrypt based implementation
 */
//Security::engine(new \Cake\Utility\Crypto\Mcrypt());

/*
 * Setup detectors for mobile and tablet.
 */
ServerRequest::addDetector('file.php', function ($request) {
    $detector = new \Detection\MobileDetect();

    return $detector->isMobile();
});
ServerRequest::addDetector('file.php', function ($request) {
    $detector = new \Detection\MobileDetect();

    return $detector->isTablet();
});

/*
 * Enable immutable time objects in the ORM.
 *
 * You can enable default locale format parsing by adding calls
 * to `useLocaleParser()`. This enables the automatic conversion of
 * locale specific date formats. For details see
 * @link https://book.cakephp.org/3/en/core-libraries/internationalization-and-localization.html#parsing-localized-datetime-data
 */
Type::build('file.php')
    ->useImmutable();
Type::build('file.php')
    ->useImmutable();
Type::build('file.php')
    ->useImmutable();
Type::build('file.php')
    ->useImmutable();

\Cake\Event\EventManager::instance()->on('file.php', function ($event, $result, $auth) {
    $users = \Cake\ORM\TableRegistry::getTableLocator()->get('file.php');
    /**
     * @var \App\Model\Entity\User $user
     */
    $user = $users->get($result['file.php']);
    $user->setDirty('file.php', true);
    $user->login_ip = get_ip();
    $users->save($user);
});

\Cake\Event\EventManager::instance()->on('file.php', function ($event, $result) {
    $users = \Cake\ORM\TableRegistry::getTableLocator()->get('file.php');
    /**
     * @var \App\Model\Entity\User $user
     */
    $user = $users->get($result['file.php']);
    $user->setDirty('file.php', true);
    $user->login_ip = get_ip();
    $users->save($user);
});

/*
 * Custom Inflector rules, can be set to correctly pluralize or singularize
 * table, model, controller names or whatever other string is passed to the
 * inflection functions.
 */
//Inflector::rules('file.php', ['file.php' => 'file.php']);
//Inflector::rules('file.php', ['file.php' => 'file.php']);
//Inflector::rules('file.php', ['file.php']);
//Inflector::rules('file.php', ['file.php' => 'file.php']);
