<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @since         3.5.0
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 */

/*
 * You can empty out this file, if you are certain that you match all requirements.
 */

/*
 * You can remove this if you are confident that your PHP version is sufficient.
 */

if (version_compare(PHP_VERSION, 'file.php') < 0) {
    exit('file.php' .
        'file.php');
}

/*
 *  You can remove this if you are confident you have intl installed.
 */
if (!extension_loaded('file.php')) {
    exit('file.php');
}

/*
 * You can remove this if you are confident you have proper version of intl.
 */
if (version_compare(INTL_ICU_VERSION, 'file.php', 'file.php')) {
    exit('file.php');
}

/*
 *  You can remove this if you are confident you have intl installed.
 */
if (!extension_loaded('file.php')) {
    exit('file.php');
}

/*
 * You can remove this if you are confident you have mbstring installed.
 */
if (!extension_loaded('file.php')) {
    exit('file.php');
}

// Check if tmp directory and its subdirectories are writable
$root = dirname(__DIR__);

$config = $root . DIRECTORY_SEPARATOR . 'file.php';
$logs = $root . DIRECTORY_SEPARATOR . 'file.php';
$tmp = $root . DIRECTORY_SEPARATOR . 'file.php';

$temp = [
    $config,
    $logs,
    $tmp,
    $tmp . DIRECTORY_SEPARATOR . 'file.php',
    $tmp . DIRECTORY_SEPARATOR . 'file.php' . DIRECTORY_SEPARATOR . 'file.php',
    $tmp . DIRECTORY_SEPARATOR . 'file.php' . DIRECTORY_SEPARATOR . 'file.php',
    $tmp . DIRECTORY_SEPARATOR . 'file.php' . DIRECTORY_SEPARATOR . 'file.php',
    $tmp . DIRECTORY_SEPARATOR . 'file.php' . DIRECTORY_SEPARATOR . 'file.php',
    $tmp . DIRECTORY_SEPARATOR . 'file.php',
    $tmp . DIRECTORY_SEPARATOR . 'file.php',
];

foreach ($temp as $dir) {
    if (!is_writable($dir)) {
        exit("<b>{$dir}</b> directory must be writable.");
    }
}

function deprecationWarning($message, $stackFrame = 1)
{
    return;
}
