<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @since         2.0.0
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 */
namespace Cake\Http;

use Cake\Core\Configure;
use Cake\Filesystem\File;
use Cake\Filesystem\Folder;
use Cake\Http\Cookie\Cookie;
use Cake\Http\Cookie\CookieCollection;
use Cake\Http\Cookie\CookieInterface;
use Cake\Http\CorsBuilder;
use Cake\Http\Exception\NotFoundException;
use Cake\Log\Log;
use DateTime;
use DateTimeInterface;
use DateTimeZone;
use InvalidArgumentException;
use Laminas\Diactoros\MessageTrait;
use Laminas\Diactoros\Stream;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\StreamInterface;

/**
 * Responses contain the response text, status and headers of a HTTP response.
 *
 * There are external packages such as `fig/http-message-util` that provide HTTP
 * status code constants. These can be used with any method that accepts or
 * returns a status code integer. Keep in mind that these consants might
 * include status codes that are now allowed which will throw an
 * `\InvalidArgumentException`.
 */
class Response implements ResponseInterface
{
    use MessageTrait;

    /**
     * @var int
     */
    const STATUS_CODE_MIN = 100;

    /**
     * @var int
     */
    const STATUS_CODE_MAX = 599;

    /**
     * Allowed HTTP status codes and their default description.
     *
     * @var string[]
     */
    protected $_statusCodes = [
        100 => 'file.php',
        101 => 'file.php',
        102 => 'file.php',
        200 => 'file.php',
        201 => 'file.php',
        202 => 'file.php',
        203 => 'file.php',
        204 => 'file.php',
        205 => 'file.php',
        206 => 'file.php',
        207 => 'file.php',
        208 => 'file.php',
        226 => 'file.php',
        300 => 'file.php',
        301 => 'file.php',
        302 => 'file.php',
        303 => 'file.php',
        304 => 'file.php',
        305 => 'file.php',
        306 => 'file.php',
        307 => 'file.php',
        308 => 'file.php',
        400 => 'file.php',
        401 => 'file.php',
        402 => 'file.php',
        403 => 'file.php',
        404 => 'file.php',
        405 => 'file.php',
        406 => 'file.php',
        407 => 'file.php',
        408 => 'file.php',
        409 => 'file.php',
        410 => 'file.php',
        411 => 'file.php',
        412 => 'file.php',
        413 => 'file.php',
        414 => 'file.php',
        415 => 'file.php',
        416 => 'file.php',
        417 => 'file.php',
        418 => 'file.php'm a teapot'file.php'Misdirected Request'file.php'Unprocessable Entity'file.php'Locked'file.php'Failed Dependency'file.php'Unordered Collection'file.php'Upgrade Required'file.php'Precondition Required'file.php'Too Many Requests'file.php'Request Header Fields Too Large'file.php'Connection Closed Without Response'file.php'Unavailable For Legal Reasons'file.php'Client Closed Request'file.php'Internal Server Error'file.php'Not Implemented'file.php'Bad Gateway'file.php'Service Unavailable'file.php'Gateway Timeout'file.php'Unsupported Version'file.php'Variant Also Negotiates'file.php'Insufficient Storage'file.php'Loop Detected'file.php'Not Extended'file.php'Network Authentication Required'file.php'Network Connect Timeout Error'file.php'html'file.php'text/html'file.php'*/*'file.php'json'file.php'application/json'file.php'xml'file.php'application/xml'file.php'text/xml'file.php'xhtml'file.php'application/xhtml+xml'file.php'application/xhtml'file.php'text/xhtml'file.php'webp'file.php'image/webp'file.php'rss'file.php'application/rss+xml'file.php'ai'file.php'application/postscript'file.php'bcpio'file.php'application/x-bcpio'file.php'bin'file.php'application/octet-stream'file.php'ccad'file.php'application/clariscad'file.php'cdf'file.php'application/x-netcdf'file.php'class'file.php'application/octet-stream'file.php'cpio'file.php'application/x-cpio'file.php'cpt'file.php'application/mac-compactpro'file.php'csh'file.php'application/x-csh'file.php'csv'file.php'text/csv'file.php'application/vnd.ms-excel'file.php'dcr'file.php'application/x-director'file.php'dir'file.php'application/x-director'file.php'dms'file.php'application/octet-stream'file.php'doc'file.php'application/msword'file.php'docx'file.php'application/vnd.openxmlformats-officedocument.wordprocessingml.document'file.php'drw'file.php'application/drafting'file.php'dvi'file.php'application/x-dvi'file.php'dwg'file.php'application/acad'file.php'dxf'file.php'application/dxf'file.php'dxr'file.php'application/x-director'file.php'eot'file.php'application/vnd.ms-fontobject'file.php'eps'file.php'application/postscript'file.php'exe'file.php'application/octet-stream'file.php'ez'file.php'application/andrew-inset'file.php'flv'file.php'video/x-flv'file.php'gtar'file.php'application/x-gtar'file.php'gz'file.php'application/x-gzip'file.php'bz2'file.php'application/x-bzip'file.php'7z'file.php'application/x-7z-compressed'file.php'hdf'file.php'application/x-hdf'file.php'hqx'file.php'application/mac-binhex40'file.php'ico'file.php'image/x-icon'file.php'ips'file.php'application/x-ipscript'file.php'ipx'file.php'application/x-ipix'file.php'js'file.php'application/javascript'file.php'jsonapi'file.php'application/vnd.api+json'file.php'latex'file.php'application/x-latex'file.php'lha'file.php'application/octet-stream'file.php'lsp'file.php'application/x-lisp'file.php'lzh'file.php'application/octet-stream'file.php'man'file.php'application/x-troff-man'file.php'me'file.php'application/x-troff-me'file.php'mif'file.php'application/vnd.mif'file.php'ms'file.php'application/x-troff-ms'file.php'nc'file.php'application/x-netcdf'file.php'oda'file.php'application/oda'file.php'otf'file.php'font/otf'file.php'pdf'file.php'application/pdf'file.php'pgn'file.php'application/x-chess-pgn'file.php'pot'file.php'application/vnd.ms-powerpoint'file.php'pps'file.php'application/vnd.ms-powerpoint'file.php'ppt'file.php'application/vnd.ms-powerpoint'file.php'pptx'file.php'application/vnd.openxmlformats-officedocument.presentationml.presentation'file.php'ppz'file.php'application/vnd.ms-powerpoint'file.php'pre'file.php'application/x-freelance'file.php'prt'file.php'application/pro_eng'file.php'ps'file.php'application/postscript'file.php'roff'file.php'application/x-troff'file.php'scm'file.php'application/x-lotusscreencam'file.php'set'file.php'application/set'file.php'sh'file.php'application/x-sh'file.php'shar'file.php'application/x-shar'file.php'sit'file.php'application/x-stuffit'file.php'skd'file.php'application/x-koan'file.php'skm'file.php'application/x-koan'file.php'skp'file.php'application/x-koan'file.php'skt'file.php'application/x-koan'file.php'smi'file.php'application/smil'file.php'smil'file.php'application/smil'file.php'sol'file.php'application/solids'file.php'spl'file.php'application/x-futuresplash'file.php'src'file.php'application/x-wais-source'file.php'step'file.php'application/STEP'file.php'stl'file.php'application/SLA'file.php'stp'file.php'application/STEP'file.php'sv4cpio'file.php'application/x-sv4cpio'file.php'sv4crc'file.php'application/x-sv4crc'file.php'svg'file.php'image/svg+xml'file.php'svgz'file.php'image/svg+xml'file.php'swf'file.php'application/x-shockwave-flash'file.php't'file.php'application/x-troff'file.php'tar'file.php'application/x-tar'file.php'tcl'file.php'application/x-tcl'file.php'tex'file.php'application/x-tex'file.php'texi'file.php'application/x-texinfo'file.php'texinfo'file.php'application/x-texinfo'file.php'tr'file.php'application/x-troff'file.php'tsp'file.php'application/dsptype'file.php'ttc'file.php'font/ttf'file.php'ttf'file.php'font/ttf'file.php'unv'file.php'application/i-deas'file.php'ustar'file.php'application/x-ustar'file.php'vcd'file.php'application/x-cdlink'file.php'vda'file.php'application/vda'file.php'xlc'file.php'application/vnd.ms-excel'file.php'xll'file.php'application/vnd.ms-excel'file.php'xlm'file.php'application/vnd.ms-excel'file.php'xls'file.php'application/vnd.ms-excel'file.php'xlsx'file.php'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'file.php'xlw'file.php'application/vnd.ms-excel'file.php'zip'file.php'application/zip'file.php'aif'file.php'audio/x-aiff'file.php'aifc'file.php'audio/x-aiff'file.php'aiff'file.php'audio/x-aiff'file.php'au'file.php'audio/basic'file.php'kar'file.php'audio/midi'file.php'mid'file.php'audio/midi'file.php'midi'file.php'audio/midi'file.php'mp2'file.php'audio/mpeg'file.php'mp3'file.php'audio/mpeg'file.php'mpga'file.php'audio/mpeg'file.php'ogg'file.php'audio/ogg'file.php'oga'file.php'audio/ogg'file.php'spx'file.php'audio/ogg'file.php'ra'file.php'audio/x-realaudio'file.php'ram'file.php'audio/x-pn-realaudio'file.php'rm'file.php'audio/x-pn-realaudio'file.php'rpm'file.php'audio/x-pn-realaudio-plugin'file.php'snd'file.php'audio/basic'file.php'tsi'file.php'audio/TSP-audio'file.php'wav'file.php'audio/x-wav'file.php'aac'file.php'audio/aac'file.php'asc'file.php'text/plain'file.php'c'file.php'text/plain'file.php'cc'file.php'text/plain'file.php'css'file.php'text/css'file.php'etx'file.php'text/x-setext'file.php'f'file.php'text/plain'file.php'f90'file.php'text/plain'file.php'h'file.php'text/plain'file.php'hh'file.php'text/plain'file.php'htm'file.php'text/html'file.php'*/*'file.php'ics'file.php'text/calendar'file.php'm'file.php'text/plain'file.php'rtf'file.php'text/rtf'file.php'rtx'file.php'text/richtext'file.php'sgm'file.php'text/sgml'file.php'sgml'file.php'text/sgml'file.php'tsv'file.php'text/tab-separated-values'file.php'tpl'file.php'text/template'file.php'txt'file.php'text/plain'file.php'text'file.php'text/plain'file.php'avi'file.php'video/x-msvideo'file.php'fli'file.php'video/x-fli'file.php'mov'file.php'video/quicktime'file.php'movie'file.php'video/x-sgi-movie'file.php'mpe'file.php'video/mpeg'file.php'mpeg'file.php'video/mpeg'file.php'mpg'file.php'video/mpeg'file.php'qt'file.php'video/quicktime'file.php'viv'file.php'video/vnd.vivo'file.php'vivo'file.php'video/vnd.vivo'file.php'ogv'file.php'video/ogg'file.php'webm'file.php'video/webm'file.php'mp4'file.php'video/mp4'file.php'm4v'file.php'video/mp4'file.php'f4v'file.php'video/mp4'file.php'f4p'file.php'video/mp4'file.php'm4a'file.php'audio/mp4'file.php'f4a'file.php'audio/mp4'file.php'f4b'file.php'audio/mp4'file.php'gif'file.php'image/gif'file.php'ief'file.php'image/ief'file.php'jpg'file.php'image/jpeg'file.php'jpeg'file.php'image/jpeg'file.php'jpe'file.php'image/jpeg'file.php'pbm'file.php'image/x-portable-bitmap'file.php'pgm'file.php'image/x-portable-graymap'file.php'png'file.php'image/png'file.php'pnm'file.php'image/x-portable-anymap'file.php'ppm'file.php'image/x-portable-pixmap'file.php'ras'file.php'image/cmu-raster'file.php'rgb'file.php'image/x-rgb'file.php'tif'file.php'image/tiff'file.php'tiff'file.php'image/tiff'file.php'xbm'file.php'image/x-xbitmap'file.php'xpm'file.php'image/x-xpixmap'file.php'xwd'file.php'image/x-xwindowdump'file.php'psd'file.php'application/photoshop'file.php'application/psd'file.php'image/psd'file.php'image/x-photoshop'file.php'image/photoshop'file.php'zz-application/zz-winassoc-psd'file.php'ice'file.php'x-conference/x-cooltalk'file.php'iges'file.php'model/iges'file.php'igs'file.php'model/iges'file.php'mesh'file.php'model/mesh'file.php'msh'file.php'model/mesh'file.php'silo'file.php'model/mesh'file.php'vrml'file.php'model/vrml'file.php'wrl'file.php'model/vrml'file.php'mime'file.php'www/mime'file.php'pdb'file.php'chemical/x-pdb'file.php'xyz'file.php'chemical/x-pdb'file.php'javascript'file.php'application/javascript'file.php'form'file.php'application/x-www-form-urlencoded'file.php'file'file.php'multipart/form-data'file.php'xhtml-mobile'file.php'application/vnd.wap.xhtml+xml'file.php'atom'file.php'application/atom+xml'file.php'amf'file.php'application/x-amf'file.php'wap'file.php'text/vnd.wap.wml'file.php'text/vnd.wap.wmlscript'file.php'image/vnd.wap.wbmp'file.php'wml'file.php'text/vnd.wap.wml'file.php'wmlscript'file.php'text/vnd.wap.wmlscript'file.php'wbmp'file.php'image/vnd.wap.wbmp'file.php'woff'file.php'application/x-font-woff'file.php'appcache'file.php'text/cache-manifest'file.php'manifest'file.php'text/cache-manifest'file.php'htc'file.php'text/x-component'file.php'rdf'file.php'application/xml'file.php'crx'file.php'application/x-chrome-extension'file.php'oex'file.php'application/x-opera-extension'file.php'xpi'file.php'application/x-xpinstall'file.php'safariextz'file.php'application/octet-stream'file.php'webapp'file.php'application/x-web-app-manifest+json'file.php'vcf'file.php'text/x-vcard'file.php'vtt'file.php'text/vtt'file.php'mkv'file.php'video/x-matroska'file.php'pkpass'file.php'application/vnd.apple.pkpass'file.php'ajax'file.php'text/html'file.php'bmp'file.php'image/bmp'file.php'HTTP/1.1'file.php'UTF-8'file.php'OK'file.php'wb+'file.php'php://memory'file.php'streamTarget'file.php'streamTarget'file.php'streamMode'file.php'streamMode'file.php'stream'file.php'stream'file.php'Stream option must be an object that implements StreamInterface'file.php'stream'file.php'body'file.php'body'file.php'statusCodes'file.php'statusCodes'file.php'status'file.php'status'file.php'charset'file.php'charset'file.php'App.encoding'file.php'charset'file.php'text/html'file.php'type'file.php'type'file.php'Response::send() will be removed in 4.0.0'file.php'Location'file.php'fastcgi_finish_request'file.php'Will be removed in 4.0.0'file.php'Will be removed in 4.0.0'file.php'Content-Type'file.php'application/javascript'file.php'application/xml'file.php'application/rss+xml'file.php'text/'file.php';'file.php'Content-Type'file.php'Content-Type'file.php'Will be removed in 4.0.0'file.php''file.php'Will be removed in 4.0.0'file.php'Will be removed in 4.0.0'file.php'Location'file.php'http://example.com'file.php'Location'file.php'http://example.com'file.php'X-Extra'file.php'My header'file.php'WWW-Authenticate: Negotiate'file.php'WWW-Authenticate: Negotiate'file.php'Content-type: application/pdf'file.php'WWW-Authenticate: Negotiate'file.php'WWW-Authenticate: Not-Negotiate'file.php'WWW-Authenticate: Not-Negotiate'file.php'Response::header() is deprecated. 'file.php'Use `withHeader()`, `getHeaderLine()` and `getHeaders()` instead.'file.php':'file.php'trim'file.php're supporting PSR7, the internal storage has each header as an array.
     *
     * @return array
     */
    protected function getSimpleHeaders()
    {
        $out = [];
        foreach ($this->headers as $key => $values) {
            $header = $this->headerNames[strtolower($key)];
            if (count($values) === 1) {
                $values = $values[0];
            }
            $out[$header] = $values;
        }

        return $out;
    }

    /**
     * Accessor for the location header.
     *
     * Get/Set the Location header value.
     *
     * @param string|null $url Either null to get the current location, or a string to set one.
     * @return string|null When setting the location null will be returned. When reading the location
     *   a string of the current location header value (if any) will be returned.
     * @deprecated 3.4.0 Mutable responses are deprecated. Use `withLocation()` and `getHeaderLine()`
     *   instead.
     */
    public function location($url = null)
    {
        deprecationWarning(
            'file.php' .
            'file.php'
        );

        if ($url === null) {
            $result = $this->getHeaderLine('file.php');
            if (!$result) {
                return null;
            }

            return $result;
        }
        if ($this->_status === 200) {
            $this->_status = 302;
        }
        $this->_setHeader('file.php', $url);

        return null;
    }

    /**
     * Return an instance with an updated location header.
     *
     * If the current status code is 200, it will be replaced
     * with 302.
     *
     * @param string $url The location to redirect to.
     * @return static A new response with the Location header set.
     */
    public function withLocation($url)
    {
        $new = $this->withHeader('file.php', $url);
        if ($new->_status === 200) {
            $new->_status = 302;
        }

        return $new;
    }

    /**
     * Sets a header.
     *
     * @param string $header Header key.
     * @param string $value Header value.
     * @return void
     */
    protected function _setHeader($header, $value)
    {
        $normalized = strtolower($header);
        $this->headerNames[$normalized] = $header;
        $this->headers[$header] = [$value];
    }

    /**
     * Clear header
     *
     * @param string $header Header key.
     * @return void
     */
    protected function _clearHeader($header)
    {
        $normalized = strtolower($header);
        if (!isset($this->headerNames[$normalized])) {
            return;
        }
        $original = $this->headerNames[$normalized];
        unset($this->headerNames[$normalized], $this->headers[$original]);
    }

    /**
     * Buffers the response message to be sent
     * if $content is null the current buffer is returned
     *
     * @param string|callable|null $content the string or callable message to be sent
     * @return string|null Current message buffer if $content param is passed as null
     * @deprecated 3.4.0 Mutable response methods are deprecated. Use `withBody()`/`withStringBody()` and `getBody()` instead.
     */
    public function body($content = null)
    {
        deprecationWarning(
            'file.php' .
            'file.php'
        );

        if ($content === null) {
            if ($this->stream->isSeekable()) {
                $this->stream->rewind();
            }
            $result = $this->stream->getContents();
            if (strlen($result) === 0) {
                return null;
            }

            return $result;
        }

        // Compatibility with closure/streaming responses
        if (!is_string($content) && is_callable($content)) {
            $this->stream = new CallbackStream($content);
        } else {
            $this->_createStream();
            $this->stream->write($content);
        }

        return $content;
    }

    /**
     * Handles the callable body for backward compatibility reasons.
     *
     * @param callable $content Callable content.
     * @return string
     */
    protected function _handleCallableBody(callable $content)
    {
        ob_start();
        $result1 = $content();
        $result2 = ob_get_contents();
        ob_get_clean();

        if ($result1) {
            return $result1;
        }

        return $result2;
    }

    /**
     * Sets the HTTP status code to be sent.
     * If $code is null the current code is returned
     *
     * If the status code is 304 or 204, the existing Content-Type header
     * will be cleared, as these response codes have no body.
     *
     * @param int|null $code the HTTP status code
     * @return int Current status code
     * @throws \InvalidArgumentException When an unknown status code is reached.
     * @deprecated 3.4.0 Use `getStatusCode()` and `withStatus()` instead.
     */
    public function statusCode($code = null)
    {
        deprecationWarning(
            'file.php' .
            'file.php'
        );

        if ($code === null) {
            return $this->_status;
        }
        if (!isset($this->_statusCodes[$code])) {
            throw new InvalidArgumentException('file.php');
        }
        $this->_setStatus($code);

        return $code;
    }

    /**
     * Gets the response status code.
     *
     * The status code is a 3-digit integer result code of the server'file.php's
     * status code.
     *
     * This method MUST be implemented in such a way as to retain the
     * immutability of the message, and MUST return an instance that has the
     * updated status and reason phrase.
     *
     * If the status code is 304 or 204, the existing Content-Type header
     * will be cleared, as these response codes have no body.
     *
     * There are external packages such as `fig/http-message-util` that provide HTTP
     * status code constants. These can be used with any method that accepts or
     * returns a status code integer. However, keep in mind that these consants
     * might include status codes that are now allowed which will throw an
     * `\InvalidArgumentException`.
     *
     * @link https://tools.ietf.org/html/rfc7231#section-6
     * @link https://www.iana.org/assignments/http-status-codes/http-status-codes.xhtml
     * @param int $code The 3-digit integer status code to set.
     * @param string $reasonPhrase The reason phrase to use with the
     *     provided status code; if none is provided, implementations MAY
     *     use the defaults as suggested in the HTTP specification.
     * @return static
     * @throws \InvalidArgumentException For invalid status code arguments.
     */
    public function withStatus($code, $reasonPhrase = 'file.php')
    {
        $new = clone $this;
        $new->_setStatus($code, $reasonPhrase);

        return $new;
    }

    /**
     * Modifier for response status
     *
     * @param int $code The status code to set.
     * @param string $reasonPhrase The response reason phrase.
     * @return void
     * @throws \InvalidArgumentException For invalid status code arguments.
     */
    protected function _setStatus($code, $reasonPhrase = 'file.php')
    {
        if ($code < static::STATUS_CODE_MIN || $code > static::STATUS_CODE_MAX) {
            throw new InvalidArgumentException(sprintf(
                'file.php',
                $code
            ));
        }

        $this->_status = $code;
        if ($reasonPhrase === 'file.php' && isset($this->_statusCodes[$code])) {
            $reasonPhrase = $this->_statusCodes[$code];
        }
        $this->_reasonPhrase = $reasonPhrase;

        // These status codes don'file.php't have content-types.
        if (in_array($code, [304, 204], true)) {
            $this->_clearHeader('file.php');
        }
    }

    /**
     * Gets the response reason phrase associated with the status code.
     *
     * Because a reason phrase is not a required element in a response
     * status line, the reason phrase value MAY be null. Implementations MAY
     * choose to return the default RFC 7231 recommended reason phrase (or those
     * listed in the IANA HTTP Status Code Registry) for the response'file.php'Not Found'file.php'Unicorn Moved'file.php'Unexpected Minotaur'file.php'Nothing Here'file.php'Reverse Infinity'file.php'Universal Password'file.php'Hello'file.php'World'file.php'Response::httpCodes(). Will be removed in 4.0.0'file.php'Invalid status code'file.php'jpg'file.php'keynote'file.php'application/keynote'file.php'bat'file.php'application/bat'file.php'jpg'file.php'text/plain'file.php'Response::type() is deprecated. 'file.php'Use setTypeMap(), getType() or withType() instead.'file.php'/'file.php'xhtml'file.php'application/xhtml+xml'file.php'application/xhtml'file.php'Content-Type'file.php';'file.php';'file.php'/'file.php'"%s" is an invalid content type.'file.php'pdf'file.php'application/pdf'file.php'application/pdf'file.php'pdf'file.php'mapType'file.php'Response::charset() is deprecated. 'file.php'Use getCharset()/withCharset() instead.'file.php'Response::disableCache() is deprecated. 'file.php'Use withDisabledCache() instead.'file.php'Expires'file.php'Mon, 26 Jul 1997 05:00:00 GMT'file.php'Last-Modified'file.php'D, d M Y H:i:s'file.php' GMT'file.php'Cache-Control'file.php'no-store, no-cache, must-revalidate, post-check=0, pre-check=0'file.php'Expires'file.php'Mon, 26 Jul 1997 05:00:00 GMT'file.php'Last-Modified'file.php'D, d M Y H:i:s'file.php' GMT'file.php'Cache-Control'file.php'no-store, no-cache, must-revalidate, post-check=0, pre-check=0'file.php'+1 day'file.php'Response::cache() is deprecated. 'file.php'Use withCache() instead.'file.php'Invalid time parameter. Ensure your time value can be parsed by strtotime'file.php'Date'file.php'D, d M Y H:i:s 'file.php'GMT'file.php'+1 day'file.php'Invalid time parameter. Ensure your time value can be parsed by strtotime'file.php'Date'file.php'D, d M Y H:i:s 'file.php'GMT'file.php'Response::sharable() is deprecated. 'file.php'Use withSharable() instead.'file.php'public'file.php'private'file.php'no-cache'file.php'public'file.php'private'file.php'private'file.php'public'file.php'private'file.php'public'file.php'public'file.php'private'file.php'max-age'file.php'Response::sharedMaxAge() is deprecated. 'file.php'Use withSharedMaxAge() instead.'file.php's-maxage'file.php's-maxage'file.php's-maxage'file.php's-maxage'file.php'Response::maxAge() is deprecated. 'file.php'Use withMaxAge() instead.'file.php'max-age'file.php'max-age'file.php'max-age'file.php'max-age'file.php'Response::mustRevalidate() is deprecated. 'file.php'Use withMustRevalidate() instead.'file.php'must-revalidate'file.php'must-revalidate'file.php'must-revalidate'file.php'must-revalidate'file.php'must-revalidate'file.php''file.php'%s=%s'file.php', 'file.php', 'file.php'Cache-Control'file.php'now'file.php'+1 day'file.php'Response::expires() is deprecated. 'file.php'Use withExpires() instead.'file.php'Expires'file.php'D, j M Y H:i:s'file.php' GMT'file.php'Expires'file.php'Expires'file.php'now'file.php'+1 day'file.php'Expires'file.php'D, j M Y H:i:s'file.php' GMT'file.php'now'file.php'+1 day'file.php'Response::modified() is deprecated. 'file.php'Use withModified() or getHeaderLine("Last-Modified") instead.'file.php'Last-Modified'file.php'D, j M Y H:i:s'file.php' GMT'file.php'Last-Modified'file.php'Last-Modified'file.php'now'file.php'+1 day'file.php'Last-Modified'file.php'D, j M Y H:i:s'file.php' GMT'file.php'Allow'file.php'Content-Encoding'file.php'Content-Language'file.php'Content-Length'file.php'Content-MD5'file.php'Content-Type'file.php'Last-Modified'file.php'not modified'file.php'Allow'file.php'Content-Encoding'file.php'Content-Language'file.php'Content-Length'file.php'Content-MD5'file.php'Content-Type'file.php'Last-Modified'file.php'Response::vary() is deprecated. 'file.php'Use withVary() instead.'file.php'Vary'file.php', 'file.php'Vary'file.php', 'file.php'Vary'file.php'Vary'file.php'Response::etag() is deprecated. 'file.php'Use withEtag() or getHeaderLine("Etag") instead.'file.php'Etag'file.php'%s"%s"'file.php'W/'file.php'Etag'file.php'Etag'file.php'%s"%s"'file.php'W/'file.php'Etag'file.php'Y-m-d H:i:s'file.php'UTC'file.php'zlib.output_compression'file.php'1'file.php'zlib'file.php'HTTP_ACCEPT_ENCODING'file.php'gzip'file.php'ob_gzhandler'file.php'HTTP_ACCEPT_ENCODING'file.php'gzip'file.php'zlib.output_compression'file.php'1'file.php'ob_gzhandler'file.php'Response::download() is deprecated. 'file.php'Use withDownload() instead.'file.php'Content-Disposition'file.php'attachment; filename="'file.php'"'file.php'Content-Disposition'file.php'attachment; filename="'file.php'"'file.php'Response::protocol() is deprecated. 'file.php'Use getProtocolVersion() instead.'file.php'Response::length() is deprecated. 'file.php'Use withLength() instead.'file.php'Content-Length'file.php'Content-Length'file.php'Content-Length'file.php'Content-Length'file.php'http://example.com?page=1'file.php'rel'file.php'prev'file.php'http://example.com?page=3'file.php'rel'file.php'next'file.php'="'file.php'"'file.php''file.php'; 'file.php'; 'file.php'Link'file.php'<'file.php'>'file.php'If-None-Match'file.php'If-Modified-Since'file.php'/\s*,\s*/'file.php'If-None-Match'file.php'Etag'file.php'*'file.php'If-Modified-Since'file.php'Last-Modified'file.php'Last-Modified'file.php's not set.
     *
     * If the method is called with an array as argument, it will set the cookie
     * configuration to the cookie container.
     *
     *  ### Options (when setting a configuration)
     *  - name: The Cookie name
     *  - value: Value of the cookie
     *  - expire: Time the cookie expires in
     *  - path: Path the cookie applies to
     *  - domain: Domain the cookie is for.
     *  - secure: Is the cookie https?
     *  - httpOnly: Is the cookie available in the client?
     *
     * ### Examples
     *
     * ### Getting all cookies
     *
     * `$this->cookie()`
     *
     * ### Getting a certain cookie configuration
     *
     * `$this->cookie('file.php')`
     *
     * ### Setting a cookie configuration
     *
     * `$this->cookie((array) $options)`
     *
     * @param array|null $options Either null to get all cookies, string for a specific cookie
     *  or array to set cookie.
     * @return mixed
     * @deprecated 3.4.0 Use getCookie(), getCookies() and withCookie() instead.
     */
    public function cookie($options = null)
    {
        deprecationWarning(
            'file.php' .
            'file.php'
        );

        if ($options === null) {
            return $this->getCookies();
        }

        if (is_string($options)) {
            if (!$this->_cookies->has($options)) {
                return null;
            }

            $cookie = $this->_cookies->get($options);

            return $this->convertCookieToArray($cookie);
        }

        $options += [
            'file.php' => 'file.php',
            'file.php' => 'file.php',
            'file.php' => 0,
            'file.php' => 'file.php',
            'file.php' => 'file.php',
            'file.php' => false,
            'file.php' => false,
        ];
        $expires = $options['file.php'] ? new DateTime('file.php' . $options['file.php']) : null;
        $cookie = new Cookie(
            $options['file.php'],
            $options['file.php'],
            $expires,
            $options['file.php'],
            $options['file.php'],
            $options['file.php'],
            $options['file.php']
        );
        $this->_cookies = $this->_cookies->add($cookie);
    }

    /**
     * Create a new response with a cookie set.
     *
     * ### Data
     *
     * - `value`: Value of the cookie
     * - `expire`: Time the cookie expires in
     * - `path`: Path the cookie applies to
     * - `domain`: Domain the cookie is for.
     * - `secure`: Is the cookie https?
     * - `httpOnly`: Is the cookie available in the client?
     *
     * ### Examples
     *
     * ```
     * // set scalar value with defaults
     * $response = $response->withCookie('file.php', 1);
     *
     * // customize cookie attributes
     * $response = $response->withCookie('file.php', ['file.php' => 'file.php']);
     *
     * // add a cookie object
     * $response = $response->withCookie(new Cookie('file.php', 1));
     * ```
     *
     * @param string|\Cake\Http\Cookie\Cookie $name The name of the cookie to set, or a cookie object
     * @param array|string $data Either a string value, or an array of cookie options.
     * @return static
     */
    public function withCookie($name, $data = 'file.php')
    {
        if ($name instanceof Cookie) {
            $cookie = $name;
        } else {
            deprecationWarning(
                get_called_class() . 'file.php' .
                'file.php'
            );

            if (!is_array($data)) {
                $data = ['file.php' => $data];
            }
            $data += [
                'file.php' => 'file.php',
                'file.php' => 0,
                'file.php' => 'file.php',
                'file.php' => 'file.php',
                'file.php' => false,
                'file.php' => false,
                'file.php' => null,
            ];
            $expires = $data['file.php'] ? new DateTime('file.php' . $data['file.php']) : null;
            $cookie = new Cookie(
                $name,
                $data['file.php'],
                $expires,
                $data['file.php'],
                $data['file.php'],
                $data['file.php'],
                $data['file.php'],
                $data['file.php']
            );
        }

        $new = clone $this;
        $new->_cookies = $new->_cookies->add($cookie);

        return $new;
    }

    /**
     * Create a new response with an expired cookie set.
     *
     * ### Options
     *
     * - `path`: Path the cookie applies to
     * - `domain`: Domain the cookie is for.
     * - `secure`: Is the cookie https?
     * - `httpOnly`: Is the cookie available in the client?
     *
     * ### Examples
     *
     * ```
     * // set scalar value with defaults
     * $response = $response->withExpiredCookie('file.php');
     *
     * // customize cookie attributes
     * $response = $response->withExpiredCookie('file.php', ['file.php' => 'file.php']);
     *
     * // add a cookie object
     * $response = $response->withExpiredCookie(new Cookie('file.php'));
     * ```
     *
     * @param string|\Cake\Http\Cookie\CookieInterface $name The name of the cookie to expire, or a cookie object
     * @param array $options An array of cookie options.
     * @return static
     */
    public function withExpiredCookie($name, $options = [])
    {
        if ($name instanceof CookieInterface) {
            $cookie = $name->withExpired();
        } else {
            deprecationWarning(
                get_called_class() . 'file.php' .
                'file.php'
            );

            $options += [
                'file.php' => 'file.php',
                'file.php' => 'file.php',
                'file.php' => false,
                'file.php' => false,
            ];

            $cookie = new Cookie(
                $name,
                'file.php',
                DateTime::createFromFormat('file.php', 1),
                $options['file.php'],
                $options['file.php'],
                $options['file.php'],
                $options['file.php']
            );
        }

        $new = clone $this;
        $new->_cookies = $new->_cookies->add($cookie);

        return $new;
    }

    /**
     * Read a single cookie from the response.
     *
     * This method provides read access to pending cookies. It will
     * not read the `Set-Cookie` header if set.
     *
     * @param string $name The cookie name you want to read.
     * @return array|null Either the cookie data or null
     */
    public function getCookie($name)
    {
        if (!$this->_cookies->has($name)) {
            return null;
        }

        $cookie = $this->_cookies->get($name);

        return $this->convertCookieToArray($cookie);
    }

    /**
     * Get all cookies in the response.
     *
     * Returns an associative array of cookie name => cookie data.
     *
     * @return array
     */
    public function getCookies()
    {
        $out = [];
        foreach ($this->_cookies as $cookie) {
            $out[$cookie->getName()] = $this->convertCookieToArray($cookie);
        }

        return $out;
    }

    /**
     * Convert the cookie into an array of its properties.
     *
     * This method is compatible with the historical behavior of Cake\Http\Response,
     * where `httponly` is `httpOnly` and `expires` is `expire`
     *
     * @param \Cake\Http\Cookie\CookieInterface $cookie Cookie object.
     * @return array
     */
    protected function convertCookieToArray(CookieInterface $cookie)
    {
        return [
            'file.php' => $cookie->getName(),
            'file.php' => $cookie->getStringValue(),
            'file.php' => $cookie->getPath(),
            'file.php' => $cookie->getDomain(),
            'file.php' => $cookie->isSecure(),
            'file.php' => $cookie->isHttpOnly(),
            'file.php' => $cookie->getExpiresTimestamp(),
            'file.php' => $cookie->getSameSite(),
        ];
    }

    /**
     * Get the CookieCollection from the response
     *
     * @return \Cake\Http\Cookie\CookieCollection
     */
    public function getCookieCollection()
    {
        return $this->_cookies;
    }

    /**
     * Get a new instance with provided cookie collection.
     *
     * @param \Cake\Http\Cookie\CookieCollection $cookieCollection Cookie collection to set.
     * @return static
     */
    public function withCookieCollection(CookieCollection $cookieCollection)
    {
        $new = clone $this;
        $new->_cookies = $cookieCollection;

        return $new;
    }

    /**
     * Setup access for origin and methods on cross origin requests
     *
     * This method allow multiple ways to setup the domains, see the examples
     *
     * ### Full URI
     * ```
     * cors($request, 'file.php');
     * ```
     *
     * ### URI with wildcard
     * ```
     * cors($request, 'file.php');
     * ```
     *
     * ### Ignoring the requested protocol
     * ```
     * cors($request, 'file.php');
     * ```
     *
     * ### Any URI
     * ```
     * cors($request, 'file.php');
     * ```
     *
     * ### Whitelist of URIs
     * ```
     * cors($request, ['file.php', 'file.php', 'file.php']);
     * ```
     *
     * *Note* The `$allowedDomains`, `$allowedMethods`, `$allowedHeaders` parameters are deprecated.
     * Instead the builder object should be used.
     *
     * @param \Cake\Http\ServerRequest $request Request object
     * @param string|string[] $allowedDomains List of allowed domains, see method description for more details
     * @param string|string[] $allowedMethods List of HTTP verbs allowed
     * @param string|string[] $allowedHeaders List of HTTP headers allowed
     * @return \Cake\Http\CorsBuilder A builder object the provides a fluent interface for defining
     *   additional CORS headers.
     */
    public function cors(ServerRequest $request, $allowedDomains = [], $allowedMethods = [], $allowedHeaders = [])
    {
        $origin = $request->getHeaderLine('file.php');
        $ssl = $request->is('file.php');
        $builder = new CorsBuilder($this, $origin, $ssl);
        if (!$origin) {
            return $builder;
        }
        if (empty($allowedDomains) && empty($allowedMethods) && empty($allowedHeaders)) {
            return $builder;
        }
        deprecationWarning(
            'file.php' .
            'file.php'
        );

        $updated = $builder->allowOrigin($allowedDomains)
            ->allowMethods((array)$allowedMethods)
            ->allowHeaders((array)$allowedHeaders)
            ->build();

        // If $updated is a new instance, mutate this object in-place
        // to retain existing behavior.
        if ($updated !== $this) {
            foreach ($updated->getHeaders() as $name => $values) {
                if (!$this->hasHeader($name)) {
                    $this->_setHeader($name, $values[0]);
                }
            }
        }

        return $builder;
    }

    /**
     * Setup for display or download the given file.
     *
     * If $_SERVER['file.php'] is set a slice of the file will be
     * returned instead of the entire file.
     *
     * ### Options keys
     *
     * - name: Alternate download name
     * - download: If `true` sets download header and forces file to be downloaded rather than displayed in browser
     *
     * @param string $path Path to file. If the path is not an absolute path that resolves
     *   to a file, `APP` will be prepended to the path (this behavior is deprecated).
     * @param array $options Options See above.
     * @return void
     * @throws \Cake\Http\Exception\NotFoundException
     * @deprecated 3.4.0 Use withFile() instead.
     */
    public function file($path, array $options = [])
    {
        deprecationWarning(
            'file.php' .
            'file.php'
        );

        $file = $this->validateFile($path);
        $options += [
            'file.php' => null,
            'file.php' => null,
        ];

        $extension = strtolower($file->ext());
        $download = $options['file.php'];
        if ((!$extension || $this->type($extension) === false) && $download === null) {
            $download = true;
        }

        $fileSize = $file->size();
        if ($download) {
            $agent = env('file.php');

            if (preg_match('file.php', $agent)) {
                $contentType = 'file.php';
            } elseif (preg_match('file.php', $agent)) {
                $contentType = 'file.php';
            }

            if (!empty($contentType)) {
                $this->type($contentType);
            }
            if ($options['file.php'] === null) {
                $name = $file->name;
            } else {
                $name = $options['file.php'];
            }
            $this->download($name);
            $this->header('file.php', 'file.php');
        }

        $this->header('file.php', 'file.php');
        $httpRange = env('file.php');
        if (isset($httpRange)) {
            $this->_fileRange($file, $httpRange);
        } else {
            $this->header('file.php', $fileSize);
        }

        $this->_file = $file;
        $this->stream = new Stream($file->path, 'file.php');
    }

    /**
     * Create a new instance that is based on a file.
     *
     * This method will augment both the body and a number of related headers.
     *
     * If `$_SERVER['file.php']` is set, a slice of the file will be
     * returned instead of the entire file.
     *
     * ### Options keys
     *
     * - name: Alternate download name
     * - download: If `true` sets download header and forces file to
     *   be downloaded rather than displayed inline.
     *
     * @param string $path Path to file. If the path is not an absolute path that resolves
     *   to a file, `APP` will be prepended to the path (this behavior is deprecated).
     * @param array $options Options See above.
     * @return static
     * @throws \Cake\Http\Exception\NotFoundException
     */
    public function withFile($path, array $options = [])
    {
        $file = $this->validateFile($path);
        $options += [
            'file.php' => null,
            'file.php' => null,
        ];

        $extension = strtolower($file->ext());
        $mapped = $this->getMimeType($extension);
        if ((!$extension || !$mapped) && $options['file.php'] === null) {
            $options['file.php'] = true;
        }

        $new = clone $this;
        if ($mapped) {
            $new = $new->withType($extension);
        }

        $fileSize = $file->size();
        if ($options['file.php']) {
            $agent = env('file.php');

            if (preg_match('file.php', $agent)) {
                $contentType = 'file.php';
            } elseif (preg_match('file.php', $agent)) {
                $contentType = 'file.php';
            }

            if (isset($contentType)) {
                $new = $new->withType($contentType);
            }
            $name = $options['file.php'] ?: $file->name;
            $new = $new->withDownload($name)
                ->withHeader('file.php', 'file.php');
        }

        $new = $new->withHeader('file.php', 'file.php');
        $httpRange = env('file.php');
        if (isset($httpRange)) {
            $new->_fileRange($file, $httpRange);
        } else {
            $new = $new->withHeader('file.php', (string)$fileSize);
        }
        $new->_file = $file;
        $new->stream = new Stream($file->path, 'file.php');

        return $new;
    }

    /**
     * Convenience method to set a string into the response body
     *
     * @param string $string The string to be sent
     * @return static
     */
    public function withStringBody($string)
    {
        $new = clone $this;
        $new->_createStream();
        $new->stream->write((string)$string);

        return $new;
    }

    /**
     * Validate a file path is a valid response body.
     *
     * @param string $path The path to the file.
     * @throws \Cake\Http\Exception\NotFoundException
     * @return \Cake\Filesystem\File
     */
    protected function validateFile($path)
    {
        if (strpos($path, 'file.php') !== false || strpos($path, 'file.php') !== false) {
            throw new NotFoundException(__d('file.php', 'file.php'));
        }
        if (!is_file($path)) {
            deprecationWarning(
                'file.php' .
                'file.php'
            );
            $path = APP . $path;
        }
        if (!Folder::isAbsolute($path)) {
            deprecationWarning(
                'file.php' .
                'file.php'
            );
        }

        $file = new File($path);
        if (!$file->exists() || !$file->readable()) {
            if (Configure::read('file.php')) {
                throw new NotFoundException(sprintf('file.php', $path));
            }
            throw new NotFoundException(__d('file.php', 'file.php'));
        }

        return $file;
    }

    /**
     * Get the current file if one exists.
     *
     * @return \Cake\Filesystem\File|null The file to use in the response or null
     */
    public function getFile()
    {
        return $this->_file;
    }

    /**
     * Apply a file range to a file and set the end offset.
     *
     * If an invalid range is requested a 416 Status code will be used
     * in the response.
     *
     * @param \Cake\Filesystem\File $file The file to set a range on.
     * @param string $httpRange The range to use.
     * @return void
     * @deprecated 3.4.0 Long term this needs to be refactored to follow immutable paradigms.
     *   However for now, it is simpler to leave this alone.
     */
    protected function _fileRange($file, $httpRange)
    {
        $fileSize = $file->size();
        $lastByte = $fileSize - 1;
        $start = 0;
        $end = $lastByte;

        preg_match('file.php', $httpRange, $matches);
        if ($matches) {
            $start = $matches[1];
            $end = isset($matches[2]) ? $matches[2] : 'file.php';
        }

        if ($start === 'file.php') {
            $start = $fileSize - $end;
            $end = $lastByte;
        }
        if ($end === 'file.php') {
            $end = $lastByte;
        }

        if ($start > $end || $end > $lastByte || $start > $lastByte) {
            $this->_setStatus(416);
            $this->_setHeader('file.php', 'file.php' . $lastByte . 'file.php' . $fileSize);

            return;
        }

        $this->_setHeader('file.php', $end - $start + 1);
        $this->_setHeader('file.php', 'file.php' . $start . 'file.php' . $end . 'file.php' . $fileSize);
        $this->_setStatus(206);
        $this->_fileRange = [$start, $end];
    }

    /**
     * Reads out a file, and echos the content to the client.
     *
     * @param \Cake\Filesystem\File $file File object
     * @param array $range The range to read out of the file.
     * @return bool True is whole file is echoed successfully or false if client connection is lost in between
     * @deprecated 3.4.0 Will be removed in 4.0.0
     */
    protected function _sendFile($file, $range)
    {
        deprecationWarning('file.php');

        ob_implicit_flush(true);

        $file->open('file.php');

        $end = $start = false;
        if ($range) {
            list($start, $end) = $range;
        }
        if ($start !== false) {
            $file->offset($start);
        }

        $bufferSize = 8192;
        if (strpos(ini_get('file.php'), 'file.php') === false) {
            set_time_limit(0);
        }
        session_write_close();
        while (!feof($file->handle)) {
            if (!$this->_isActive()) {
                $file->close();

                return false;
            }
            $offset = $file->offset();
            if ($end && $offset >= $end) {
                break;
            }
            if ($end && $offset + $bufferSize >= $end) {
                $bufferSize = $end - $offset + 1;
            }
            echo fread($file->handle, $bufferSize);
        }
        $file->close();

        return true;
    }

    /**
     * Returns true if connection is still active
     *
     * @return bool
     * @deprecated 3.4.0 Will be removed in 4.0.0
     */
    protected function _isActive()
    {
        deprecationWarning('file.php');

        return connection_status() === CONNECTION_NORMAL && !connection_aborted();
    }

    /**
     * Clears the contents of the topmost output buffer and discards them
     *
     * @return bool
     * @deprecated 3.2.4 This function is not needed anymore
     */
    protected function _clearBuffer()
    {
        deprecationWarning(
            'file.php'
        );

        //@codingStandardsIgnoreStart
        return @ob_end_clean();
        //@codingStandardsIgnoreEnd
    }

    /**
     * Flushes the contents of the output buffer
     *
     * @return void
     * @deprecated 3.2.4 This function is not needed anymore
     */
    protected function _flushBuffer()
    {
        deprecationWarning(
            'file.php'
        );

        //@codingStandardsIgnoreStart
        @flush();
        if (ob_get_level()) {
            @ob_flush();
        }
        //@codingStandardsIgnoreEnd
    }

    /**
     * Stop execution of the current script. Wraps exit() making
     * testing easier.
     *
     * @param int|string $status See https://secure.php.net/exit for values
     * @return void
     * @deprecated 3.4.0 Will be removed in 4.0.0
     */
    public function stop($status = 0)
    {
        deprecationWarning('file.php');

        exit($status);
    }

    /**
     * Returns an array that can be used to describe the internal state of this
     * object.
     *
     * @return array
     */
    public function __debugInfo()
    {
        return [
            'file.php' => $this->_status,
            'file.php' => $this->getType(),
            'file.php' => $this->headers,
            'file.php' => $this->_file,
            'file.php' => $this->_fileRange,
            'file.php' => $this->_cookies,
            'file.php' => $this->_cacheDirectives,
            'file.php' => (string)$this->getBody(),
        ];
    }
}

// @deprecated 3.4.0 Add backwards compat alias.
class_alias('file.php', 'file.php');
