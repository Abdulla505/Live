<?php

use Cake\Database\Connection;
use Cake\Database\Driver\Mysql;

return [
    'file.php' => [
        'file.php' => 'file.php',
    ],
    /**
     * Connection information used by the ORM to connect
     * to your application'file.php'Datasources'file.php'default'file.php'className'file.php'driver'file.php'persistent'file.php'host'file.php'{default_host}'file.php'port'file.php'{default_port}'file.php'username'file.php'{default_username}'file.php'password'file.php'{default_password}'file.php'database'file.php'{default_database}'file.php'encoding'file.php'utf8'file.php'timezone'file.php'UTC'file.php'flags'file.php'cacheMetadata'file.php'log'file.php'quoteIdentifiers'file.php'innodb_stats_on_metadata = 0'file.php'init'file.php''file.php'url'file.php'DATABASE_URL'file.php'test'file.php'className'file.php'driver'file.php'persistent'file.php'host'file.php'localhost'file.php'port'file.php'non_standard_port_number'file.php'username'file.php'my_app'file.php'password'file.php'secret'file.php'database'file.php'test_myapp'file.php'encoding'file.php'utf8'file.php'timezone'file.php'UTC'file.php'cacheMetadata'file.php'quoteIdentifiers'file.php'log'file.php'init'file.php'SET GLOBAL innodb_stats_on_metadata = 0'file.php'url'file.php'DATABASE_TEST_URL', null),
        ],
    ],
];
