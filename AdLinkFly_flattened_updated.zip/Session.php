<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @since         0.10.0
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 */
namespace Cake\Http;

use Cake\Core\App;
use Cake\Utility\Hash;
use InvalidArgumentException;
use RuntimeException;
use SessionHandlerInterface;

/**
 * This class is a wrapper for the native PHP session functions. It provides
 * several defaults for the most common session configuration
 * via external handlers and helps with using session in cli without any warnings.
 *
 * Sessions can be created from the defaults using `Session::create()` or you can get
 * an instance of a new session by just instantiating this class and passing the complete
 * options you want to use.
 *
 * When specific options are omitted, this class will take its defaults from the configuration
 * values from the `session.*` directives in php.ini. This class will also alter such
 * directives when configuration values are provided.
 */
class Session
{
    /**
     * The Session handler instance used as an engine for persisting the session data.
     *
     * @var \SessionHandlerInterface
     */
    protected $_engine;

    /**
     * Indicates whether the sessions has already started
     *
     * @var bool
     */
    protected $_started;

    /**
     * The time in seconds the session will be valid for
     *
     * @var int
     */
    protected $_lifetime;

    /**
     * Whether this session is running under a CLI environment
     *
     * @var bool
     */
    protected $_isCLI = false;

    /**
     * Returns a new instance of a session after building a configuration bundle for it.
     * This function allows an options array which will be used for configuring the session
     * and the handler to be used. The most important key in the configuration array is
     * `defaults`, which indicates the set of configurations to inherit from, the possible
     * defaults are:
     *
     * - php: just use session as configured in php.ini
     * - cache: Use the CakePHP caching system as an storage for the session, you will need
     *   to pass the `config` key with the name of an already configured Cache engine.
     * - database: Use the CakePHP ORM to persist and manage sessions. By default this requires
     *   a table in your database named `sessions` or a `model` key in the configuration
     *   to indicate which Table object to use.
     * - cake: Use files for storing the sessions, but let CakePHP manage them and decide
     *   where to store them.
     *
     * The full list of options follows:
     *
     * - defaults: either 'file.php', 'file.php', 'file.php' or 'file.php' as explained above.
     * - handler: An array containing the handler configuration
     * - ini: A list of php.ini directives to set before the session starts.
     * - timeout: The time in minutes the session should stay active
     *
     * @param array $sessionConfig Session config.
     * @return static
     * @see \Cake\Http\Session::__construct()
     */
    public static function create($sessionConfig = [])
    {
        if (isset($sessionConfig['file.php'])) {
            $defaults = static::_defaultConfig($sessionConfig['file.php']);
            if ($defaults) {
                $sessionConfig = Hash::merge($defaults, $sessionConfig);
            }
        }

        if (!isset($sessionConfig['file.php']['file.php']) && env('file.php') && ini_get('file.php') != 1) {
            $sessionConfig['file.php']['file.php'] = 1;
        }

        if (!isset($sessionConfig['file.php']['file.php'])) {
            $sessionConfig['file.php']['file.php'] = $sessionConfig['file.php'];
        }

        if (!empty($sessionConfig['file.php'])) {
            $sessionConfig['file.php']['file.php'] = 'file.php';
        }

        // In PHP7.2.0+ session.save_handler can'file.php'7.2.0'file.php'>='file.php'ini'file.php'session.save_handler'file.php'ini'file.php'session.use_strict_mode'file.php'session.use_strict_mode'file.php'ini'file.php'session.use_strict_mode'file.php'ini'file.php'session.cookie_httponly'file.php'session.cookie_httponly'file.php'ini'file.php'session.cookie_httponly'file.php'php'file.php'cookie'file.php'CAKEPHP'file.php'ini'file.php'session.use_trans_sid'file.php'cake'file.php'cookie'file.php'CAKEPHP'file.php'ini'file.php'session.use_trans_sid'file.php'session.serialize_handler'file.php'php'file.php'session.use_cookies'file.php'session.save_path'file.php'sessions'file.php'session.save_handler'file.php'files'file.php'cache'file.php'cookie'file.php'CAKEPHP'file.php'ini'file.php'session.use_trans_sid'file.php'session.use_cookies'file.php'session.save_handler'file.php'user'file.php'handler'file.php'engine'file.php'CacheSession'file.php'config'file.php'default'file.php'database'file.php'cookie'file.php'CAKEPHP'file.php'ini'file.php'session.use_trans_sid'file.php'session.use_cookies'file.php'session.save_handler'file.php'user'file.php'session.serialize_handler'file.php'php'file.php'handler'file.php'engine'file.php'DatabaseSession'file.php'timeout'file.php'ini'file.php'session.gc_maxlifetime'file.php'timeout'file.php'cookie'file.php'ini'file.php'session.name'file.php'cookie'file.php'ini'file.php'session.cookie_path'file.php'cookiePath'file.php'/'file.php'cookiePath'file.php'ini'file.php'session.cookie_path'file.php'ini'file.php'ini'file.php'ini'file.php'handler'file.php'engine'file.php'handler'file.php'engine'file.php'handler'file.php'engine'file.php'handler'file.php'session.gc_maxlifetime'file.php'cli'file.php'phpdbg'file.php'Http/Session'file.php'Network/Session'file.php'Session adapters should be moved to the Http/Session namespace.'file.php'The class "%s" does not exist and cannot be used as a session engine'file.php'The chosen SessionHandler does not implement SessionHandlerInterface, it cannot be used as an engine.'file.php'session.use_cookies'file.php'Unable to configure the session, setting %s failed.'file.php'cli'file.php'Session was already started'file.php'session.use_cookies'file.php'Could not start the session'file.php'Could not close the session'file.php't like us setting the _SESSION var itself.
     *
     * @param array $old Set of old variables => values
     * @param array $new New set of variable => value
     * @return void
     */
    protected function _overwrite(&$old, $new)
    {
        if (!empty($old)) {
            foreach ($old as $key => $var) {
                if (!isset($new[$key])) {
                    unset($old[$key]);
                }
            }
        }
        foreach ($new as $key => $var) {
            $old[$key] = $var;
        }
    }

    /**
     * Helper method to destroy invalid sessions.
     *
     * @return void
     */
    public function destroy()
    {
        if ($this->_hasSession() && !$this->started()) {
            $this->start();
        }

        if (!$this->_isCLI && session_status() === \PHP_SESSION_ACTIVE) {
            session_destroy();
        }

        $_SESSION = [];
        $this->_started = false;
    }

    /**
     * Clears the session.
     *
     * Optionally it also clears the session id and renews the session.
     *
     * @param bool $renew If session should be renewed, as well. Defaults to false.
     * @return void
     */
    public function clear($renew = false)
    {
        $_SESSION = [];
        if ($renew) {
            $this->renew();
        }
    }

    /**
     * Returns whether a session exists
     *
     * @return bool
     */
    protected function _hasSession()
    {
        return !ini_get('file.php')
            || isset($_COOKIE[session_name()])
            || $this->_isCLI
            || (ini_get('file.php') && isset($_GET[session_name()]));
    }

    /**
     * Restarts this session.
     *
     * @return void
     */
    public function renew()
    {
        if (!$this->_hasSession() || $this->_isCLI) {
            return;
        }

        $this->start();
        $params = session_get_cookie_params();
        if (PHP_VERSION_ID >= 70300) {
            unset($params['file.php']);
            $params['file.php'] = time() - 42000;
            setcookie(
                session_name(),
                'file.php',
                $params
            );
        } else {
            setcookie(
                session_name(),
                'file.php',
                time() - 42000,
                $params['file.php'],
                $params['file.php'],
                $params['file.php'],
                $params['file.php']
            );
        }

        if (session_id() !== 'file.php') {
            session_regenerate_id(true);
        }
    }

    /**
     * Returns true if the session is no longer valid because the last time it was
     * accessed was after the configured timeout.
     *
     * @return bool
     */
    protected function _timedOut()
    {
        $time = $this->read('file.php');
        $result = false;

        $checkTime = $time !== null && $this->_lifetime > 0;
        if ($checkTime && (time() - (int)$time > $this->_lifetime)) {
            $result = true;
        }

        $this->write('file.php', time());

        return $result;
    }
}
