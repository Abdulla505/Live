# CHANGELOG

## 3.0.1
- Moved from travis to github actions workflow.
- Added yoast/phpunit-polyfills to support testing from 5.6 onwards.
- Current supported php versions are 5.6 to 8.1
- Using producer for release.
