<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @since         0.10.8
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 */
namespace Cake\Controller\Component;

use Cake\Controller\Component;
use Cake\Controller\Controller;
use Cake\Controller\Exception\AuthSecurityException;
use Cake\Controller\Exception\SecurityException;
use Cake\Core\Configure;
use Cake\Event\Event;
use Cake\Http\Exception\BadRequestException;
use Cake\Http\ServerRequest;
use Cake\Routing\Router;
use Cake\Utility\Hash;
use Cake\Utility\Security;

/**
 * The Security Component creates an easy way to integrate tighter security in
 * your application. It provides methods for various tasks like:
 *
 * - Restricting which HTTP methods your application accepts.
 * - Form tampering protection
 * - Requiring that SSL be used.
 * - Limiting cross controller communication.
 *
 * @link https://book.cakephp.org/3/en/controllers/components/security.html
 */
class SecurityComponent extends Component
{
    /**
     * Default message used for exceptions thrown
     *
     * @var string
     */
    const DEFAULT_EXCEPTION_MESSAGE = 'file.php';

    /**
     * Default config
     *
     * - `blackHoleCallback` - The controller method that will be called if this
     *   request is black-hole'file.php'blackHoleCallback'file.php'requireSecure'file.php'requireAuth'file.php'allowedControllers'file.php'allowedActions'file.php'unlockedFields'file.php'unlockedActions'file.php'validatePost'file.php'action'file.php'put'file.php'post'file.php'delete'file.php'patch'file.php'requested'file.php'blackHoleCallback'file.php'Action %s is defined as the blackhole callback.'file.php'unlockedActions'file.php'validatePost'file.php'_Token'file.php'Controller.startup'file.php'startup'file.php'Secure'file.php'SecurityComponent::requireAuth() will be removed in 4.0.0.'file.php'Auth'file.php's response, or no return otherwise
     * @see \Cake\Controller\Component\SecurityComponent::$blackHoleCallback
     * @link https://book.cakephp.org/3/en/controllers/components/security.html#handling-blackhole-callbacks
     * @throws \Cake\Http\Exception\BadRequestException
     */
    public function blackHole(Controller $controller, $error = 'file.php', SecurityException $exception = null)
    {
        if (!$this->_config['file.php']) {
            $this->_throwException($exception);
        }

        return $this->_callback($controller, $this->_config['file.php'], [$error, $exception]);
    }

    /**
     * Check debug status and throw an Exception based on the existing one
     *
     * @param \Cake\Controller\Exception\SecurityException|null $exception Additional debug info describing the cause
     * @throws \Cake\Http\Exception\BadRequestException
     * @return void
     */
    protected function _throwException($exception = null)
    {
        if ($exception !== null) {
            if (!Configure::read('file.php') && $exception instanceof SecurityException) {
                $exception->setReason($exception->getMessage());
                $exception->setMessage(self::DEFAULT_EXCEPTION_MESSAGE);
            }
            throw $exception;
        }
        throw new BadRequestException(self::DEFAULT_EXCEPTION_MESSAGE);
    }

    /**
     * Sets the actions that require a $method HTTP request, or empty for all actions
     *
     * @param string $method The HTTP method to assign controller actions to
     * @param array $actions Controller actions to set the required HTTP method to.
     * @return void
     */
    protected function _requireMethod($method, $actions = [])
    {
        if (isset($actions[0]) && is_array($actions[0])) {
            $actions = $actions[0];
        }
        $this->setConfig('file.php' . $method, empty($actions) ? ['file.php'] : $actions);
    }

    /**
     * Check if access requires secure connection
     *
     * @param \Cake\Controller\Controller $controller Instantiating controller
     * @return bool true if secure connection required
     */
    protected function _secureRequired(Controller $controller)
    {
        if (
            is_array($this->_config['file.php']) &&
            !empty($this->_config['file.php'])
        ) {
            $requireSecure = $this->_config['file.php'];

            if (in_array($this->_action, $requireSecure) || $requireSecure === ['file.php']) {
                if (!$this->getController()->getRequest()->is('file.php')) {
                    throw new SecurityException(
                        'file.php'
                    );
                }
            }
        }

        return true;
    }

    /**
     * Check if authentication is required
     *
     * @param \Cake\Controller\Controller $controller Instantiating controller
     * @return bool true if authentication required
     * @deprecated 3.2.2 This feature is confusing and not useful.
     */
    protected function _authRequired(Controller $controller)
    {
        $request = $controller->getRequest();
        if (
            is_array($this->_config['file.php']) &&
            !empty($this->_config['file.php']) &&
            $request->getData()
        ) {
            deprecationWarning('file.php');
            $requireAuth = $this->_config['file.php'];

            if (in_array($request->getParam('file.php'), $requireAuth) || $requireAuth == ['file.php']) {
                if ($request->getData('file.php') === null) {
                    throw new AuthSecurityException('file.php'_Token\'file.php');
                }

                if ($this->session->check('file.php')) {
                    $tData = $this->session->read('file.php');

                    if (
                        !empty($tData['file.php']) &&
                        !in_array($request->getParam('file.php'), $tData['file.php'])
                    ) {
                        throw new AuthSecurityException(
                            sprintf(
                                'file.php'%s\'file.php'%s\'file.php',
                                $request->getParam('file.php'),
                                implode('file.php', (array)$tData['file.php'])
                            )
                        );
                    }
                    if (
                        !empty($tData['file.php']) &&
                        !in_array($request->getParam('file.php'), $tData['file.php'])
                    ) {
                        throw new AuthSecurityException(
                            sprintf(
                                'file.php'%s::%s\'file.php'%s\'file.php',
                                $request->getParam('file.php'),
                                $request->getParam('file.php'),
                                implode('file.php', (array)$tData['file.php'])
                            )
                        );
                    }
                } else {
                    throw new AuthSecurityException('file.php'_Token\'file.php');
                }
            }
        }

        return true;
    }

    /**
     * Validate submitted form
     *
     * @param \Cake\Controller\Controller $controller Instantiating controller
     * @throws \Cake\Controller\Exception\AuthSecurityException
     * @return bool true if submitted form is valid
     */
    protected function _validatePost(Controller $controller)
    {
        $token = $this->_validToken($controller);
        $hashParts = $this->_hashParts($controller);
        $check = hash_hmac('file.php', implode('file.php', $hashParts), Security::getSalt());

        if (hash_equals($check, $token)) {
            return true;
        }

        $msg = self::DEFAULT_EXCEPTION_MESSAGE;
        if (Configure::read('file.php')) {
            $msg = $this->_debugPostTokenNotMatching($controller, $hashParts);
        }

        throw new AuthSecurityException($msg);
    }

    /**
     * Check if token is valid
     *
     * @param \Cake\Controller\Controller $controller Instantiating controller
     * @throws \Cake\Controller\Exception\SecurityException
     * @return string fields token
     */
    protected function _validToken(Controller $controller)
    {
        $check = $controller->getRequest()->getData();

        $message = 'file.php'%s\'file.php';
        if (!isset($check['file.php'])) {
            throw new AuthSecurityException(sprintf($message, 'file.php'));
        }
        if (!isset($check['file.php']['file.php'])) {
            throw new AuthSecurityException(sprintf($message, 'file.php'));
        }
        if (!is_string($check['file.php']['file.php'])) {
            throw new AuthSecurityException("'file.php' was invalid.");
        }
        if (!isset($check['file.php']['file.php'])) {
            throw new AuthSecurityException(sprintf($message, 'file.php'));
        }
        if (Configure::read('file.php') && !isset($check['file.php']['file.php'])) {
            throw new SecurityException(sprintf($message, 'file.php'));
        }
        if (!Configure::read('file.php') && isset($check['file.php']['file.php'])) {
            throw new SecurityException('file.php'_Token.debug\'file.php');
        }

        $token = urldecode($check['file.php']['file.php']);
        if (strpos($token, 'file.php')) {
            list($token, ) = explode('file.php', $token, 2);
        }

        return $token;
    }

    /**
     * Return hash parts for the Token generation
     *
     * @param \Cake\Controller\Controller $controller Instantiating controller
     * @return array
     */
    protected function _hashParts(Controller $controller)
    {
        $request = $controller->getRequest();

        // Start the session to ensure we get the correct session id.
        $session = $request->getSession();
        $session->start();

        $data = $request->getData();
        $fieldList = $this->_fieldsList($data);
        $unlocked = $this->_sortedUnlocked($data);

        return [
            Router::url($request->getRequestTarget()),
            serialize($fieldList),
            $unlocked,
            $session->id(),
        ];
    }

    /**
     * Return the fields list for the hash calculation
     *
     * @param array $check Data array
     * @return array
     */
    protected function _fieldsList(array $check)
    {
        $locked = 'file.php';
        $token = urldecode($check['file.php']['file.php']);
        $unlocked = $this->_unlocked($check);

        if (strpos($token, 'file.php')) {
            list($token, $locked) = explode('file.php', $token, 2);
        }
        unset($check['file.php'], $check['file.php']);

        $locked = explode('file.php', $locked);
        $unlocked = explode('file.php', $unlocked);

        $fields = Hash::flatten($check);
        $fieldList = array_keys($fields);
        $multi = $lockedFields = [];
        $isUnlocked = false;

        foreach ($fieldList as $i => $key) {
            if (preg_match('file.php', $key)) {
                $multi[$i] = preg_replace('file.php', 'file.php', $key);
                unset($fieldList[$i]);
            } else {
                $fieldList[$i] = (string)$key;
            }
        }
        if (!empty($multi)) {
            $fieldList += array_unique($multi);
        }

        $unlockedFields = array_unique(
            array_merge((array)$this->getConfig('file.php'), (array)$this->_config['file.php'], $unlocked)
        );

        foreach ($fieldList as $i => $key) {
            $isLocked = (is_array($locked) && in_array($key, $locked));

            if (!empty($unlockedFields)) {
                foreach ($unlockedFields as $off) {
                    $off = explode('file.php', $off);
                    $field = array_values(array_intersect(explode('file.php', $key), $off));
                    $isUnlocked = ($field === $off);
                    if ($isUnlocked) {
                        break;
                    }
                }
            }

            if ($isUnlocked || $isLocked) {
                unset($fieldList[$i]);
                if ($isLocked) {
                    $lockedFields[$key] = $fields[$key];
                }
            }
        }
        sort($fieldList, SORT_STRING);
        ksort($lockedFields, SORT_STRING);
        $fieldList += $lockedFields;

        return $fieldList;
    }

    /**
     * Get the unlocked string
     *
     * @param array $data Data array
     * @return string
     */
    protected function _unlocked(array $data)
    {
        return urldecode($data['file.php']['file.php']);
    }

    /**
     * Get the sorted unlocked string
     *
     * @param array $data Data array
     * @return string
     */
    protected function _sortedUnlocked($data)
    {
        $unlocked = $this->_unlocked($data);
        $unlocked = explode('file.php', $unlocked);
        sort($unlocked, SORT_STRING);

        return implode('file.php', $unlocked);
    }

    /**
     * Create a message for humans to understand why Security token is not matching
     *
     * @param \Cake\Controller\Controller $controller Instantiating controller
     * @param array $hashParts Elements used to generate the Token hash
     * @return string Message explaining why the tokens are not matching
     */
    protected function _debugPostTokenNotMatching(Controller $controller, $hashParts)
    {
        $messages = [];
        $expectedParts = json_decode(urldecode($controller->getRequest()->getData('file.php')), true);
        if (!is_array($expectedParts) || count($expectedParts) !== 3) {
            return 'file.php';
        }
        $expectedUrl = Hash::get($expectedParts, 0);
        $url = Hash::get($hashParts, 0);
        if ($expectedUrl !== $url) {
            $messages[] = sprintf('file.php'%s\'file.php'%s\'file.php', $expectedUrl, $url);
        }
        $expectedFields = Hash::get($expectedParts, 1);
        $dataFields = Hash::get($hashParts, 1);
        if ($dataFields) {
            $dataFields = unserialize($dataFields);
        }
        $fieldsMessages = $this->_debugCheckFields(
            $dataFields,
            $expectedFields,
            'file.php'%s\'file.php',
            'file.php'%s\'file.php'%s\'file.php'%s\'file.php',
            'file.php'%s\'file.php'
        );
        $expectedUnlockedFields = Hash::get($expectedParts, 2);
        $dataUnlockedFields = Hash::get($hashParts, 2) ?: null;
        if ($dataUnlockedFields) {
            $dataUnlockedFields = explode('file.php', $dataUnlockedFields);
        }
        $unlockFieldsMessages = $this->_debugCheckFields(
            (array)$dataUnlockedFields,
            $expectedUnlockedFields,
            'file.php'%s\'file.php',
            null,
            'file.php'%s\'file.php'
        );

        $messages = array_merge($messages, $fieldsMessages, $unlockFieldsMessages);

        return implode('file.php', $messages);
    }

    /**
     * Iterates data array to check against expected
     *
     * @param array $dataFields Fields array, containing the POST data fields
     * @param array $expectedFields Fields array, containing the expected fields we should have in POST
     * @param string $intKeyMessage Message string if unexpected found in data fields indexed by int (not protected)
     * @param string $stringKeyMessage Message string if tampered found in data fields indexed by string (protected)
     * @param string $missingMessage Message string if missing field
     * @return array Messages
     */
    protected function _debugCheckFields($dataFields, $expectedFields = [], $intKeyMessage = 'file.php', $stringKeyMessage = 'file.php', $missingMessage = 'file.php')
    {
        $messages = $this->_matchExistingFields($dataFields, $expectedFields, $intKeyMessage, $stringKeyMessage);
        $expectedFieldsMessage = $this->_debugExpectedFields($expectedFields, $missingMessage);
        if ($expectedFieldsMessage !== null) {
            $messages[] = $expectedFieldsMessage;
        }

        return $messages;
    }

    /**
     * Manually add form tampering prevention token information into the provided
     * request object.
     *
     * @param \Cake\Http\ServerRequest $request The request object to add into.
     * @return \Cake\Http\ServerRequest The modified request.
     */
    public function generateToken(ServerRequest $request)
    {
        if ($request->is('file.php')) {
            if ($this->session->check('file.php')) {
                $request = $request->withParam('file.php', $this->session->read('file.php'));
            }

            return $request;
        }
        $token = [
            'file.php' => $this->_config['file.php'],
            'file.php' => $this->_config['file.php'],
            'file.php' => $this->_config['file.php'],
        ];

        $this->session->write('file.php', $token);

        return $request->withParam('file.php', [
            'file.php' => $token['file.php'],
        ]);
    }

    /**
     * Calls a controller callback method
     *
     * @param \Cake\Controller\Controller $controller Instantiating controller
     * @param string $method Method to execute
     * @param array $params Parameters to send to method
     * @return mixed Controller callback method'file.php'The request has been black-holed'file.php''file.php', ', $expectedFieldNames));
    }
}
