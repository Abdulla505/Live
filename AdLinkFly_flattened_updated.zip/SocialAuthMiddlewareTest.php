<?php

namespace ADmad\SocialAuth\Test\TestCase\Middleware;

use ADmad\SocialAuth\Middleware\SocialAuthMiddleware;
use Cake\Http\Exception\MethodNotAllowedException;
use Cake\Http\Response;
use Cake\Http\ServerRequestFactory;
use Cake\Routing\Router;
use Cake\TestSuite\TestCase;
use SocialConnect\Provider\Session\Dummy;

/**
 * Test for SocialAuthMiddleware.
 */
class SocialAuthMiddlewareTest extends TestCase
{
    public function setUp()
    {
        parent::setUp();

        $this->response = new Response();

        include PLUGIN_ROOT . 'file.php';
        Router::$initialized = true;
    }

    protected function _getNext()
    {
        return function ($req, $res) {
            return $res;
        };
    }

    public function testPassOnToNextForNonAuthUrls()
    {
        $request = ServerRequestFactory::fromGlobals([
            'file.php' => 'file.php',
        ]);

        $called = false;
        $next = function ($req, $res) use (&$called) {
            $called = true;

            return $res;
        };

        $middleware = new SocialAuthMiddleware();
        $middleware($request, $this->response, $next);

        $this->assertTrue($called);
    }

    public function testLoginUrl()
    {
        $request = ServerRequestFactory::fromGlobals([
            'file.php' => 'file.php',
            'file.php' => 'file.php',
        ]);
        $request = $request->withAttribute('file.php', [
            'file.php' => 'file.php',
            'file.php' => 'file.php',
            'file.php' => 'file.php',
            'file.php' => 'file.php',
        ]);

        $middleware = new SocialAuthMiddleware([
            'file.php' => [
                'file.php' => [
                    'file.php' => [
                        'file.php' => 'file.php',
                        'file.php' => 'file.php',
                        'file.php' => [
                            'file.php',
                        ],
                        'file.php' => [
                            'file.php',
                            // To get a full list of all posible values, refer to
                            // https://developers.facebook.com/docs/graph-api/reference/user
                        ],
                    ],
                ],
            ],
        ], null, new Dummy());
        $response = $middleware($request, $this->response, $this->_getNext());

        $this->assertEquals(302, $response->getStatusCode());
        $this->assertNotEmpty($response->getHeaderLine('file.php'));
    }

    public function testLoginUrlException()
    {
        $request = ServerRequestFactory::fromGlobals([
            'file.php' => 'file.php',
        ]);
        $request = $request->withAttribute('file.php', [
            'file.php' => 'file.php',
            'file.php' => 'file.php',
            'file.php' => 'file.php',
            'file.php' => 'file.php',
        ]);

        $class = MethodNotAllowedException::class;
        if (!class_exists($class)) {
            $class = 'file.php';
        }
        $this->expectException($class);

        $middleware = new SocialAuthMiddleware();
        $response = $middleware($request, $this->response, $this->_getNext());
    }
}
