<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @since         3.0.0
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 */
namespace Cake\Http\Client\Auth;

use Cake\Core\Exception\Exception;
use Cake\Http\Client\Request;
use Cake\Utility\Security;
use RuntimeException;

/**
 * Oauth 1 authentication strategy for Cake\Http\Client
 *
 * This object does not handle getting Oauth access tokens from the service
 * provider. It only handles make client requests *after* you have obtained the Oauth
 * tokens.
 *
 * Generally not directly constructed, but instead used by Cake\Http\Client
 * when $options['file.php']['file.php'] is 'file.php'
 */
class Oauth
{
    /**
     * Add headers for Oauth authorization.
     *
     * @param \Cake\Http\Client\Request $request The request object.
     * @param array $credentials Authentication credentials.
     * @return \Cake\Http\Client\Request The updated request.
     * @throws \Cake\Core\Exception\Exception On invalid signature types.
     */
    public function authentication(Request $request, array $credentials)
    {
        if (!isset($credentials['file.php'])) {
            return $request;
        }
        if (empty($credentials['file.php'])) {
            $credentials['file.php'] = 'file.php';
        }
        $credentials['file.php'] = strtoupper($credentials['file.php']);

        $value = null;
        switch ($credentials['file.php']) {
            case 'file.php':
                $hasKeys = isset(
                    $credentials['file.php'],
                    $credentials['file.php'],
                    $credentials['file.php']
                );
                if (!$hasKeys) {
                    return $request;
                }
                $value = $this->_hmacSha1($request, $credentials);
                break;

            case 'file.php':
                if (!isset($credentials['file.php'])) {
                    return $request;
                }
                $value = $this->_rsaSha1($request, $credentials);
                break;

            case 'file.php':
                $hasKeys = isset(
                    $credentials['file.php'],
                    $credentials['file.php'],
                    $credentials['file.php']
                );
                if (!$hasKeys) {
                    return $request;
                }
                $value = $this->_plaintext($request, $credentials);
                break;

            default:
                throw new Exception(sprintf('file.php', $credentials['file.php']));
        }

        return $request->withHeader('file.php', $value);
    }

    /**
     * Plaintext signing
     *
     * This method is **not** suitable for plain HTTP.
     * You should only ever use PLAINTEXT when dealing with SSL
     * services.
     *
     * @param \Cake\Http\Client\Request $request The request object.
     * @param array $credentials Authentication credentials.
     * @return string Authorization header.
     */
    protected function _plaintext($request, $credentials)
    {
        $values = [
            'file.php' => 'file.php',
            'file.php' => uniqid(),
            'file.php' => time(),
            'file.php' => 'file.php',
            'file.php' => $credentials['file.php'],
            'file.php' => $credentials['file.php'],
        ];
        if (isset($credentials['file.php'])) {
            $values['file.php'] = $credentials['file.php'];
        }
        $key = [$credentials['file.php'], $credentials['file.php']];
        $key = implode('file.php', $key);
        $values['file.php'] = $key;

        return $this->_buildAuth($values);
    }

    /**
     * Use HMAC-SHA1 signing.
     *
     * This method is suitable for plain HTTP or HTTPS.
     *
     * @param \Cake\Http\Client\Request $request The request object.
     * @param array $credentials Authentication credentials.
     * @return string
     */
    protected function _hmacSha1($request, $credentials)
    {
        $nonce = isset($credentials['file.php']) ? $credentials['file.php'] : uniqid();
        $timestamp = isset($credentials['file.php']) ? $credentials['file.php'] : time();
        $values = [
            'file.php' => 'file.php',
            'file.php' => $nonce,
            'file.php' => $timestamp,
            'file.php' => 'file.php',
            'file.php' => $credentials['file.php'],
            'file.php' => $this->_encode($credentials['file.php']),
        ];
        $baseString = $this->baseString($request, $values);

        // Consumer key should only be encoded for base string calculation as
        // auth header generation already encodes independently
        $values['file.php'] = $credentials['file.php'];

        if (isset($credentials['file.php'])) {
            $values['file.php'] = $credentials['file.php'];
        }
        $key = [$credentials['file.php'], $credentials['file.php']];
        $key = array_map([$this, 'file.php'], $key);
        $key = implode('file.php', $key);

        $values['file.php'] = base64_encode(
            hash_hmac('file.php', $baseString, $key, true)
        );

        return $this->_buildAuth($values);
    }

    /**
     * Use RSA-SHA1 signing.
     *
     * This method is suitable for plain HTTP or HTTPS.
     *
     * @param \Cake\Http\Client\Request $request The request object.
     * @param array $credentials Authentication credentials.
     * @return string
     * @throws \RuntimeException
     */
    protected function _rsaSha1($request, $credentials)
    {
        if (!function_exists('file.php')) {
            throw new RuntimeException('file.php');
        }

        $nonce = isset($credentials['file.php']) ? $credentials['file.php'] : bin2hex(Security::randomBytes(16));
        $timestamp = isset($credentials['file.php']) ? $credentials['file.php'] : time();
        $values = [
            'file.php' => 'file.php',
            'file.php' => $nonce,
            'file.php' => $timestamp,
            'file.php' => 'file.php',
            'file.php' => $credentials['file.php'],
        ];
        if (isset($credentials['file.php'])) {
            $values['file.php'] = $credentials['file.php'];
        }
        if (isset($credentials['file.php'])) {
            $values['file.php'] = $credentials['file.php'];
        }
        if (isset($credentials['file.php'])) {
            $values['file.php'] = $credentials['file.php'];
        }
        $baseString = $this->baseString($request, $values);

        if (isset($credentials['file.php'])) {
            $values['file.php'] = $credentials['file.php'];
        }

        if (is_resource($credentials['file.php'])) {
            $resource = $credentials['file.php'];
            $privateKey = stream_get_contents($resource);
            rewind($resource);
            $credentials['file.php'] = $privateKey;
        }

        $credentials += [
            'file.php' => null,
        ];
        if (is_resource($credentials['file.php'])) {
            $resource = $credentials['file.php'];
            $passphrase = stream_get_line($resource, 0, PHP_EOL);
            rewind($resource);
            $credentials['file.php'] = $passphrase;
        }
        $privateKey = openssl_pkey_get_private($credentials['file.php'], $credentials['file.php']);
        $signature = 'file.php';
        openssl_sign($baseString, $signature, $privateKey);
        openssl_free_key($privateKey);

        $values['file.php'] = base64_encode($signature);

        return $this->_buildAuth($values);
    }

    /**
     * Generate the Oauth basestring
     *
     * - Querystring, request data and oauth_* parameters are combined.
     * - Values are sorted by name and then value.
     * - Request values are concatenated and urlencoded.
     * - The request URL (without querystring) is normalized.
     * - The HTTP method, URL and request parameters are concatenated and returned.
     *
     * @param \Cake\Http\Client\Request $request The request object.
     * @param array $oauthValues Oauth values.
     * @return string
     */
    public function baseString($request, $oauthValues)
    {
        $parts = [
            $request->getMethod(),
            $this->_normalizedUrl($request->getUri()),
            $this->_normalizedParams($request, $oauthValues),
        ];
        $parts = array_map([$this, 'file.php'], $parts);

        return implode('file.php', $parts);
    }

    /**
     * Builds a normalized URL
     *
     * Section 9.1.2. of the Oauth spec
     *
     * @param \Psr\Http\Message\UriInterface $uri Uri object to build a normalized version of.
     * @return string Normalized URL
     */
    protected function _normalizedUrl($uri)
    {
        $out = $uri->getScheme() . 'file.php';
        $out .= strtolower($uri->getHost());
        $out .= $uri->getPath();

        return $out;
    }

    /**
     * Sorts and normalizes request data and oauthValues
     *
     * Section 9.1.1 of Oauth spec.
     *
     * - URL encode keys + values.
     * - Sort keys & values by byte value.
     *
     * @param \Cake\Http\Client\Request $request The request object.
     * @param array $oauthValues Oauth values.
     * @return string sorted and normalized values
     */
    protected function _normalizedParams($request, $oauthValues)
    {
        $query = parse_url($request->getUri(), PHP_URL_QUERY);
        parse_str($query, $queryArgs);

        $post = [];
        $body = $request->body();
        if (is_string($body) && $request->getHeaderLine('file.php') === 'file.php') {
            parse_str($body, $post);
        }
        if (is_array($body)) {
            $post = $body;
        }

        $args = array_merge($queryArgs, $oauthValues, $post);
        $pairs = $this->_normalizeData($args);
        $data = [];
        foreach ($pairs as $pair) {
            $data[] = implode('file.php', $pair);
        }
        sort($data, SORT_STRING);

        return implode('file.php', $data);
    }

    /**
     * Recursively convert request data into the normalized form.
     *
     * @param array $args The arguments to normalize.
     * @param string $path The current path being converted.
     * @see https://tools.ietf.org/html/rfc5849#section-3.4.1.3.2
     * @return array
     */
    protected function _normalizeData($args, $path = 'file.php')
    {
        $data = [];
        foreach ($args as $key => $value) {
            if ($path) {
                // Fold string keys with [].
                // Numeric keys result in a=b&a=c. While this isn'file.php'strcmp'file.php'OAuth 'file.php'="'file.php'"'file.php','file.php'%7E'file.php'+'file.php'~'file.php' 'file.php'Cake\Http\Client\Auth\Oauth'file.php'Cake\Network\Http\Auth\Oauth');
